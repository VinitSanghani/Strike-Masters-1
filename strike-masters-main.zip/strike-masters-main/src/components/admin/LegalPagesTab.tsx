import { useEffect, useState } from "react";
import { Loader2, Save, Plus, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface Section { heading: string; body: string }

interface LegalPage {
  id: string;
  page_key: string;
  eyebrow: string;
  title: string;
  description: string;
  sections: Section[];
  primary_title: string | null;
  primary_items: string[];
  extra_title: string | null;
  extra_items: string[];
  footer_title: string | null;
  footer_body: string | null;
}

const inputCls = "w-full px-3 py-2 rounded-md bg-input/60 border border-border text-sm focus:border-neon focus:outline-none";
const labelCls = "block text-[10px] uppercase tracking-widest text-muted-foreground mb-1";

export function LegalPagesTab() {
  const [tab, setTab] = useState<"rules" | "refund">("rules");
  return (
    <div className="space-y-6">
      <div className="flex gap-1 border-b border-border">
        {(["rules", "refund"] as const).map((k) => (
          <button
            key={k}
            onClick={() => setTab(k)}
            className={`px-4 py-2 text-xs uppercase tracking-widest font-bold border-b-2 ${
              tab === k ? "border-neon text-neon" : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            {k === "rules" ? "Rules & Regulations" : "Refund Policy"}
          </button>
        ))}
      </div>
      {tab === "rules" ? <PageEditor pageKey="rules" mode="lists" /> : <PageEditor pageKey="refund" mode="sections" />}
    </div>
  );
}

function PageEditor({ pageKey, mode }: { pageKey: string; mode: "lists" | "sections" }) {
  const [data, setData] = useState<LegalPage | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setLoading(true);
    (async () => {
      const { data: row } = await (supabase as any)
        .from("legal_pages")
        .select("*")
        .eq("page_key", pageKey)
        .maybeSingle();
      if (row) {
        setData({
          ...row,
          sections: Array.isArray(row.sections) ? row.sections : [],
          primary_items: Array.isArray(row.primary_items) ? row.primary_items : [],
          extra_items: Array.isArray(row.extra_items) ? row.extra_items : [],
        } as LegalPage);
      }
      setLoading(false);
    })();
  }, [pageKey]);

  if (loading || !data) {
    return <div className="text-center py-12"><Loader2 className="w-6 h-6 mx-auto animate-spin text-neon" /></div>;
  }

  const set = <K extends keyof LegalPage>(k: K, v: LegalPage[K]) => setData({ ...data, [k]: v });

  const save = async () => {
    setSaving(true);
    const { id, page_key, ...payload } = data;
    void id; void page_key;
    const { error } = await (supabase as any).from("legal_pages").update(payload).eq("page_key", pageKey);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Page updated");
  };

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-border bg-card/40 p-6 space-y-3">
        <h3 className="font-display text-lg text-neon">Page Header</h3>
        <div className="grid sm:grid-cols-2 gap-3">
          <div>
            <label className={labelCls}>Eyebrow</label>
            <input className={inputCls} value={data.eyebrow} onChange={(e) => set("eyebrow", e.target.value)} />
          </div>
          <div>
            <label className={labelCls}>Title</label>
            <input className={inputCls} value={data.title} onChange={(e) => set("title", e.target.value)} />
          </div>
        </div>
        <div>
          <label className={labelCls}>Description</label>
          <textarea rows={2} className={inputCls} value={data.description} onChange={(e) => set("description", e.target.value)} />
        </div>
      </div>

      {mode === "sections" ? (
        <SectionsEditor sections={data.sections} onChange={(s) => set("sections", s)} />
      ) : (
        <>
          <ListEditor
            title="Primary List (e.g. Game Rules)"
            heading={data.primary_title ?? ""}
            items={data.primary_items}
            onHeading={(v) => set("primary_title", v)}
            onItems={(v) => set("primary_items", v)}
          />
          <ListEditor
            title="Secondary List (e.g. Code of Conduct)"
            heading={data.extra_title ?? ""}
            items={data.extra_items}
            onHeading={(v) => set("extra_title", v)}
            onItems={(v) => set("extra_items", v)}
          />
          <div className="rounded-2xl border border-border bg-card/40 p-6 space-y-3">
            <h3 className="font-display text-lg text-neon">Footer Callout</h3>
            <div>
              <label className={labelCls}>Footer Title</label>
              <input className={inputCls} value={data.footer_title ?? ""} onChange={(e) => set("footer_title", e.target.value)} />
            </div>
            <div>
              <label className={labelCls}>Footer Body</label>
              <textarea rows={3} className={inputCls} value={data.footer_body ?? ""} onChange={(e) => set("footer_body", e.target.value)} />
            </div>
          </div>
        </>
      )}

      <div className="flex justify-end">
        <button
          onClick={save}
          disabled={saving}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground text-xs uppercase tracking-wider font-bold shadow-neon disabled:opacity-50"
        >
          {saving ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />}
          Save Page
        </button>
      </div>
    </div>
  );
}

function SectionsEditor({ sections, onChange }: { sections: Section[]; onChange: (s: Section[]) => void }) {
  const update = (i: number, patch: Partial<Section>) => {
    const next = sections.slice();
    next[i] = { ...next[i], ...patch };
    onChange(next);
  };
  const add = () => onChange([...sections, { heading: "", body: "" }]);
  const remove = (i: number) => onChange(sections.filter((_, idx) => idx !== i));
  const move = (i: number, dir: -1 | 1) => {
    const j = i + dir;
    if (j < 0 || j >= sections.length) return;
    const next = sections.slice();
    [next[i], next[j]] = [next[j], next[i]];
    onChange(next);
  };

  return (
    <div className="rounded-2xl border border-border bg-card/40 p-6 space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-display text-lg text-neon">Sections</h3>
        <button onClick={add} className="inline-flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-md border border-border hover:border-neon">
          <Plus size={12} /> Add Section
        </button>
      </div>
      {sections.length === 0 && <p className="text-xs text-muted-foreground">No sections yet.</p>}
      {sections.map((s, i) => (
        <div key={i} className="rounded-lg border border-border bg-card/40 p-4 space-y-2">
          <div className="flex items-center justify-between gap-2">
            <span className="text-[10px] uppercase tracking-widest text-muted-foreground">Section #{i + 1}</span>
            <div className="flex items-center gap-1">
              <button onClick={() => move(i, -1)} className="text-xs px-2 py-0.5 rounded border border-border">↑</button>
              <button onClick={() => move(i, 1)} className="text-xs px-2 py-0.5 rounded border border-border">↓</button>
              <button onClick={() => remove(i)} className="text-xs px-2 py-0.5 rounded border border-destructive/40 text-destructive">
                <Trash2 size={12} />
              </button>
            </div>
          </div>
          <div>
            <label className={labelCls}>Heading</label>
            <input className={inputCls} value={s.heading} onChange={(e) => update(i, { heading: e.target.value })} />
          </div>
          <div>
            <label className={labelCls}>Body</label>
            <textarea rows={3} className={inputCls} value={s.body} onChange={(e) => update(i, { body: e.target.value })} />
          </div>
        </div>
      ))}
    </div>
  );
}

function ListEditor({
  title, heading, items, onHeading, onItems,
}: {
  title: string; heading: string; items: string[];
  onHeading: (v: string) => void; onItems: (v: string[]) => void;
}) {
  return (
    <div className="rounded-2xl border border-border bg-card/40 p-6 space-y-3">
      <h3 className="font-display text-lg text-neon">{title}</h3>
      <div>
        <label className={labelCls}>Heading</label>
        <input className={inputCls} value={heading} onChange={(e) => onHeading(e.target.value)} />
      </div>
      <div>
        <label className={labelCls}>Bullet points (one per line)</label>
        <textarea
          rows={8}
          className={inputCls}
          value={items.join("\n")}
          onChange={(e) => onItems(e.target.value.split("\n").map((s) => s.trim()).filter(Boolean))}
        />
      </div>
    </div>
  );
}
