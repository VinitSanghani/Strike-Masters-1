
-- Sponsors table
CREATE TABLE IF NOT EXISTS public.sponsors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  category text NOT NULL DEFAULT 'Sponsor',
  description text,
  website_url text,
  logo_url text,
  sort_order integer NOT NULL DEFAULT 0,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.sponsors ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Sponsors publicly readable"
  ON public.sponsors FOR SELECT
  USING (active = true OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins manage sponsors"
  ON public.sponsors FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER update_sponsors_updated_at
  BEFORE UPDATE ON public.sponsors
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE INDEX idx_sponsors_sort ON public.sponsors (sort_order, created_at);

-- Add finals/qualification status to registrations
ALTER TABLE public.registrations
  ADD COLUMN IF NOT EXISTS qualification_status text;

-- Public storage bucket for sponsor logos
INSERT INTO storage.buckets (id, name, public)
VALUES ('sponsors', 'sponsors', true)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "Sponsor logos publicly readable"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'sponsors');

CREATE POLICY "Admins upload sponsor logos"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'sponsors' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins update sponsor logos"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING (bucket_id = 'sponsors' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins delete sponsor logos"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (bucket_id = 'sponsors' AND public.has_role(auth.uid(), 'admin'));
