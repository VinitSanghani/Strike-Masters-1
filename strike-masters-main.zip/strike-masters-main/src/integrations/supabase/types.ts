export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      about_content: {
        Row: {
          eligibility_label: string
          eligibility_text: string
          equipment_label: string
          equipment_text: string
          eyebrow: string
          format_bullets: string[]
          format_intro: string
          format_title: string
          hero_description: string
          hero_title: string
          id: number
          scoring_bullets: string[]
          scoring_intro: string
          scoring_title: string
          team_label: string
          team_text: string
          updated_at: string
          who_title: string
        }
        Insert: {
          eligibility_label?: string
          eligibility_text?: string
          equipment_label?: string
          equipment_text?: string
          eyebrow?: string
          format_bullets?: string[]
          format_intro?: string
          format_title?: string
          hero_description?: string
          hero_title?: string
          id?: number
          scoring_bullets?: string[]
          scoring_intro?: string
          scoring_title?: string
          team_label?: string
          team_text?: string
          updated_at?: string
          who_title?: string
        }
        Update: {
          eligibility_label?: string
          eligibility_text?: string
          equipment_label?: string
          equipment_text?: string
          eyebrow?: string
          format_bullets?: string[]
          format_intro?: string
          format_title?: string
          hero_description?: string
          hero_title?: string
          id?: number
          scoring_bullets?: string[]
          scoring_intro?: string
          scoring_title?: string
          team_label?: string
          team_text?: string
          updated_at?: string
          who_title?: string
        }
        Relationships: []
      }
      announcements: {
        Row: {
          body: string
          created_at: string
          created_by: string | null
          id: string
          pinned: boolean
          title: string
        }
        Insert: {
          body: string
          created_at?: string
          created_by?: string | null
          id?: string
          pinned?: boolean
          title: string
        }
        Update: {
          body?: string
          created_at?: string
          created_by?: string | null
          id?: string
          pinned?: boolean
          title?: string
        }
        Relationships: []
      }
      contact_content: {
        Row: {
          description: string
          email_label: string
          email_value: string
          eyebrow: string
          id: number
          map_query: string
          organizers_label: string
          organizers_value: string
          phone_label: string
          phone_value: string
          title: string
          updated_at: string
          venue_label: string
          venue_value: string
          whatsapp_message: string
          whatsapp_number: string
        }
        Insert: {
          description?: string
          email_label?: string
          email_value?: string
          eyebrow?: string
          id?: number
          map_query?: string
          organizers_label?: string
          organizers_value?: string
          phone_label?: string
          phone_value?: string
          title?: string
          updated_at?: string
          venue_label?: string
          venue_value?: string
          whatsapp_message?: string
          whatsapp_number?: string
        }
        Update: {
          description?: string
          email_label?: string
          email_value?: string
          eyebrow?: string
          id?: number
          map_query?: string
          organizers_label?: string
          organizers_value?: string
          phone_label?: string
          phone_value?: string
          title?: string
          updated_at?: string
          venue_label?: string
          venue_value?: string
          whatsapp_message?: string
          whatsapp_number?: string
        }
        Relationships: []
      }
      gallery_images: {
        Row: {
          active: boolean
          caption: string | null
          created_at: string
          id: string
          image_url: string
          sort_order: number
          tournament_id: string | null
          updated_at: string
        }
        Insert: {
          active?: boolean
          caption?: string | null
          created_at?: string
          id?: string
          image_url: string
          sort_order?: number
          tournament_id?: string | null
          updated_at?: string
        }
        Update: {
          active?: boolean
          caption?: string | null
          created_at?: string
          id?: string
          image_url?: string
          sort_order?: number
          tournament_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "gallery_images_tournament_id_fkey"
            columns: ["tournament_id"]
            isOneToOne: false
            referencedRelation: "tournaments"
            referencedColumns: ["id"]
          },
        ]
      }
      legal_pages: {
        Row: {
          created_at: string
          description: string
          extra_items: Json
          extra_title: string | null
          eyebrow: string
          footer_body: string | null
          footer_title: string | null
          id: string
          page_key: string
          primary_items: Json
          primary_title: string | null
          sections: Json
          title: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string
          extra_items?: Json
          extra_title?: string | null
          eyebrow?: string
          footer_body?: string | null
          footer_title?: string | null
          id?: string
          page_key: string
          primary_items?: Json
          primary_title?: string | null
          sections?: Json
          title?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string
          extra_items?: Json
          extra_title?: string | null
          eyebrow?: string
          footer_body?: string | null
          footer_title?: string | null
          id?: string
          page_key?: string
          primary_items?: Json
          primary_title?: string | null
          sections?: Json
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      registrations: {
        Row: {
          admin_notes: string | null
          amount_paid: number | null
          captain_email: string
          captain_name: string
          captain_phone: string
          created_at: string
          id: string
          payment_method: string
          payment_proof_url: string | null
          payment_status: string
          payment_transaction_id: string | null
          payment_verified: boolean
          player2_name: string
          player2_phone: string | null
          player3_name: string
          player3_phone: string | null
          qualification_status: string | null
          razorpay_order_id: string | null
          razorpay_payment_id: string | null
          razorpay_signature: string | null
          skill_level: string
          status: Database["public"]["Enums"]["registration_status"]
          substitute_name: string | null
          substitute_phone: string | null
          team_name: string
          tournament_id: string | null
          updated_at: string
          upi_transaction_ref: string | null
          user_id: string
          verification_notes: string | null
          verified_at: string | null
          verified_by: string | null
        }
        Insert: {
          admin_notes?: string | null
          amount_paid?: number | null
          captain_email: string
          captain_name: string
          captain_phone: string
          created_at?: string
          id?: string
          payment_method?: string
          payment_proof_url?: string | null
          payment_status?: string
          payment_transaction_id?: string | null
          payment_verified?: boolean
          player2_name: string
          player2_phone?: string | null
          player3_name: string
          player3_phone?: string | null
          qualification_status?: string | null
          razorpay_order_id?: string | null
          razorpay_payment_id?: string | null
          razorpay_signature?: string | null
          skill_level?: string
          status?: Database["public"]["Enums"]["registration_status"]
          substitute_name?: string | null
          substitute_phone?: string | null
          team_name: string
          tournament_id?: string | null
          updated_at?: string
          upi_transaction_ref?: string | null
          user_id: string
          verification_notes?: string | null
          verified_at?: string | null
          verified_by?: string | null
        }
        Update: {
          admin_notes?: string | null
          amount_paid?: number | null
          captain_email?: string
          captain_name?: string
          captain_phone?: string
          created_at?: string
          id?: string
          payment_method?: string
          payment_proof_url?: string | null
          payment_status?: string
          payment_transaction_id?: string | null
          payment_verified?: boolean
          player2_name?: string
          player2_phone?: string | null
          player3_name?: string
          player3_phone?: string | null
          qualification_status?: string | null
          razorpay_order_id?: string | null
          razorpay_payment_id?: string | null
          razorpay_signature?: string | null
          skill_level?: string
          status?: Database["public"]["Enums"]["registration_status"]
          substitute_name?: string | null
          substitute_phone?: string | null
          team_name?: string
          tournament_id?: string | null
          updated_at?: string
          upi_transaction_ref?: string | null
          user_id?: string
          verification_notes?: string | null
          verified_at?: string | null
          verified_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "registrations_tournament_id_fkey"
            columns: ["tournament_id"]
            isOneToOne: false
            referencedRelation: "tournaments"
            referencedColumns: ["id"]
          },
        ]
      }
      round_scores: {
        Row: {
          advanced: boolean
          created_at: string
          id: string
          notes: string | null
          position: number | null
          registration_id: string
          round_id: string
          score: number | null
          tournament_id: string
          updated_at: string
        }
        Insert: {
          advanced?: boolean
          created_at?: string
          id?: string
          notes?: string | null
          position?: number | null
          registration_id: string
          round_id: string
          score?: number | null
          tournament_id: string
          updated_at?: string
        }
        Update: {
          advanced?: boolean
          created_at?: string
          id?: string
          notes?: string | null
          position?: number | null
          registration_id?: string
          round_id?: string
          score?: number | null
          tournament_id?: string
          updated_at?: string
        }
        Relationships: []
      }
      site_settings: {
        Row: {
          copyright_text: string
          id: number
          instagram_url: string
          updated_at: string
        }
        Insert: {
          copyright_text?: string
          id?: number
          instagram_url?: string
          updated_at?: string
        }
        Update: {
          copyright_text?: string
          id?: number
          instagram_url?: string
          updated_at?: string
        }
        Relationships: []
      }
      sponsors: {
        Row: {
          active: boolean
          category: string
          created_at: string
          description: string | null
          id: string
          logo_url: string | null
          name: string
          sort_order: number
          updated_at: string
          website_url: string | null
        }
        Insert: {
          active?: boolean
          category?: string
          created_at?: string
          description?: string | null
          id?: string
          logo_url?: string | null
          name: string
          sort_order?: number
          updated_at?: string
          website_url?: string | null
        }
        Update: {
          active?: boolean
          category?: string
          created_at?: string
          description?: string | null
          id?: string
          logo_url?: string | null
          name?: string
          sort_order?: number
          updated_at?: string
          website_url?: string | null
        }
        Relationships: []
      }
      sponsors_page: {
        Row: {
          cta_button_email: string
          cta_button_label: string
          cta_description: string
          cta_title: string
          description: string
          eyebrow: string
          feature_1_label: string
          feature_2_label: string
          feature_3_label: string
          featured_badge: string
          featured_description: string
          featured_enabled: boolean
          featured_logo_url: string | null
          featured_name: string
          id: number
          title: string
          updated_at: string
        }
        Insert: {
          cta_button_email?: string
          cta_button_label?: string
          cta_description?: string
          cta_title?: string
          description?: string
          eyebrow?: string
          feature_1_label?: string
          feature_2_label?: string
          feature_3_label?: string
          featured_badge?: string
          featured_description?: string
          featured_enabled?: boolean
          featured_logo_url?: string | null
          featured_name?: string
          id?: number
          title?: string
          updated_at?: string
        }
        Update: {
          cta_button_email?: string
          cta_button_label?: string
          cta_description?: string
          cta_title?: string
          description?: string
          eyebrow?: string
          feature_1_label?: string
          feature_2_label?: string
          feature_3_label?: string
          featured_badge?: string
          featured_description?: string
          featured_enabled?: boolean
          featured_logo_url?: string | null
          featured_name?: string
          id?: number
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      tournament_faqs: {
        Row: {
          answer: string
          created_at: string
          id: string
          question: string
          sort_order: number
          tournament_id: string | null
          updated_at: string
        }
        Insert: {
          answer: string
          created_at?: string
          id?: string
          question: string
          sort_order?: number
          tournament_id?: string | null
          updated_at?: string
        }
        Update: {
          answer?: string
          created_at?: string
          id?: string
          question?: string
          sort_order?: number
          tournament_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "tournament_faqs_tournament_id_fkey"
            columns: ["tournament_id"]
            isOneToOne: false
            referencedRelation: "tournaments"
            referencedColumns: ["id"]
          },
        ]
      }
      tournament_individual_awards: {
        Row: {
          active: boolean
          amount: number | null
          created_at: string
          description: string | null
          id: string
          sort_order: number
          title: string
          tournament_id: string
          updated_at: string
        }
        Insert: {
          active?: boolean
          amount?: number | null
          created_at?: string
          description?: string | null
          id?: string
          sort_order?: number
          title: string
          tournament_id: string
          updated_at?: string
        }
        Update: {
          active?: boolean
          amount?: number | null
          created_at?: string
          description?: string | null
          id?: string
          sort_order?: number
          title?: string
          tournament_id?: string
          updated_at?: string
        }
        Relationships: []
      }
      tournament_prizes: {
        Row: {
          created_at: string
          description: string | null
          id: string
          rank_label: string
          sort_order: number
          title: string
          tournament_id: string
          updated_at: string
          value: string | null
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          rank_label: string
          sort_order?: number
          title: string
          tournament_id: string
          updated_at?: string
          value?: string | null
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          rank_label?: string
          sort_order?: number
          title?: string
          tournament_id?: string
          updated_at?: string
          value?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "tournament_prizes_tournament_id_fkey"
            columns: ["tournament_id"]
            isOneToOne: false
            referencedRelation: "tournaments"
            referencedColumns: ["id"]
          },
        ]
      }
      tournament_rounds: {
        Row: {
          created_at: string
          description: string | null
          id: string
          name: string
          participants_advancing: number | null
          scheduled_at: string | null
          selection_criteria: string | null
          sort_order: number
          status: string
          tournament_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          name: string
          participants_advancing?: number | null
          scheduled_at?: string | null
          selection_criteria?: string | null
          sort_order?: number
          status?: string
          tournament_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          name?: string
          participants_advancing?: number | null
          scheduled_at?: string | null
          selection_criteria?: string | null
          sort_order?: number
          status?: string
          tournament_id?: string
          updated_at?: string
        }
        Relationships: []
      }
      tournament_schedule: {
        Row: {
          created_at: string
          day_label: string
          description: string | null
          id: string
          sort_order: number
          time_label: string | null
          title: string
          tournament_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          day_label: string
          description?: string | null
          id?: string
          sort_order?: number
          time_label?: string | null
          title: string
          tournament_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          day_label?: string
          description?: string | null
          id?: string
          sort_order?: number
          time_label?: string | null
          title?: string
          tournament_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "tournament_schedule_tournament_id_fkey"
            columns: ["tournament_id"]
            isOneToOne: false
            referencedRelation: "tournaments"
            referencedColumns: ["id"]
          },
        ]
      }
      tournament_settings: {
        Row: {
          finalist_team_count: number
          id: number
          notes: string | null
          prize_pool: string
          registration_deadline: string | null
          registration_fee: number
          registration_open: boolean
          tournament_end_date: string | null
          tournament_start_date: string | null
          updated_at: string
        }
        Insert: {
          finalist_team_count?: number
          id?: number
          notes?: string | null
          prize_pool?: string
          registration_deadline?: string | null
          registration_fee?: number
          registration_open?: boolean
          tournament_end_date?: string | null
          tournament_start_date?: string | null
          updated_at?: string
        }
        Update: {
          finalist_team_count?: number
          id?: number
          notes?: string | null
          prize_pool?: string
          registration_deadline?: string | null
          registration_fee?: number
          registration_open?: boolean
          tournament_end_date?: string | null
          tournament_start_date?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      tournament_sponsors: {
        Row: {
          active: boolean
          created_at: string
          id: string
          link_url: string | null
          logo_url: string | null
          name: string
          sort_order: number
          tournament_id: string
          updated_at: string
        }
        Insert: {
          active?: boolean
          created_at?: string
          id?: string
          link_url?: string | null
          logo_url?: string | null
          name: string
          sort_order?: number
          tournament_id: string
          updated_at?: string
        }
        Update: {
          active?: boolean
          created_at?: string
          id?: string
          link_url?: string | null
          logo_url?: string | null
          name?: string
          sort_order?: number
          tournament_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "tournament_sponsors_tournament_id_fkey"
            columns: ["tournament_id"]
            isOneToOne: false
            referencedRelation: "tournaments"
            referencedColumns: ["id"]
          },
        ]
      }
      tournament_winners: {
        Row: {
          created_at: string
          id: string
          notes: string | null
          place: number
          place_label: string
          prize_amount: number | null
          prize_title: string | null
          registration_id: string | null
          tournament_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          notes?: string | null
          place: number
          place_label: string
          prize_amount?: number | null
          prize_title?: string | null
          registration_id?: string | null
          tournament_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          notes?: string | null
          place?: number
          place_label?: string
          prize_amount?: number | null
          prize_title?: string | null
          registration_id?: string | null
          tournament_id?: string
          updated_at?: string
        }
        Relationships: []
      }
      tournaments: {
        Row: {
          auto_confirm_online: boolean
          banner_url: string | null
          cash_payment_deadline: string | null
          created_at: string
          description: string | null
          early_bird_fee: number | null
          early_bird_until: string | null
          featured: boolean
          finalist_count: number
          finals_date: string | null
          id: string
          lane_batch_size: number | null
          max_teams: number | null
          name: string
          notes: string | null
          number_of_winners: number
          payment_instructions: string | null
          payment_methods: string[]
          payment_required: boolean
          prize_pool: string
          prize_pool_amount: number | null
          qualification_date: string | null
          qualification_format: string | null
          registration_close_date: string | null
          registration_deadline: string | null
          registration_fee: number
          registration_open: boolean
          registration_open_date: string | null
          rules: string | null
          slug: string
          status: string
          subtitle: string | null
          team_size: number
          tournament_type: string
          updated_at: string
          upi_id: string | null
          upi_qr_url: string | null
          venue: string | null
        }
        Insert: {
          auto_confirm_online?: boolean
          banner_url?: string | null
          cash_payment_deadline?: string | null
          created_at?: string
          description?: string | null
          early_bird_fee?: number | null
          early_bird_until?: string | null
          featured?: boolean
          finalist_count?: number
          finals_date?: string | null
          id?: string
          lane_batch_size?: number | null
          max_teams?: number | null
          name: string
          notes?: string | null
          number_of_winners?: number
          payment_instructions?: string | null
          payment_methods?: string[]
          payment_required?: boolean
          prize_pool?: string
          prize_pool_amount?: number | null
          qualification_date?: string | null
          qualification_format?: string | null
          registration_close_date?: string | null
          registration_deadline?: string | null
          registration_fee?: number
          registration_open?: boolean
          registration_open_date?: string | null
          rules?: string | null
          slug: string
          status?: string
          subtitle?: string | null
          team_size?: number
          tournament_type?: string
          updated_at?: string
          upi_id?: string | null
          upi_qr_url?: string | null
          venue?: string | null
        }
        Update: {
          auto_confirm_online?: boolean
          banner_url?: string | null
          cash_payment_deadline?: string | null
          created_at?: string
          description?: string | null
          early_bird_fee?: number | null
          early_bird_until?: string | null
          featured?: boolean
          finalist_count?: number
          finals_date?: string | null
          id?: string
          lane_batch_size?: number | null
          max_teams?: number | null
          name?: string
          notes?: string | null
          number_of_winners?: number
          payment_instructions?: string | null
          payment_methods?: string[]
          payment_required?: boolean
          prize_pool?: string
          prize_pool_amount?: number | null
          qualification_date?: string | null
          qualification_format?: string | null
          registration_close_date?: string | null
          registration_deadline?: string | null
          registration_fee?: number
          registration_open?: boolean
          registration_open_date?: string | null
          rules?: string | null
          slug?: string
          status?: string
          subtitle?: string | null
          team_size?: number
          tournament_type?: string
          updated_at?: string
          upi_id?: string | null
          upi_qr_url?: string | null
          venue?: string | null
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      get_public_registrations: {
        Args: { _tournament_id: string }
        Returns: {
          captain_name: string
          id: string
          team_name: string
          tournament_id: string
        }[]
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "user"
      registration_status: "pending" | "approved" | "rejected"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "user"],
      registration_status: ["pending", "approved", "rejected"],
    },
  },
} as const
