
CREATE TABLE public.legal_pages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  page_key text NOT NULL UNIQUE,
  eyebrow text NOT NULL DEFAULT '',
  title text NOT NULL DEFAULT '',
  description text NOT NULL DEFAULT '',
  sections jsonb NOT NULL DEFAULT '[]'::jsonb,
  -- Optional secondary list (used for Rules: code of conduct list)
  extra_title text,
  extra_items jsonb NOT NULL DEFAULT '[]'::jsonb,
  primary_title text,
  primary_items jsonb NOT NULL DEFAULT '[]'::jsonb,
  footer_title text,
  footer_body text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.legal_pages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Legal pages publicly readable"
  ON public.legal_pages FOR SELECT
  USING (true);

CREATE POLICY "Admins manage legal pages"
  ON public.legal_pages FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER legal_pages_updated_at
  BEFORE UPDATE ON public.legal_pages
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Seed Rules page (uses primary_items = game rules, extra_items = code of conduct, footer = fair play notice)
INSERT INTO public.legal_pages (page_key, eyebrow, title, description, primary_title, primary_items, extra_title, extra_items, footer_title, footer_body)
VALUES (
  'rules',
  'Tournament Details',
  'Rules & Regulations',
  'Everything you need to know before you step onto the lane.',
  'Game Rules',
  '["USBC standard 10-pin bowling rules apply throughout the tournament.","Teams must consist of exactly 3 registered players. No substitutions allowed mid-game.","All players must check in 30 minutes before their scheduled match.","House balls and shoes are provided; players may bring their own gear (max 16 lbs).","No bumpers, lane assists, or handicaps in the main bracket.","Electronic scoring is final. Disputes must be raised before the next frame.","Top 16 teams from qualifying advance to the knockout rounds.","Knockout rounds are best-of-3; semifinals and finals are best-of-5.","Tiebreakers are decided by 9-pin no-tap rolloffs.","All disputes are settled by the head referee — decisions are final."]'::jsonb,
  'Code of Conduct',
  '["Treat all players, staff, and referees with respect.","No abusive language, harassment, or unsporting behavior.","Alcohol is not permitted on the lanes during competition.","Mobile phones must be silenced during matches.","Players under the influence will be disqualified without refund.","Coaching is allowed between frames only — no interference during a delivery."]'::jsonb,
  'Fair Play is Mandatory',
  'Violations of these rules may result in warnings, point deductions, or disqualification without refund. By registering, you agree to follow all tournament regulations.'
);

-- Seed Refund page (uses sections array of {heading, body})
INSERT INTO public.legal_pages (page_key, eyebrow, title, description, sections)
VALUES (
  'refund',
  'Legal',
  'Refund Policy',
  'Cancellation and refund terms for tournament registrations.',
  '[
    {"heading":"1. Full Refund — Before May 1, 2026","body":"Cancel before May 1, 2026 and receive a 100% refund of your ₹3,000 entry fee. Refunds are processed within 7 working days to the original payment method."},
    {"heading":"2. Partial Refund — May 1 to May 15, 2026","body":"Cancellations between May 1 and May 15, 2026 are eligible for a 50% refund (₹1,500). The remaining amount covers venue and administrative costs already committed."},
    {"heading":"3. No Refund — After May 15, 2026","body":"No refunds will be issued for cancellations after May 15, 2026 or for no-shows on tournament days. The slot may be transferred to another team — see Section 5."},
    {"heading":"4. Event Cancellation by Organizer","body":"If Strike Masters cancels the event for any reason (weather, venue issues, force majeure), all registered teams receive a 100% refund within 14 working days."},
    {"heading":"5. Team Substitutions","body":"You may substitute a player or transfer your team''s spot to another 3-player team free of charge up to May 20, 2026. Email support@strikemasters.com with the new details."},
    {"heading":"6. How to Request a Refund","body":"Email refunds@strikemasters.com with your team name, registration date, and payment reference. Include the reason for cancellation."},
    {"heading":"7. Disputes","body":"For any payment disputes, contact us first before raising a chargeback. We aim to resolve all refund requests within 5 working days."}
  ]'::jsonb
);
