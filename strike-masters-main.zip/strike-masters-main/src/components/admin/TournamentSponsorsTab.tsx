import { useEffect, useState } from "react";
import { Loader2, Trophy } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { TournamentContentTab } from "./TournamentContentTab";

/**
 * Standalone admin tab that jumps directly into the per-tournament sponsors editor.
 * Reuses TournamentContentTab so all logic (upload, reorder, toggle) stays in one place.
 */
export function TournamentSponsorsTab() {
  const [hasTournaments, setHasTournaments] = useState<boolean | null>(null);

  useEffect(() => {
    supabase.from("tournaments").select("id", { count: "exact", head: true }).then(({ count }) => {
      setHasTournaments((count ?? 0) > 0);
    });
  }, []);

  if (hasTournaments === null) {
    return <div className="text-center py-12"><Loader2 className="w-6 h-6 mx-auto animate-spin text-neon" /></div>;
  }
  if (!hasTournaments) {
    return (
      <div className="rounded-2xl border border-dashed border-border bg-card/40 p-10 text-center">
        <Trophy className="w-10 h-10 mx-auto text-muted-foreground mb-2" />
        <p className="text-sm text-muted-foreground">Create a tournament first, then add its sponsors here.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-border bg-card/40 p-4">
        <h3 className="font-display text-lg text-neon mb-1">Tournament Sponsors</h3>
        <p className="text-xs text-muted-foreground">
          Manage the auto-scrolling sponsor row that appears on each tournament page between
          <span className="text-foreground"> "What's At Stake"</span> and
          <span className="text-foreground"> "Tournament Structure"</span>. Logos render at 280×220 on desktop.
          Pick a tournament from the dropdown below.
        </p>
      </div>
      <TournamentContentTab initialKind="sponsors" />
    </div>
  );
}
