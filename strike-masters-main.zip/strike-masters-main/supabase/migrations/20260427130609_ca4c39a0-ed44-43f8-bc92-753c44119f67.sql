
-- These are trigger functions, not DB-exposed APIs. Make them SECURITY INVOKER.
ALTER FUNCTION public.validate_tournament_fields() SECURITY INVOKER;
ALTER FUNCTION public.validate_registration_fields() SECURITY INVOKER;
REVOKE EXECUTE ON FUNCTION public.validate_tournament_fields() FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.validate_registration_fields() FROM anon, authenticated, public;
