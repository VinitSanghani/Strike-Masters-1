import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Calendar, MapPin, Trophy, Users, Loader2, Star, ArrowRight, Crown } from "lucide-react";
import { SectionHeader } from "@/components/SectionHeader";
import { supabase } from "@/integrations/supabase/client";
import { formatDateDMY } from "@/lib/format-date";

export const Route = createFileRoute("/tournaments/")({
  head: () => ({
    meta: [
      { title: "Tournaments — Strike Masters" },
      { name: "description", content: "Browse all upcoming and past Strike Masters bowling tournaments." },
      { property: "og:title", content: "Strike Masters Tournaments" },
      { property: "og:description", content: "Discover all upcoming and completed bowling tournaments." },
    ],
  }),
  component: TournamentsListPage,
});

interface ListItem {
  id: string;
  slug: string;
  name: string;
  subtitle: string | null;
  banner_url: string | null;
  venue: string | null;
  qualification_date: string | null;
  finals_date: string | null;
  registration_fee: number;
  status: string;
  featured: boolean;
}

interface WinnerInfo {
  tournament_id: string;
  place: number;
  place_label: string;
  team_name: string | null;
}

function statusBadge(status: string) {
  switch (status) {
    case "active": return "text-success border-success/40 bg-success/10";
    case "upcoming": return "text-neon border-neon/40 bg-neon/10";
    case "completed": return "text-gold border-gold/40 bg-gold/10";
    default: return "text-muted-foreground/60 border-border bg-card/20";
  }
}

function TournamentCard({ t, winner }: { t: ListItem; winner?: WinnerInfo }) {
  return (
    <Link
      to="/tournaments/$slug"
      params={{ slug: t.slug }}
      className={`group rounded-2xl border bg-card/60 backdrop-blur shadow-glow overflow-hidden hover:-translate-y-1 transition-all ${t.featured ? "border-neon" : "border-border hover:border-neon/60"}`}
    >
      <div className="aspect-[16/9] bg-background/60 relative overflow-hidden">
        {t.banner_url ? (
          <img src={t.banner_url} alt={t.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" loading="lazy" />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-card via-primary/10 to-card">
            <Trophy className="w-12 h-12 text-neon/40" />
          </div>
        )}
        <div className="absolute top-2 left-2 flex gap-1.5">
          <span className={`text-[9px] uppercase tracking-widest font-bold border rounded px-2 py-0.5 ${statusBadge(t.status)}`}>
            {t.status}
          </span>
          {t.featured && (
            <span className="text-[9px] uppercase tracking-widest font-bold border rounded px-2 py-0.5 text-neon border-neon/40 bg-background/80 inline-flex items-center gap-1">
              <Star size={10} /> Featured
            </span>
          )}
        </div>
        {winner && (
          <div className="absolute bottom-2 left-2 right-2 rounded-lg border border-gold/50 bg-background/85 backdrop-blur px-3 py-2 flex items-center gap-2">
            <Crown className="w-4 h-4 text-gold flex-shrink-0" />
            <div className="min-w-0">
              <div className="text-[9px] uppercase tracking-widest text-gold font-bold leading-none">{winner.place_label}</div>
              <div className="text-xs font-bold truncate">{winner.team_name ?? "—"}</div>
            </div>
          </div>
        )}
      </div>
      <div className="p-5">
        <h3 className="font-display text-lg mb-1 group-hover:text-neon transition-colors">{t.name}</h3>
        {t.subtitle && <p className="text-xs text-muted-foreground line-clamp-2 mb-3">{t.subtitle}</p>}
        <div className="space-y-1 text-[11px] text-muted-foreground mb-3">
          {t.qualification_date && (
            <div className="flex items-center gap-1.5"><Calendar size={11} className="text-neon" /> {formatDateDMY(t.qualification_date)}</div>
          )}
          {t.venue && <div className="flex items-center gap-1.5 truncate"><MapPin size={11} className="text-neon" /> {t.venue}</div>}
          <div className="flex items-center gap-1.5"><Users size={11} className="text-neon" /> ₹{t.registration_fee.toLocaleString("en-IN")} per team</div>
        </div>
        <div className="inline-flex items-center gap-1 text-xs text-neon font-bold uppercase tracking-wider">
          {t.status === "completed" ? "View results" : "View details"} <ArrowRight size={12} className="group-hover:translate-x-1 transition-transform" />
        </div>
      </div>
    </Link>
  );
}

function TournamentsListPage() {
  const [items, setItems] = useState<ListItem[]>([]);
  const [winners, setWinners] = useState<Record<string, WinnerInfo>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const { data: tData } = await supabase
        .from("tournaments")
        .select("id, slug, name, subtitle, banner_url, venue, qualification_date, finals_date, registration_fee, status, featured")
        .neq("status", "draft");

      const tournaments = (tData ?? []) as ListItem[];
      setItems(tournaments);

      const completedIds = tournaments.filter((t) => t.status === "completed" || t.status === "archived").map((t) => t.id);
      if (completedIds.length > 0) {
        const { data: wData } = await supabase
          .from("tournament_winners")
          .select("tournament_id, place, place_label, registration_id, registrations(team_name)")
          .in("tournament_id", completedIds)
          .order("place", { ascending: true });

        const map: Record<string, WinnerInfo> = {};
        for (const w of (wData ?? []) as any[]) {
          if (!map[w.tournament_id] || w.place < map[w.tournament_id].place) {
            map[w.tournament_id] = {
              tournament_id: w.tournament_id,
              place: w.place,
              place_label: w.place_label,
              team_name: w.registrations?.team_name ?? null,
            };
          }
        }
        setWinners(map);
      }
      setLoading(false);
    })();
  }, []);

  const sortByDateAsc = (a: ListItem, b: ListItem) =>
    (a.qualification_date ? new Date(a.qualification_date).getTime() : Infinity) -
    (b.qualification_date ? new Date(b.qualification_date).getTime() : Infinity);
  const sortByDateDesc = (a: ListItem, b: ListItem) =>
    (b.qualification_date ? new Date(b.qualification_date).getTime() : 0) -
    (a.qualification_date ? new Date(a.qualification_date).getTime() : 0);

  const upcoming = items.filter((t) => t.status === "active" || t.status === "upcoming").sort(sortByDateAsc);
  const completed = items.filter((t) => t.status === "completed" || t.status === "archived").sort(sortByDateDesc);

  return (
    <div className="container mx-auto px-4 sm:px-6 py-14 sm:py-20">
      <SectionHeader
        eyebrow="All Events"
        title="Tournaments"
        description="Upcoming, active, and completed Strike Masters tournaments."
      />

      {loading ? (
        <div className="text-center py-20">
          <Loader2 className="w-8 h-8 mx-auto animate-spin text-neon" />
        </div>
      ) : items.length === 0 ? (
        <div className="max-w-xl mx-auto rounded-2xl border border-dashed border-border bg-card/40 p-10 text-center">
          <Trophy className="w-10 h-10 mx-auto text-muted-foreground mb-2" />
          <p className="text-sm text-muted-foreground">No tournaments published yet. Check back soon.</p>
        </div>
      ) : (
        <div className="max-w-6xl mx-auto space-y-14">
          {upcoming.length > 0 && (
            <section>
              <div className="flex items-center gap-3 mb-5">
                <h2 className="font-display text-2xl text-neon">Upcoming &amp; Active</h2>
                <span className="text-xs text-muted-foreground">({upcoming.length})</span>
              </div>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {upcoming.map((t) => <TournamentCard key={t.id} t={t} />)}
              </div>
            </section>
          )}

          {completed.length > 0 && (
            <section>
              <div className="flex items-center gap-3 mb-5">
                <Crown className="w-5 h-5 text-gold" />
                <h2 className="font-display text-2xl text-gold">Completed — Champions</h2>
                <span className="text-xs text-muted-foreground">({completed.length})</span>
              </div>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {completed.map((t) => <TournamentCard key={t.id} t={t} winner={winners[t.id]} />)}
              </div>
            </section>
          )}
        </div>
      )}
    </div>
  );
}
