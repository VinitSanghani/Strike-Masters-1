import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Mail, Phone, MapPin, Instagram } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import logo from "@/assets/strike-masters-logo.png";
import lanex from "@/assets/lanex-logo.png";

const DEFAULT_COPYRIGHT = "© 2026 Strike Masters Tournament. Hosted at LaneX Bowling Alley, Surat. All rights reserved.";
const DEFAULT_INSTAGRAM = "#";

export function Footer() {
  const [copyright, setCopyright] = useState(DEFAULT_COPYRIGHT);
  const [instagramUrl, setInstagramUrl] = useState(DEFAULT_INSTAGRAM);

  useEffect(() => {
    (async () => {
      const { data } = await (supabase as any).from("site_settings").select("copyright_text, instagram_url").eq("id", 1).maybeSingle();
      if (data) {
        if (data.copyright_text) setCopyright(data.copyright_text);
        if (data.instagram_url) setInstagramUrl(data.instagram_url);
      }
    })();
  }, []);

  return (
    <footer className="border-t border-border bg-card/40 mt-24">
      <div className="container mx-auto px-4 sm:px-6 py-12 grid gap-10 md:grid-cols-2 lg:grid-cols-4">
        <div>
          <div className="mb-4">
            <img src={logo} alt="Strike Masters logo" className="h-16 w-auto object-contain drop-shadow-[0_0_14px_color-mix(in_oklab,var(--neon)_45%,transparent)]" />
          </div>
          <p className="text-sm text-muted-foreground mb-4">
            A premier competitive bowling tournament. Compete · Strike · Win.
          </p>
          <div className="flex items-center gap-3">
            <a
              href={instagramUrl || "#"}
              target={instagramUrl && instagramUrl !== "#" ? "_blank" : undefined}
              rel="noopener noreferrer"
              aria-label="Instagram"
              className="p-2 rounded-md border border-border hover:border-neon hover:text-neon transition-colors"
            >
              <Instagram size={16} />
            </a>
          </div>
        </div>

        <div>
          <h4 className="font-display text-sm tracking-widest text-neon mb-3">Quick Links</h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li><Link to="/about" className="hover:text-foreground">About</Link></li>
            <li><Link to="/tournaments" className="hover:text-foreground">Tournaments</Link></li>
            <li><Link to="/sponsors" className="hover:text-foreground">Sponsors</Link></li>
            <li><Link to="/register" className="hover:text-foreground">Register</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="font-display text-sm tracking-widest text-neon mb-3">Policies</h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li><Link to="/rules" className="hover:text-foreground">Rules &amp; Regulations</Link></li>
            <li><Link to="/refund" className="hover:text-foreground">Refund Policy</Link></li>
            <li><Link to="/privacy" className="hover:text-foreground">Privacy Policy</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="font-display text-sm tracking-widest text-neon mb-3">Contact</h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li className="flex items-center gap-2"><Mail size={14} /><span>strikemasters.in@gmail.com</span></li>
            <li className="flex items-center gap-2"><Phone size={14} /><span>+91 95869 95356</span></li>
            <li className="flex items-center gap-2"><MapPin size={14} /><span>LaneX, AR Mall, Surat</span></li>
          </ul>

          <div className="mt-5 rounded-lg border border-gold/40 bg-card/60 p-3">
            <div className="text-[10px] uppercase tracking-widest text-gold mb-2">Official Venue Partner</div>
            <div className="flex items-center gap-2">
              <img src={lanex} alt="LaneX Bowling Alley logo" className="h-10 w-auto object-contain" />
              <span className="font-display text-sm tracking-wider text-gold">LaneX Bowling Alley</span>
            </div>
          </div>
        </div>
      </div>
      <div className="border-t border-border py-5 text-center text-xs text-muted-foreground">
        {copyright}
      </div>
    </footer>
  );
}
