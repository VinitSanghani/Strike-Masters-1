import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Mail, Phone, MapPin, User, MessageCircle, Loader2 } from "lucide-react";
import { SectionHeader } from "@/components/SectionHeader";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Strike Masters Bowling Tournament 2026" },
      { name: "description", content: "Get in touch with the Strike Masters tournament organizers. Email, phone, WhatsApp, and venue details." },
      { property: "og:title", content: "Contact Strike Masters" },
      { property: "og:description", content: "Reach out to our team — we're here to help." },
    ],
  }),
  component: ContactPage,
});

interface ContactContent {
  eyebrow: string;
  title: string;
  description: string;
  organizers_label: string;
  organizers_value: string;
  email_label: string;
  email_value: string;
  phone_label: string;
  phone_value: string;
  whatsapp_number: string;
  whatsapp_message: string;
  venue_label: string;
  venue_value: string;
  map_query: string;
}

function ContactPage() {
  const [data, setData] = useState<ContactContent | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const { data: row } = await (supabase as any)
        .from("contact_content")
        .select("eyebrow, title, description, organizers_label, organizers_value, email_label, email_value, phone_label, phone_value, whatsapp_number, whatsapp_message, venue_label, venue_value, map_query")
        .eq("id", 1)
        .maybeSingle();
      if (cancelled) return;
      setData(row as ContactContent | null);
      setLoading(false);
    })();
    return () => { cancelled = true; };
  }, []);

  if (loading || !data) {
    return (
      <div className="container mx-auto px-4 sm:px-6 py-20 text-center">
        <Loader2 className="w-8 h-8 mx-auto animate-spin text-neon" />
      </div>
    );
  }

  const phoneDigits = data.phone_value.replace(/[^\d+]/g, "");
  const items = [
    { icon: User, label: data.organizers_label, value: data.organizers_value, href: null as string | null },
    { icon: Mail, label: data.email_label, value: data.email_value, href: `mailto:${data.email_value}` },
    { icon: Phone, label: data.phone_label, value: data.phone_value, href: `tel:${phoneDigits}` },
    { icon: MapPin, label: data.venue_label, value: data.venue_value, href: null as string | null },
  ];

  return (
    <div className="container mx-auto px-4 sm:px-6 py-14 sm:py-20">
      <SectionHeader
        eyebrow={data.eyebrow}
        title={data.title}
        description={data.description}
      />

      <div className="grid lg:grid-cols-2 gap-8 max-w-5xl mx-auto">
        <div className="space-y-4">
          {items.map((it) => (
            <div
              key={it.label}
              className="flex items-start gap-4 rounded-xl border border-border bg-card/50 p-5 hover:border-neon transition-colors shadow-glow"
            >
              <div className="w-11 h-11 rounded-lg bg-gradient-to-br from-neon to-primary flex items-center justify-center shrink-0">
                <it.icon size={20} className="text-neon-foreground" />
              </div>
              <div>
                <div className="text-xs uppercase tracking-widest text-muted-foreground font-bold mb-1">
                  {it.label}
                </div>
                {it.href ? (
                  <a href={it.href} className="text-foreground hover:text-neon transition-colors">
                    {it.value}
                  </a>
                ) : (
                  <div className="text-foreground">{it.value}</div>
                )}
              </div>
            </div>
          ))}

          {data.whatsapp_number && (
            <a
              href={`https://wa.me/${data.whatsapp_number}?text=${encodeURIComponent(data.whatsapp_message)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-3 w-full px-5 py-4 rounded-xl bg-gradient-to-r from-[oklch(0.65_0.18_150)] to-[oklch(0.55_0.2_145)] text-white font-bold uppercase tracking-wider text-sm shadow-glow hover:scale-[1.02] transition-transform"
            >
              <MessageCircle size={18} /> Chat on WhatsApp
            </a>
          )}
        </div>

        <div className="rounded-xl overflow-hidden border border-border bg-card/50 min-h-[400px] shadow-glow">
          <iframe
            title="Venue location"
            src={`https://www.google.com/maps?q=${encodeURIComponent(data.map_query)}&output=embed`}
            className="w-full h-full min-h-[400px] grayscale contrast-125"
            loading="lazy"
          />
        </div>
      </div>
    </div>
  );
}
