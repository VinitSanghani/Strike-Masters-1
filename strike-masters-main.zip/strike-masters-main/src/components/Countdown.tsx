import { useEffect, useState } from "react";

interface CountdownProps {
  qualificationDate?: string | null;
  finalsDate?: string | null;
}

function nextTarget(qualification: number | null, finals: number | null) {
  const now = Date.now();
  if (qualification && now < qualification) return qualification;
  if (finals && now < finals) return finals;
  return null;
}

function calc(qualification: number | null, finals: number | null) {
  const target = nextTarget(qualification, finals);
  if (!target) return { days: 0, hours: 0, minutes: 0, seconds: 0, over: true };
  const diff = Math.max(0, target - Date.now());
  return {
    days: Math.floor(diff / 86400000),
    hours: Math.floor((diff / 3600000) % 24),
    minutes: Math.floor((diff / 60000) % 60),
    seconds: Math.floor((diff / 1000) % 60),
    over: diff === 0,
  };
}

export function Countdown({ qualificationDate, finalsDate }: CountdownProps = {}) {
  const qualification = qualificationDate ? new Date(qualificationDate).getTime() : null;
  const finals = finalsDate ? new Date(finalsDate).getTime() : null;
  const hasDates = Boolean(qualification || finals);

  const [t, setT] = useState<{ days: number; hours: number; minutes: number; seconds: number; over: boolean } | null>(null);

  useEffect(() => {
    if (!hasDates) {
      setT(null);
      return;
    }
    setT(calc(qualification, finals));
    const id = setInterval(() => setT(calc(qualification, finals)), 1000);
    return () => clearInterval(id);
  }, [qualification, finals, hasDates]);

  if (!hasDates) {
    return (
      <div className="text-center py-6">
        <div className="font-display text-2xl text-muted-foreground">Dates To Be Announced</div>
        <div className="text-[10px] uppercase tracking-widest text-muted-foreground mt-2">Schedule coming soon</div>
      </div>
    );
  }

  const items = [
    { label: "Days", value: t?.days ?? 0 },
    { label: "Hours", value: t?.hours ?? 0 },
    { label: "Minutes", value: t?.minutes ?? 0 },
    { label: "Seconds", value: t?.seconds ?? 0 },
  ];

  return (
    <div className="grid grid-cols-4 gap-2 sm:gap-3">
      {items.map((it) => (
        <div
          key={it.label}
          className="rounded-xl border border-border bg-card/60 backdrop-blur p-2 sm:p-3 text-center shadow-glow"
        >
          <div
            className="font-display text-2xl sm:text-3xl text-gradient-neon tabular-nums"
            suppressHydrationWarning
          >
            {String(it.value).padStart(2, "0")}
          </div>
          <div className="text-[9px] uppercase tracking-widest text-muted-foreground mt-1">
            {it.label}
          </div>
        </div>
      ))}
    </div>
  );
}
