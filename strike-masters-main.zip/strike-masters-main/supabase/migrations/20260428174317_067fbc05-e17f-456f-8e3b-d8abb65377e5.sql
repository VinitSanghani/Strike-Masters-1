CREATE TABLE public.sponsors_page (
  id integer PRIMARY KEY DEFAULT 1,
  -- Section header
  eyebrow text NOT NULL DEFAULT 'Our Partners',
  title text NOT NULL DEFAULT 'Powering The Tournament',
  description text NOT NULL DEFAULT 'Strike Masters 2026 is brought to life with our official partners. Meet the team making the event possible.',
  -- Featured venue partner card
  featured_enabled boolean NOT NULL DEFAULT true,
  featured_badge text NOT NULL DEFAULT 'Official Venue Partner',
  featured_name text NOT NULL DEFAULT 'LaneX Bowling Alley',
  featured_description text NOT NULL DEFAULT 'LaneX Bowling Alley is the official home of Strike Masters 2026. Located at AR Mall, Surat, LaneX provides tournament-spec lanes, electronic scoring, premium seating and a charged competition atmosphere.',
  featured_logo_url text,
  feature_1_label text NOT NULL DEFAULT 'Pro-Spec Lanes',
  feature_2_label text NOT NULL DEFAULT 'AR Mall, Surat',
  feature_3_label text NOT NULL DEFAULT '+91 95869 95356',
  -- CTA block at bottom
  cta_title text NOT NULL DEFAULT 'Partner With Strike Masters',
  cta_description text NOT NULL DEFAULT 'Sponsorship opportunities are open for brands that want to reach a passionate competitive sports audience. Get in touch to discuss title, prize, or category partnerships.',
  cta_button_label text NOT NULL DEFAULT 'Become a Sponsor',
  cta_button_email text NOT NULL DEFAULT 'strikemasters.in@gmail.com',
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  CONSTRAINT sponsors_page_singleton CHECK (id = 1)
);

INSERT INTO public.sponsors_page (id) VALUES (1) ON CONFLICT DO NOTHING;

ALTER TABLE public.sponsors_page ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Sponsors page publicly readable"
  ON public.sponsors_page FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Admins manage sponsors page"
  ON public.sponsors_page FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER sponsors_page_updated
  BEFORE UPDATE ON public.sponsors_page
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();