import { useEffect, useState } from "react";
import { Loader2, Plus, Trash2, Edit3, Save, X, Image as ImageIcon, ArrowUp, ArrowDown, ExternalLink, Eye, EyeOff } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export interface Sponsor {
  id: string;
  name: string;
  category: string;
  description: string | null;
  website_url: string | null;
  logo_url: string | null;
  sort_order: number;
  active: boolean;
  created_at: string;
}

const PRESET_CATEGORIES = [
  "Title Sponsor",
  "Venue Partner",
  "Co-Sponsor",
  "Partner Sponsor",
  "Prize Partner",
  "Media Partner",
];

export function SponsorsTab() {
  const [sponsors, setSponsors] = useState<Sponsor[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<Sponsor | null>(null);
  const [creating, setCreating] = useState(false);

  const refresh = async () => {
    const { data, error } = await supabase
      .from("sponsors")
      .select("*")
      .order("sort_order", { ascending: true })
      .order("created_at", { ascending: true });
    if (error) {
      toast.error(error.message);
      return;
    }
    setSponsors((data ?? []) as Sponsor[]);
    setLoading(false);
  };

  useEffect(() => { refresh(); }, []);

  const remove = async (s: Sponsor) => {
    if (!confirm(`Delete sponsor "${s.name}"? This cannot be undone.`)) return;
    // Best-effort: try to remove logo from storage
    if (s.logo_url) {
      const path = extractStoragePath(s.logo_url);
      if (path) await supabase.storage.from("sponsors").remove([path]);
    }
    const { error } = await supabase.from("sponsors").delete().eq("id", s.id);
    if (error) return toast.error(error.message);
    toast.success("Sponsor deleted");
    await refresh();
  };

  const toggleActive = async (s: Sponsor) => {
    const { error } = await supabase.from("sponsors").update({ active: !s.active }).eq("id", s.id);
    if (error) return toast.error(error.message);
    await refresh();
  };

  const move = async (s: Sponsor, dir: -1 | 1) => {
    const list = [...sponsors];
    const idx = list.findIndex((x) => x.id === s.id);
    const swap = list[idx + dir];
    if (!swap) return;
    const a = s.sort_order;
    const b = swap.sort_order;
    // If both have the same sort_order (e.g. all 0), assign sequentially first
    if (a === b) {
      const updates = list.map((it, i) => ({ id: it.id, sort_order: i * 10 }));
      for (const u of updates) {
        await supabase.from("sponsors").update({ sort_order: u.sort_order }).eq("id", u.id);
      }
      await refresh();
      return move({ ...s, sort_order: idx * 10 }, dir);
    }
    await Promise.all([
      supabase.from("sponsors").update({ sort_order: b }).eq("id", s.id),
      supabase.from("sponsors").update({ sort_order: a }).eq("id", swap.id),
    ]);
    await refresh();
  };

  if (loading) {
    return <div className="text-center py-12"><Loader2 className="w-6 h-6 mx-auto animate-spin text-neon" /></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h3 className="font-display text-xl text-neon">Sponsors & Partners</h3>
          <p className="text-xs text-muted-foreground mt-1">Manage sponsors that appear on the public Sponsors page.</p>
        </div>
        <button
          onClick={() => setCreating(true)}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground text-xs uppercase tracking-wider font-bold shadow-neon"
        >
          <Plus size={14} /> Add Sponsor
        </button>
      </div>

      {sponsors.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border bg-card/40 p-10 text-center">
          <ImageIcon className="w-10 h-10 mx-auto text-muted-foreground mb-2" />
          <p className="text-sm text-muted-foreground">No sponsors yet. Click "Add Sponsor" to create the first one.</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {sponsors.map((s, i) => (
            <div key={s.id} className={`rounded-xl border bg-card/60 shadow-glow overflow-hidden ${s.active ? "border-border" : "border-border/40 opacity-60"}`}>
              <div className="aspect-[16/9] bg-background/60 flex items-center justify-center p-4 border-b border-border">
                {s.logo_url ? (
                  <img src={s.logo_url} alt={s.name} className="max-h-full max-w-full object-contain" loading="lazy" />
                ) : (
                  <ImageIcon className="w-10 h-10 text-muted-foreground" />
                )}
              </div>
              <div className="p-4">
                <div className="flex items-start justify-between gap-2 mb-1">
                  <h4 className="font-display text-base">{s.name}</h4>
                  <span className="text-[10px] uppercase tracking-widest text-neon font-bold border border-neon/40 rounded px-2 py-0.5 shrink-0">{s.category}</span>
                </div>
                {s.description && <p className="text-xs text-muted-foreground line-clamp-2 mb-2">{s.description}</p>}
                {s.website_url && (
                  <a href={s.website_url} target="_blank" rel="noopener noreferrer" className="text-xs text-neon inline-flex items-center gap-1 mb-2">
                    <ExternalLink size={11} /> Website
                  </a>
                )}
                <div className="mt-3 pt-3 border-t border-border flex items-center justify-between gap-2">
                  <div className="flex gap-1">
                    <button onClick={() => move(s, -1)} disabled={i === 0} className="p-1.5 rounded text-muted-foreground hover:text-neon hover:bg-neon/10 disabled:opacity-30" title="Move up">
                      <ArrowUp size={14} />
                    </button>
                    <button onClick={() => move(s, 1)} disabled={i === sponsors.length - 1} className="p-1.5 rounded text-muted-foreground hover:text-neon hover:bg-neon/10 disabled:opacity-30" title="Move down">
                      <ArrowDown size={14} />
                    </button>
                  </div>
                  <div className="flex gap-1">
                    <button onClick={() => toggleActive(s)} className="p-1.5 rounded text-muted-foreground hover:text-neon hover:bg-neon/10" title={s.active ? "Hide from public" : "Show on public site"}>
                      {s.active ? <Eye size={14} /> : <EyeOff size={14} />}
                    </button>
                    <button onClick={() => setEditing(s)} className="p-1.5 rounded text-neon hover:bg-neon/10" title="Edit">
                      <Edit3 size={14} />
                    </button>
                    <button onClick={() => remove(s)} className="p-1.5 rounded text-destructive hover:bg-destructive/10" title="Delete">
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {(creating || editing) && (
        <SponsorModal
          sponsor={editing}
          nextSortOrder={sponsors.length * 10}
          onClose={() => { setCreating(false); setEditing(null); }}
          onSaved={async () => { setCreating(false); setEditing(null); await refresh(); }}
        />
      )}
    </div>
  );
}

function extractStoragePath(publicUrl: string): string | null {
  // Public URL format: <project>/storage/v1/object/public/sponsors/<path>
  const m = publicUrl.match(/\/object\/public\/sponsors\/(.+)$/);
  return m ? decodeURIComponent(m[1]) : null;
}

function SponsorModal({
  sponsor,
  nextSortOrder,
  onClose,
  onSaved,
}: {
  sponsor: Sponsor | null;
  nextSortOrder: number;
  onClose: () => void;
  onSaved: () => Promise<void>;
}) {
  const [form, setForm] = useState({
    name: sponsor?.name ?? "",
    category: sponsor?.category ?? "Co-Sponsor",
    description: sponsor?.description ?? "",
    website_url: sponsor?.website_url ?? "",
    active: sponsor?.active ?? true,
    sort_order: sponsor?.sort_order ?? nextSortOrder,
  });
  const [logoUrl, setLogoUrl] = useState<string | null>(sponsor?.logo_url ?? null);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);

  const onLogoChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 2_000_000) {
      toast.error("Logo must be smaller than 2 MB");
      return;
    }
    setUploading(true);
    const ext = file.name.split(".").pop()?.toLowerCase() || "png";
    const path = `${crypto.randomUUID()}.${ext}`;
    const { error: upErr } = await supabase.storage.from("sponsors").upload(path, file, {
      cacheControl: "3600",
      upsert: false,
      contentType: file.type,
    });
    setUploading(false);
    if (upErr) {
      toast.error(upErr.message);
      return;
    }
    const { data } = supabase.storage.from("sponsors").getPublicUrl(path);
    setLogoUrl(data.publicUrl);
    toast.success("Logo uploaded");
  };

  const save = async () => {
    if (!form.name.trim() || !form.category.trim()) {
      toast.error("Name and category are required");
      return;
    }
    setSaving(true);
    const payload = {
      name: form.name.trim(),
      category: form.category.trim(),
      description: form.description.trim() || null,
      website_url: form.website_url.trim() || null,
      logo_url: logoUrl,
      active: form.active,
      sort_order: form.sort_order,
    };
    const { error } = sponsor
      ? await supabase.from("sponsors").update(payload).eq("id", sponsor.id)
      : await supabase.from("sponsors").insert(payload);
    setSaving(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(sponsor ? "Sponsor updated" : "Sponsor added");
    await onSaved();
  };

  const inputCls = "w-full px-3 py-2 rounded-md bg-input/60 border border-border text-sm focus:border-neon focus:outline-none";
  const labelCls = "block text-[10px] uppercase tracking-widest text-muted-foreground mb-1";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur" onClick={onClose}>
      <div className="w-full max-w-2xl rounded-2xl border border-border bg-card p-6 shadow-glow max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display text-xl text-neon">{sponsor ? "Edit Sponsor" : "Add Sponsor"}</h3>
          <button onClick={onClose} className="p-2 hover:bg-accent rounded"><X size={16} /></button>
        </div>

        {/* Logo */}
        <div className="mb-4">
          <label className={labelCls}>Logo</label>
          <div className="flex items-start gap-4">
            <div className="w-32 h-32 rounded-md border border-border bg-background/60 flex items-center justify-center overflow-hidden shrink-0">
              {logoUrl ? (
                <img src={logoUrl} alt="Logo preview" className="max-h-full max-w-full object-contain" />
              ) : (
                <ImageIcon className="w-8 h-8 text-muted-foreground" />
              )}
            </div>
            <div className="flex-1">
              <input
                type="file"
                accept="image/png,image/jpeg,image/webp,image/svg+xml"
                onChange={onLogoChange}
                disabled={uploading}
                className="block w-full text-xs file:mr-3 file:py-2 file:px-4 file:rounded-md file:border-0 file:bg-neon file:text-neon-foreground file:font-bold file:text-xs file:uppercase file:tracking-wider file:cursor-pointer"
              />
              <p className="text-[11px] text-muted-foreground mt-2">PNG, JPG, WEBP or SVG. Max 2 MB. Transparent backgrounds look best.</p>
              {uploading && <p className="text-xs text-neon mt-1 inline-flex items-center gap-1"><Loader2 size={12} className="animate-spin" /> Uploading…</p>}
              {logoUrl && (
                <button onClick={() => setLogoUrl(null)} className="text-[11px] text-destructive mt-1 underline">Remove logo</button>
              )}
            </div>
          </div>
        </div>

        <div className="grid sm:grid-cols-2 gap-3">
          <div>
            <label className={labelCls}>Sponsor Name *</label>
            <input className={inputCls} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Acme Corp" />
          </div>
          <div>
            <label className={labelCls}>Category / Title *</label>
            <input
              className={inputCls}
              value={form.category}
              onChange={(e) => setForm({ ...form, category: e.target.value })}
              list="sponsor-categories"
              placeholder="Title Sponsor"
            />
            <datalist id="sponsor-categories">
              {PRESET_CATEGORIES.map((c) => <option key={c} value={c} />)}
            </datalist>
          </div>
          <div className="sm:col-span-2">
            <label className={labelCls}>Website / Social Link</label>
            <input className={inputCls} value={form.website_url} onChange={(e) => setForm({ ...form, website_url: e.target.value })} placeholder="https://…" />
          </div>
          <div className="sm:col-span-2">
            <label className={labelCls}>Short Description (optional)</label>
            <textarea rows={3} className={inputCls} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="One or two sentences about the sponsor." />
          </div>
          <div>
            <label className={labelCls}>Sort Order</label>
            <input type="number" className={inputCls} value={form.sort_order} onChange={(e) => setForm({ ...form, sort_order: parseInt(e.target.value) || 0 })} />
          </div>
          <label className="flex items-center gap-2 text-sm mt-6">
            <input type="checkbox" checked={form.active} onChange={(e) => setForm({ ...form, active: e.target.checked })} />
            Active (visible on public site)
          </label>
        </div>

        <div className="mt-5 flex justify-end gap-2">
          <button onClick={onClose} className="px-4 py-2 rounded-md border border-border text-xs uppercase tracking-wider font-bold">Cancel</button>
          <button onClick={save} disabled={saving || uploading} className="inline-flex items-center gap-2 px-4 py-2 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground text-xs uppercase tracking-wider font-bold disabled:opacity-50">
            {saving && <Loader2 size={14} className="animate-spin" />}
            <Save size={14} /> {sponsor ? "Save Changes" : "Add Sponsor"}
          </button>
        </div>
      </div>
    </div>
  );
}
