import { useEffect, useMemo, useState } from "react";
import { Loader2, CheckCircle2, XCircle, Eye, Clock, Banknote, Smartphone, ExternalLink } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { adminUpdatePaymentStatus, getPaymentProofSignedUrl } from "@/server/razorpay.functions";
import { formatDateDMY, formatDateTimeDMY } from "@/lib/format-date";

interface PendingReg {
  id: string;
  team_name: string;
  captain_name: string;
  captain_email: string;
  captain_phone: string;
  payment_method: string;
  payment_status: string;
  payment_proof_url: string | null;
  upi_transaction_ref: string | null;
  amount_paid: number | null;
  cash_payment_deadline?: string | null;
  tournament_id: string | null;
  created_at: string;
  verification_notes: string | null;
}

interface TournamentInfo { id: string; name: string; cash_payment_deadline: string | null; }

export function PaymentVerificationTab() {
  const [items, setItems] = useState<PendingReg[]>([]);
  const [tournaments, setTournaments] = useState<Record<string, TournamentInfo>>({});
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<"all" | "awaiting_verification" | "pending" | "rejected">("awaiting_verification");
  const [tournamentFilter, setTournamentFilter] = useState<string>("all");
  const [proofModal, setProofModal] = useState<{ id: string; url: string | null; loading: boolean } | null>(null);
  const [actionModal, setActionModal] = useState<{ reg: PendingReg; action: "verify" | "reject" } | null>(null);
  const [notes, setNotes] = useState("");
  const [busy, setBusy] = useState(false);

  const refresh = async () => {
    const [{ data: regs }, { data: tns }] = await Promise.all([
      supabase
        .from("registrations")
        .select("id, team_name, captain_name, captain_email, captain_phone, payment_method, payment_status, payment_proof_url, upi_transaction_ref, amount_paid, tournament_id, created_at, verification_notes")
        .in("payment_status", ["awaiting_verification", "pending", "rejected"])
        .order("created_at", { ascending: false }),
      supabase.from("tournaments").select("id, name, cash_payment_deadline"),
    ]);
    setItems((regs ?? []) as PendingReg[]);
    const map: Record<string, TournamentInfo> = {};
    for (const t of (tns ?? []) as TournamentInfo[]) map[t.id] = t;
    setTournaments(map);
    setLoading(false);
  };

  useEffect(() => { refresh(); }, []);

  const filtered = useMemo(() => items.filter((r) => {
    if (filter !== "all" && r.payment_status !== filter) return false;
    if (tournamentFilter !== "all" && r.tournament_id !== tournamentFilter) return false;
    return true;
  }), [items, filter, tournamentFilter]);

  const counts = useMemo(() => ({
    awaiting: items.filter((r) => r.payment_status === "awaiting_verification").length,
    pending: items.filter((r) => r.payment_status === "pending").length,
    rejected: items.filter((r) => r.payment_status === "rejected").length,
  }), [items]);

  const viewProof = async (id: string) => {
    setProofModal({ id, url: null, loading: true });
    try {
      const { url } = await getPaymentProofSignedUrl({ data: { registrationId: id } });
      setProofModal({ id, url, loading: false });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Failed to load proof");
      setProofModal(null);
    }
  };

  const submitAction = async () => {
    if (!actionModal) return;
    setBusy(true);
    try {
      await adminUpdatePaymentStatus({
        data: { registrationId: actionModal.reg.id, action: actionModal.action, notes: notes || null },
      });
      toast.success(actionModal.action === "verify" ? "Payment verified ✓" : "Payment rejected — user notified");
      setActionModal(null);
      setNotes("");
      await refresh();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Action failed");
    } finally {
      setBusy(false);
    }
  };

  if (loading) return <div className="text-center py-12"><Loader2 className="w-6 h-6 mx-auto animate-spin text-neon" /></div>;

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-3 gap-3">
        <StatTile label="Awaiting (UPI)" value={counts.awaiting} accent="amber" icon={<Smartphone size={14} />} />
        <StatTile label="Pending Cash" value={counts.pending} accent="amber" icon={<Banknote size={14} />} />
        <StatTile label="Rejected" value={counts.rejected} accent="destructive" icon={<XCircle size={14} />} />
      </div>

      <div className="flex flex-wrap gap-3">
        <select value={filter} onChange={(e) => setFilter(e.target.value as typeof filter)} className="px-3 py-2 rounded-md bg-input/60 border border-border text-sm">
          <option value="awaiting_verification">UPI awaiting verification</option>
          <option value="pending">Pending cash</option>
          <option value="rejected">Rejected</option>
          <option value="all">All unverified</option>
        </select>
        <select value={tournamentFilter} onChange={(e) => setTournamentFilter(e.target.value)} className="px-3 py-2 rounded-md bg-input/60 border border-border text-sm">
          <option value="all">All tournaments</option>
          {Object.values(tournaments).map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
        </select>
      </div>

      {filtered.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border bg-card/40 p-10 text-center text-sm text-muted-foreground">
          <CheckCircle2 className="w-10 h-10 mx-auto text-success mb-2" /> Nothing to review.
        </div>
      ) : (
        <div className="rounded-2xl border border-border bg-card/40 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-card/80 text-left text-[10px] uppercase tracking-widest text-muted-foreground">
                <tr>
                  <th className="px-4 py-3">Team / Entry</th>
                  <th className="px-4 py-3">Tournament</th>
                  <th className="px-4 py-3">Method</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3">UTR</th>
                  <th className="px-4 py-3">Submitted</th>
                  <th className="px-4 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filtered.map((r) => {
                  const t = r.tournament_id ? tournaments[r.tournament_id] : null;
                  const isUpi = r.payment_method === "upi_qr";
                  return (
                    <tr key={r.id} className="hover:bg-accent/40">
                      <td className="px-4 py-3">
                        <div className="font-display">{r.team_name}</div>
                        <div className="text-xs text-muted-foreground">{r.captain_name} · {r.captain_email}</div>
                      </td>
                      <td className="px-4 py-3 text-xs">{t?.name ?? "—"}</td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex items-center gap-1 px-2 py-1 rounded text-[10px] uppercase tracking-wider font-bold border ${isUpi ? "border-neon/40 text-neon" : "border-amber-400/40 text-amber-400"}`}>
                          {isUpi ? <Smartphone size={10} /> : <Banknote size={10} />}
                          {isUpi ? "UPI/QR" : "Cash"}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex items-center gap-1 px-2 py-1 rounded text-[10px] uppercase tracking-wider font-bold border ${
                          r.payment_status === "awaiting_verification" ? "border-amber-400/40 text-amber-400" :
                          r.payment_status === "rejected" ? "border-destructive/40 text-destructive" :
                          "border-amber-400/40 text-amber-400"
                        }`}>
                          {r.payment_status === "awaiting_verification" ? <Clock size={10} /> : r.payment_status === "rejected" ? <XCircle size={10} /> : <Clock size={10} />}
                          {r.payment_status.replace("_", " ")}
                        </span>
                        {r.verification_notes && (
                          <div className="text-[10px] text-destructive mt-1 max-w-[200px]">{r.verification_notes}</div>
                        )}
                      </td>
                      <td className="px-4 py-3 text-xs font-mono">{r.upi_transaction_ref || "—"}</td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{formatDateDMY(r.created_at)}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center justify-end gap-1">
                          {isUpi && r.payment_proof_url && (
                            <button onClick={() => viewProof(r.id)} className="p-1.5 rounded text-neon hover:bg-neon/10" title="View Proof">
                              <Eye size={14} />
                            </button>
                          )}
                          <button onClick={() => { setActionModal({ reg: r, action: "verify" }); setNotes(""); }} className="p-1.5 rounded text-success hover:bg-success/10" title="Approve">
                            <CheckCircle2 size={14} />
                          </button>
                          <button onClick={() => { setActionModal({ reg: r, action: "reject" }); setNotes(""); }} className="p-1.5 rounded text-destructive hover:bg-destructive/10" title="Reject">
                            <XCircle size={14} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {proofModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur" onClick={() => setProofModal(null)}>
          <div className="max-w-2xl w-full rounded-2xl border border-border bg-card p-6 shadow-glow max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display text-lg text-neon">Payment Proof</h3>
              <button onClick={() => setProofModal(null)} className="p-2 hover:bg-accent rounded"><XCircle size={16} /></button>
            </div>
            {proofModal.loading ? (
              <div className="text-center py-12"><Loader2 className="w-6 h-6 mx-auto animate-spin text-neon" /></div>
            ) : proofModal.url ? (
              <>
                <img src={proofModal.url} alt="Payment proof" className="w-full rounded-md border border-border" />
                <a href={proofModal.url} target="_blank" rel="noreferrer" className="mt-3 inline-flex items-center gap-1 text-xs text-neon hover:underline">
                  Open in new tab <ExternalLink size={12} />
                </a>
              </>
            ) : (
              <p className="text-sm text-muted-foreground">No proof uploaded.</p>
            )}
          </div>
        </div>
      )}

      {actionModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur" onClick={() => setActionModal(null)}>
          <div className="max-w-md w-full rounded-2xl border border-border bg-card p-6 shadow-glow" onClick={(e) => e.stopPropagation()}>
            <h3 className="font-display text-lg mb-2">
              {actionModal.action === "verify" ? "Verify Payment" : "Reject Payment"}
            </h3>
            <p className="text-xs text-muted-foreground mb-4">
              <span className="text-neon font-bold">{actionModal.reg.team_name}</span> — {actionModal.reg.captain_email}
            </p>
            <label className="block text-[10px] uppercase tracking-widest text-muted-foreground mb-1">
              {actionModal.action === "verify" ? "Notes (optional)" : "Reason (shown to user)"}
            </label>
            <textarea rows={3} value={notes} onChange={(e) => setNotes(e.target.value)}
              placeholder={actionModal.action === "verify" ? "Optional internal note" : "e.g. Screenshot is unclear, please re-upload."}
              className="w-full px-3 py-2 rounded-md bg-input/60 border border-border text-sm focus:border-neon focus:outline-none mb-4" />
            <div className="flex justify-end gap-2">
              <button onClick={() => setActionModal(null)} className="px-4 py-2 rounded-md border border-border text-xs uppercase tracking-wider font-bold">Cancel</button>
              <button onClick={submitAction} disabled={busy}
                className={`inline-flex items-center gap-2 px-4 py-2 rounded-md text-xs uppercase tracking-wider font-bold disabled:opacity-50 ${actionModal.action === "verify" ? "bg-success text-background" : "bg-destructive text-destructive-foreground"}`}>
                {busy && <Loader2 size={14} className="animate-spin" />}
                {actionModal.action === "verify" ? "Confirm Verify" : "Confirm Reject"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function StatTile({ icon, label, value, accent }: { icon: React.ReactNode; label: string; value: number; accent: string }) {
  const cls = accent === "amber" ? "text-amber-400" : accent === "destructive" ? "text-destructive" : "text-neon";
  return (
    <div className="rounded-xl border border-border bg-card/60 p-4 shadow-glow">
      <div className={`flex items-center gap-1.5 ${cls} text-[10px] uppercase tracking-widest mb-1`}>{icon} {label}</div>
      <div className="font-display text-2xl">{value}</div>
    </div>
  );
}
