import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  Calendar, MapPin, Trophy, Users, Loader2, ArrowRight,
  Clock, IndianRupee, ShieldCheck, ChevronDown, Layers, Crown, CheckCircle2, Circle, User as UserIcon, Medal, Award,
  Image as ImageIcon, X as XIcon,
} from "lucide-react";
import { SectionHeader } from "@/components/SectionHeader";
import { supabase } from "@/integrations/supabase/client";
import { formatDateDMY, formatDateTimeDMY } from "@/lib/format-date";
import { Countdown } from "@/components/Countdown";
import { getRegistrationWindowState, registrationWindowMessage } from "@/lib/registration-window";
import { TournamentSponsorsStrip } from "@/components/TournamentSponsorsStrip";

export const Route = createFileRoute("/tournaments/$slug")({
  head: () => ({
    meta: [
      { title: "Tournament — Strike Masters" },
      { name: "description", content: "Tournament details, schedule, prizes, and FAQs." },
    ],
  }),
  component: TournamentDetailPage,
});

interface Tournament {
  id: string;
  slug: string;
  name: string;
  subtitle: string | null;
  description: string | null;
  rules: string | null;
  banner_url: string | null;
  venue: string | null;
  qualification_date: string | null;
  finals_date: string | null;
  registration_deadline: string | null;
  registration_open: boolean;
  registration_open_date: string | null;
  registration_close_date: string | null;
  registration_fee: number;
  early_bird_fee: number | null;
  early_bird_until: string | null;
  prize_pool: string;
  prize_pool_amount: number | null;
  max_teams: number | null;
  team_size: number;
  status: string;
  tournament_type: string;
  number_of_winners: number;
  payment_methods: string[];
}

interface Prize { id: string; rank_label: string; title: string; description: string | null; value: string | null; }
interface IndividualAward { id: string; title: string; description: string | null; amount: number | null; }
interface ScheduleItem { id: string; day_label: string; time_label: string | null; title: string; description: string | null; }
interface Faq { id: string; question: string; answer: string; }
interface Round {
  id: string; name: string; description: string | null; status: string;
  scheduled_at: string | null; participants_advancing: number | null; selection_criteria: string | null;
}
interface Winner {
  id: string; place: number; place_label: string;
  prize_title: string | null; prize_amount: number | null;
  registration_id: string | null;
}
interface WinnerReg { id: string; team_name: string; captain_name: string; }
interface RoundScore {
  id: string; round_id: string; registration_id: string;
  score: number | null; position: number | null; advanced: boolean;
}
interface ScoreReg { id: string; team_name: string; captain_name: string; }
interface GalleryImg { id: string; image_url: string; caption: string | null; }

function TournamentDetailPage() {
  const { slug } = Route.useParams();
  const navigate = useNavigate();
  const [tournament, setTournament] = useState<Tournament | null>(null);
  const [prizes, setPrizes] = useState<Prize[]>([]);
  const [awards, setAwards] = useState<IndividualAward[]>([]);
  const [schedule, setSchedule] = useState<ScheduleItem[]>([]);
  const [faqs, setFaqs] = useState<Faq[]>([]);
  const [rounds, setRounds] = useState<Round[]>([]);
  const [winners, setWinners] = useState<Winner[]>([]);
  const [winnerRegs, setWinnerRegs] = useState<WinnerReg[]>([]);
  const [roundScores, setRoundScores] = useState<RoundScore[]>([]);
  const [scoreRegs, setScoreRegs] = useState<ScoreReg[]>([]);
  const [registrations, setRegistrations] = useState<number>(0);
  const [gallery, setGallery] = useState<GalleryImg[]>([]);
  const [lightbox, setLightbox] = useState<GalleryImg | null>(null);
  const [loading, setLoading] = useState(true);
  const [openFaq, setOpenFaq] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      setLoading(true);
      const { data: t } = await supabase
        .from("tournaments")
        .select("*")
        .eq("slug", slug)
        .maybeSingle();

      if (cancelled) return;
      if (!t) {
        setTournament(null);
        setLoading(false);
        return;
      }
      setTournament(t as Tournament);

      const [pRes, sRes, fRes, rRes, roundsRes, winnersRes, awardsRes] = await Promise.all([
        supabase.from("tournament_prizes").select("*").eq("tournament_id", t.id).order("sort_order"),
        supabase.from("tournament_schedule").select("*").eq("tournament_id", t.id).order("sort_order"),
        supabase.from("tournament_faqs").select("*").eq("tournament_id", t.id).order("sort_order"),
        supabase.from("registrations").select("id", { count: "exact", head: true }).eq("tournament_id", t.id).eq("payment_status", "verified"),
        supabase.from("tournament_rounds").select("id, name, description, status, scheduled_at, participants_advancing, selection_criteria").eq("tournament_id", t.id).order("sort_order"),
        supabase.from("tournament_winners").select("id, place, place_label, prize_title, prize_amount, registration_id").eq("tournament_id", t.id).order("place"),
        (supabase as any).from("tournament_individual_awards").select("id, title, description, amount, active, sort_order").eq("tournament_id", t.id).eq("active", true).order("sort_order"),
      ]);

      if (cancelled) return;
      setPrizes((pRes.data ?? []) as Prize[]);
      setAwards(((awardsRes as any).data ?? []) as IndividualAward[]);
      setSchedule((sRes.data ?? []) as ScheduleItem[]);
      setFaqs((fRes.data ?? []) as Faq[]);
      setRegistrations(rRes.count ?? 0);
      setRounds((roundsRes.data ?? []) as Round[]);
      const winnersList = (winnersRes.data ?? []) as Winner[];
      setWinners(winnersList);

      // Fetch scores only for in_progress / completed rounds
      const visibleRounds = ((roundsRes.data ?? []) as Round[]).filter(
        (r) => r.status === "in_progress" || r.status === "completed"
      );
      let scores: RoundScore[] = [];
      if (visibleRounds.length) {
        const { data: scoresData } = await supabase
          .from("round_scores")
          .select("id, round_id, registration_id, score, position, advanced")
          .in("round_id", visibleRounds.map((r) => r.id));
        scores = (scoresData ?? []) as RoundScore[];
        setRoundScores(scores);
      } else {
        setRoundScores([]);
      }

      // Public lookup of team/captain names (RLS-safe via SECURITY DEFINER RPC)
      const needsRegs =
        winnersList.some((w) => w.registration_id) || scores.length > 0;
      if (needsRegs) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const { data: pubRegs } = await (supabase as any).rpc("get_public_registrations", { _tournament_id: t.id });
        const regsList = (pubRegs ?? []) as { id: string; team_name: string; captain_name: string }[];
        setWinnerRegs(regsList as WinnerReg[]);
        setScoreRegs(regsList as ScoreReg[]);
      } else {
        setWinnerRegs([]);
        setScoreRegs([]);
      }
      // Tournament gallery (active images tagged to this tournament)
      const { data: galleryData } = await supabase
        .from("gallery_images")
        .select("id, image_url, caption")
        .eq("tournament_id", t.id)
        .eq("active", true)
        .order("sort_order", { ascending: true })
        .order("created_at", { ascending: false });
      if (!cancelled) setGallery((galleryData ?? []) as GalleryImg[]);

      setLoading(false);
    };
    load();
    return () => { cancelled = true; };
  }, [slug]);

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-32 text-center">
        <Loader2 className="w-8 h-8 mx-auto animate-spin text-neon" />
      </div>
    );
  }

  if (!tournament) {
    return (
      <div className="container mx-auto px-4 py-32 text-center max-w-md">
        <Trophy className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
        <h1 className="font-display text-2xl mb-2">Tournament Not Found</h1>
        <p className="text-sm text-muted-foreground mb-6">We couldn't find a tournament with that link.</p>
        <Link to="/tournaments" className="inline-flex items-center gap-2 px-5 py-3 rounded-md border border-border hover:border-neon text-xs uppercase tracking-wider font-bold">
          Browse All Tournaments
        </Link>
      </div>
    );
  }

  const slotsLeft = tournament.max_teams ? Math.max(0, tournament.max_teams - registrations) : null;
  const windowState = getRegistrationWindowState(tournament);
  const soldOut = slotsLeft !== null && slotsLeft <= 0;
  const canRegister = windowState === "open" && !soldOut;
  const closedLabel = soldOut ? "Sold Out" : registrationWindowMessage(windowState) || "Registration Closed";

  return (
    <div>
      {/* HERO */}
      <section className="relative min-h-[60vh] flex items-end overflow-hidden">
        <div className="absolute inset-0">
          {tournament.banner_url ? (
            <img src={tournament.banner_url} alt={tournament.name} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-card via-primary/20 to-background" />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/85 to-background/40" />
        </div>
        <div className="relative container mx-auto px-4 sm:px-6 py-16 sm:py-24">
          <div className="max-w-3xl animate-[fade-up_0.8s_ease-out]">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-neon/40 bg-neon/10 text-neon text-xs font-bold uppercase tracking-widest mb-5">
              {tournament.status} · {tournament.qualification_date ? formatDateDMY(tournament.qualification_date) : "Dates TBA"}
            </div>
            <h1 className="font-display text-4xl sm:text-6xl md:text-7xl leading-[0.95] mb-4">
              <span className="text-gradient-neon">{tournament.name}</span>
            </h1>
            {tournament.subtitle && <p className="text-lg text-muted-foreground mb-6 max-w-2xl">{tournament.subtitle}</p>}
            <div className="flex flex-wrap gap-3 mb-8 text-sm">
              {tournament.qualification_date && (
                <div className="inline-flex items-center gap-2 px-3 py-2 rounded-md border border-border bg-card/60">
                  <Calendar size={14} className="text-neon" /> Qualification: {formatDateDMY(tournament.qualification_date)}
                </div>
              )}
              {tournament.finals_date && (
                <div className="inline-flex items-center gap-2 px-3 py-2 rounded-md border border-border bg-card/60">
                  <Trophy size={14} className="text-neon" /> Finals: {formatDateDMY(tournament.finals_date)}
                </div>
              )}
              {tournament.venue && (
                <div className="inline-flex items-center gap-2 px-3 py-2 rounded-md border border-border bg-card/60">
                  <MapPin size={14} className="text-neon" /> {tournament.venue}
                </div>
              )}
            </div>
            {(tournament.qualification_date || tournament.finals_date) && tournament.status !== "completed" && tournament.status !== "archived" && (
              <div className="max-w-md mb-8 rounded-2xl border border-border bg-card/60 backdrop-blur-md p-5 shadow-glow">
                <div className="text-center text-[10px] uppercase tracking-widest text-neon font-bold mb-4">Tournament Starts In</div>
                <Countdown qualificationDate={tournament.qualification_date} finalsDate={tournament.finals_date} />
              </div>
            )}
            <div className="flex flex-wrap gap-3">
              {canRegister ? (
                <button
                  onClick={() => navigate({ to: "/register", search: { t: tournament.slug } as never })}
                  className="group inline-flex items-center gap-2 px-7 py-4 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground font-bold uppercase tracking-wider shadow-neon hover:scale-105 transition-transform"
                >
                  Register Now <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
                </button>
              ) : (
                <div className="inline-flex items-center gap-2 px-7 py-4 rounded-md border border-border bg-card/60 text-muted-foreground font-bold uppercase tracking-wider">
                  {closedLabel}
                  {windowState === "not_yet_open" && tournament.registration_open_date && (
                    <span className="ml-2 text-neon normal-case tracking-normal font-medium">
                      · {formatDateDMY(tournament.registration_open_date)}
                    </span>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* When completed, show winners + final rounds & scores */}
      {tournament.status === "completed" && (
        <>
        {winners.length > 0 ? (
          <section className="container mx-auto px-4 sm:px-6 py-12">
            <SectionHeader
              eyebrow="Champions"
              title="Tournament Winners"
              description="The teams who took home the trophies."
            />
            {(() => {
              const byPlace = (n: number) => winners.find((w) => w.place === n);
              const first = byPlace(1);
              const second = byPlace(2);
              const third = byPlace(3);
              // Mobile: 1st, 2nd, 3rd (top→bottom). Desktop: 2nd, 1st, 3rd (podium) via order classes.
              const ordered = [first, second, third];
              const desktopOrder = (place: number) =>
                place === 1 ? "md:order-2" : place === 2 ? "md:order-1" : "md:order-3";
              const accent = (place: number) =>
                place === 1
                  ? { border: "border-gold/60", glow: "shadow-[0_0_60px_-15px_hsl(var(--gold)/0.6)]", text: "text-gold", label: "CHAMPION", Icon: Trophy }
                  : place === 2
                  ? { border: "border-silver/40", glow: "", text: "text-silver", label: "RUNNER-UP", Icon: Medal }
                  : { border: "border-bronze/40", glow: "", text: "text-bronze", label: "BRONZE", Icon: Award };

              return (
                <div className="grid md:grid-cols-3 gap-4 sm:gap-6 max-w-5xl mx-auto items-stretch">
                  {ordered.map((w, i) => {
                    if (!w) return <div key={i} className="hidden md:block" />;
                    const reg = winnerRegs.find((r) => r.id === w.registration_id);
                    const a = accent(w.place);
                    const isFirst = w.place === 1;
                    return (
                      <div
                        key={w.id}
                        className={`relative rounded-2xl border-2 ${a.border} bg-card/60 p-6 sm:p-8 text-center flex flex-col ${a.glow} ${desktopOrder(w.place)} ${isFirst ? "md:-translate-y-4 md:scale-105" : ""}`}
                      >
                        <a.Icon size={isFirst ? 44 : 36} className={`${a.text} mx-auto mb-4`} />
                        <div className={`font-display text-5xl sm:text-6xl ${a.text} leading-none`}>
                          {w.place === 1 ? "1st" : w.place === 2 ? "2nd" : "3rd"}
                        </div>
                        <div className="text-[10px] tracking-[0.25em] text-muted-foreground mt-2 mb-4">{a.label}</div>
                        <div className="text-neon font-display text-lg mb-4">
                          {w.prize_title || (w.prize_amount != null ? `₹${w.prize_amount.toLocaleString("en-IN")}` : "Prize")}
                        </div>
                        <div className="border-t border-border/60 pt-4 mt-auto text-left text-sm">
                          {reg ? (
                            <>
                              <div className="font-display text-base mb-1">{reg.team_name}</div>
                              <div className="text-xs text-muted-foreground">Captain: {reg.captain_name}</div>
                            </>
                          ) : (
                            <div className="text-xs text-muted-foreground italic text-center">Winner TBA</div>
                          )}
                          {w.prize_amount != null && (
                            <div className={`mt-3 font-display text-xl ${a.text}`}>
                              ₹{w.prize_amount.toLocaleString("en-IN")}
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              );
            })()}
          </section>
        ) : (
          <section className="container mx-auto px-4 sm:px-6 py-20 text-center">
            <Crown size={40} className="mx-auto text-gold mb-3" />
            <h2 className="font-display text-2xl mb-2">Winners Coming Soon</h2>
            <p className="text-sm text-muted-foreground">Results will be posted here shortly.</p>
          </section>
        )}

        {/* Final Rounds & Scores for completed tournaments */}
        {rounds.length > 0 && (
          <section className="container mx-auto px-4 sm:px-6 py-12">
            <SectionHeader eyebrow="Results" title="Rounds & Scores" description="Final standings from every round." />
            <div className="max-w-4xl mx-auto space-y-3">
              {rounds.map((r, i) => {
                const showScores = r.status === "in_progress" || r.status === "completed";
                const myScores = showScores
                  ? roundScores
                      .filter((s) => s.round_id === r.id)
                      .sort((a, b) => {
                        if (a.position != null && b.position != null) return a.position - b.position;
                        if (a.position != null) return -1;
                        if (b.position != null) return 1;
                        return (b.score ?? 0) - (a.score ?? 0);
                      })
                  : [];
                return (
                  <div key={r.id} className="rounded-xl border border-border bg-card/50 p-5">
                    <div className="flex flex-wrap items-center gap-2 mb-2">
                      <span className="text-[10px] uppercase tracking-widest text-muted-foreground font-bold">Round {i + 1}</span>
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] uppercase tracking-wider font-bold border ${
                        r.status === "completed" ? "border-success/40 text-success" :
                        r.status === "in_progress" ? "border-neon/40 text-neon" :
                        "border-amber-400/40 text-amber-400"
                      }`}>
                        {r.status === "completed" ? <CheckCircle2 size={10} /> : <Circle size={10} />}
                        {r.status.replace("_", " ")}
                      </span>
                      {r.scheduled_at && (
                        <span className="inline-flex items-center gap-1 text-[10px] text-muted-foreground"><Clock size={10} /> {formatDateTimeDMY(r.scheduled_at)}</span>
                      )}
                    </div>
                    <h4 className="font-display text-lg mb-1">{r.name}</h4>
                    {r.description && <p className="text-sm text-muted-foreground mb-2">{r.description}</p>}
                    {showScores && (
                      <div className="mt-4 pt-4 border-t border-border">
                        <div className="flex items-center justify-between mb-2">
                          <h5 className="text-[11px] uppercase tracking-widest text-neon font-bold">
                            {r.status === "completed" ? "Final Standings" : "Live Standings"}
                          </h5>
                          <span className="text-[10px] text-muted-foreground">{myScores.length} {myScores.length === 1 ? "entry" : "entries"}</span>
                        </div>
                        {myScores.length === 0 ? (
                          <p className="text-xs text-muted-foreground italic">No scores posted for this round.</p>
                        ) : (
                          <div className={`overflow-auto rounded-lg border border-border ${myScores.length > 5 ? "max-h-[300px]" : ""}`}>
                            <table className="w-full text-sm">
                              <thead className="bg-card/80 text-left text-[10px] uppercase tracking-widest text-muted-foreground sticky top-0 z-10">
                                <tr>
                                  <th className="px-3 py-2 w-10">#</th>
                                  <th className="px-3 py-2">Team</th>
                                  <th className="px-3 py-2 w-24 text-right">Score</th>
                                  <th className="px-3 py-2 w-24 text-center">Status</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-border">
                                {myScores.map((s, idx) => {
                                  const reg = scoreRegs.find((x) => x.id === s.registration_id);
                                  return (
                                    <tr key={s.id} className={s.advanced ? "bg-neon/5" : ""}>
                                      <td className="px-3 py-2 text-xs font-bold text-neon">{s.position ?? idx + 1}</td>
                                      <td className="px-3 py-2">
                                        <div className="font-display text-sm">{reg?.team_name ?? "—"}</div>
                                        {reg?.captain_name && <div className="text-[11px] text-muted-foreground">{reg.captain_name}</div>}
                                      </td>
                                      <td className="px-3 py-2 text-right font-bold">{s.score ?? "—"}</td>
                                      <td className="px-3 py-2 text-center">
                                        {s.advanced ? (
                                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] uppercase font-bold border border-success/40 text-success">
                                            <CheckCircle2 size={10} /> Advanced
                                          </span>
                                        ) : (
                                          <span className="text-[10px] text-muted-foreground">—</span>
                                        )}
                                      </td>
                                    </tr>
                                  );
                                })}
                              </tbody>
                            </table>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </section>
        )}
        </>
      )}

      {tournament.status !== "completed" && (
        <>
      {/* DESCRIPTION + STATS */}
      <section className="container mx-auto px-4 sm:px-6 py-12 grid lg:grid-cols-[2fr,1fr] gap-8">
        <div className="space-y-6">
          {/* Format pills */}
          <div className="flex flex-wrap gap-2">
            <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-neon/40 bg-neon/10 text-neon text-[11px] font-bold uppercase tracking-widest">
              {tournament.tournament_type === "solo" ? <UserIcon size={12} /> : <Users size={12} />}
              {tournament.tournament_type === "solo" ? "Solo Tournament" : `Team — ${tournament.team_size} Players`}
            </span>
            {rounds.length > 0 && (
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-border text-[11px] font-bold uppercase tracking-widest">
                <Layers size={12} className="text-neon" /> {rounds.length} Round{rounds.length === 1 ? "" : "s"}
              </span>
            )}
            <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-gold/40 bg-gold/10 text-gold text-[11px] font-bold uppercase tracking-widest">
              <Crown size={12} /> {tournament.number_of_winners} Winner{tournament.number_of_winners === 1 ? "" : "s"}
            </span>
          </div>

          {tournament.description && (
            <div className="rounded-2xl border border-border bg-card/40 p-6 sm:p-8">
              <h2 className="font-display text-2xl mb-4 text-neon">About This Tournament</h2>
              <p className="text-sm text-muted-foreground whitespace-pre-line leading-relaxed">{tournament.description}</p>
            </div>
          )}
        </div>

        <div className="space-y-4">
          <div className="rounded-2xl border border-neon/30 bg-gradient-to-br from-card to-primary/10 p-6 shadow-glow">
            <div className="text-[10px] uppercase tracking-widest text-muted-foreground mb-1">Entry Fee</div>
            <div className="font-display text-3xl text-gradient-neon mb-3">₹{tournament.registration_fee.toLocaleString("en-IN")}</div>
            <div className="text-xs text-muted-foreground">per team of {tournament.team_size}</div>
            {tournament.early_bird_fee && tournament.early_bird_until && (
              <div className="mt-3 text-xs text-success">Early bird: ₹{tournament.early_bird_fee.toLocaleString("en-IN")} until {formatDateDMY(tournament.early_bird_until)}</div>
            )}
          </div>

          <div className="rounded-2xl border border-border bg-card/40 p-6">
            <div className="flex items-center gap-2 text-[10px] uppercase tracking-widest text-muted-foreground mb-3">
              <Trophy size={12} className="text-neon" /> Prize Pool
            </div>
            <div className="font-display text-base">{tournament.prize_pool}</div>
          </div>
        </div>
      </section>

      {/* PRIZES — 3 rows x 2 columns: Place | Prize amount */}
      {prizes.length > 0 && (
        <section className="container mx-auto px-4 sm:px-6 py-12">
          <SectionHeader
            eyebrow="Prizes"
            title="What's At Stake"
            description="Cash, trophies, and rewards for the top teams."
          />
          <div className="max-w-2xl mx-auto rounded-2xl border border-border bg-card/40 overflow-hidden">
            {prizes.slice(0, 3).map((p, idx) => (
              <div
                key={p.id}
                className={`grid grid-cols-2 items-center px-6 py-5 ${idx < Math.min(prizes.length, 3) - 1 ? "border-b border-border" : ""}`}
              >
                <div className="flex items-center gap-3">
                  <Trophy size={18} className={idx === 0 ? "text-gold" : idx === 1 ? "text-silver" : "text-bronze"} />
                  <div>
                    <div className="font-display text-lg">{p.rank_label}</div>
                    {p.title && <div className="text-xs text-muted-foreground">{p.title}</div>}
                  </div>
                </div>
                <div className="text-right font-display text-xl text-gradient-neon">{p.value || "—"}</div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* INDIVIDUAL AWARDS */}
      {awards.length > 0 && (
        <section className="container mx-auto px-4 sm:px-6 py-12">
          <div className="max-w-3xl mx-auto rounded-xl border border-border bg-card/40 p-8 text-center">
            <h3 className="font-display text-2xl mb-3 text-neon">Plus Individual Awards</h3>
            <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4 text-sm">
              {awards.map((a) => (
                <div key={a.id} className="rounded-lg border border-border bg-card/60 p-4">
                  <div className="font-display text-base mb-1">{a.title}</div>
                  {a.amount != null && <div className="text-gold font-bold">₹{a.amount.toLocaleString("en-IN")}</div>}
                  {a.description && <p className="text-xs text-muted-foreground mt-2">{a.description}</p>}
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* SCHEDULE */}
      {schedule.length > 0 && (
        <section className="container mx-auto px-4 sm:px-6 py-12">
          <SectionHeader eyebrow="Schedule" title="Event Timeline" description="Day-by-day breakdown of the tournament." />
          <div className="max-w-4xl mx-auto space-y-3">
            {schedule.map((s) => (
              <div key={s.id} className="rounded-xl border border-border bg-card/50 p-5 hover:border-neon transition-colors">
                <div className="flex flex-wrap items-baseline gap-3 mb-2">
                  <span className="text-xs font-bold uppercase tracking-widest text-neon">{s.day_label}</span>
                  {s.time_label && (
                    <span className="inline-flex items-center gap-1 text-xs text-muted-foreground"><Clock size={12} /> {s.time_label}</span>
                  )}
                </div>
                <h4 className="font-display text-lg mb-1">{s.title}</h4>
                {s.description && <p className="text-sm text-muted-foreground">{s.description}</p>}
              </div>
            ))}
          </div>
        </section>
      )}

      {/* SPONSORS STRIP — auto-scrolling, between Prizes and Tournament Structure */}
      <TournamentSponsorsStrip tournamentId={tournament.id} />

      {/* TOURNAMENT STRUCTURE / ROUNDS */}
      {rounds.length > 0 && (
        <section className="container mx-auto px-4 sm:px-6 py-12">
          <SectionHeader eyebrow="Format" title="Tournament Structure" description="Round-by-round qualification & advancement." />
          <div className="max-w-4xl mx-auto space-y-3">
            {rounds.map((r, i) => {
              const showScores = r.status === "in_progress" || r.status === "completed";
              const myScores = showScores
                ? roundScores
                    .filter((s) => s.round_id === r.id)
                    .sort((a, b) => {
                      if (a.position != null && b.position != null) return a.position - b.position;
                      if (a.position != null) return -1;
                      if (b.position != null) return 1;
                      return (b.score ?? 0) - (a.score ?? 0);
                    })
                : [];
              return (
              <div key={r.id} className="rounded-xl border border-border bg-card/50 p-5 hover:border-neon transition-colors">
                <div className="flex flex-wrap items-center gap-2 mb-2">
                  <span className="text-[10px] uppercase tracking-widest text-muted-foreground font-bold">Round {i + 1}</span>
                  <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] uppercase tracking-wider font-bold border ${
                    r.status === "completed" ? "border-success/40 text-success" :
                    r.status === "in_progress" ? "border-neon/40 text-neon" :
                    "border-amber-400/40 text-amber-400"
                  }`}>
                    {r.status === "completed" ? <CheckCircle2 size={10} /> : <Circle size={10} />}
                    {r.status.replace("_", " ")}
                  </span>
                  {r.scheduled_at && (
                    <span className="inline-flex items-center gap-1 text-[10px] text-muted-foreground"><Clock size={10} /> {formatDateTimeDMY(r.scheduled_at)}</span>
                  )}
                </div>
                <h4 className="font-display text-lg mb-1">{r.name}</h4>
                {r.description && <p className="text-sm text-muted-foreground mb-2">{r.description}</p>}
                <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
                  {r.participants_advancing != null && (
                    <span><span className="text-neon font-bold">{r.participants_advancing}</span> advancing to next round</span>
                  )}
                  {r.selection_criteria && <span>Criteria: <span className="text-foreground">{r.selection_criteria}</span></span>}
                </div>

                {showScores && (
                  <div className="mt-4 pt-4 border-t border-border">
                    <div className="flex items-center justify-between mb-2">
                      <h5 className="text-[11px] uppercase tracking-widest text-neon font-bold">
                        {r.status === "completed" ? "Final Standings" : "Live Standings"}
                      </h5>
                      <span className="text-[10px] text-muted-foreground">{myScores.length} {myScores.length === 1 ? "entry" : "entries"}</span>
                    </div>
                    {myScores.length === 0 ? (
                      <p className="text-xs text-muted-foreground italic">Scores will appear here once posted.</p>
                    ) : (
                      <div className={`overflow-auto rounded-lg border border-border ${myScores.length > 5 ? "max-h-[300px]" : ""}`}>
                        <table className="w-full text-sm">
                          <thead className="bg-card/80 text-left text-[10px] uppercase tracking-widest text-muted-foreground sticky top-0 z-10">
                            <tr>
                              <th className="px-3 py-2 w-10">#</th>
                              <th className="px-3 py-2">Team</th>
                              <th className="px-3 py-2 w-24 text-right">Score</th>
                              <th className="px-3 py-2 w-24 text-center">Status</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-border">
                            {myScores.map((s, idx) => {
                              const reg = scoreRegs.find((x) => x.id === s.registration_id);
                              return (
                                <tr key={s.id} className={s.advanced ? "bg-neon/5" : ""}>
                                  <td className="px-3 py-2 text-xs font-bold text-neon">{s.position ?? idx + 1}</td>
                                  <td className="px-3 py-2">
                                    <div className="font-display text-sm">{reg?.team_name ?? "—"}</div>
                                    {reg?.captain_name && <div className="text-[11px] text-muted-foreground">{reg.captain_name}</div>}
                                  </td>
                                  <td className="px-3 py-2 text-right font-bold">{s.score ?? "—"}</td>
                                  <td className="px-3 py-2 text-center">
                                    {s.advanced ? (
                                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] uppercase font-bold border border-success/40 text-success">
                                        <CheckCircle2 size={10} /> Advanced
                                      </span>
                                    ) : (
                                      <span className="text-[10px] text-muted-foreground">—</span>
                                    )}
                                  </td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                )}
              </div>
              );
            })}
          </div>
        </section>
      )}

      {/* (Winners merged into Prizes section below) */}

      {/* RULES */}
      {tournament.rules && (
        <section className="container mx-auto px-4 sm:px-6 py-12">
          <div className="max-w-4xl mx-auto rounded-2xl border border-border bg-card/40 p-6 sm:p-8">
            <h2 className="font-display text-2xl mb-4 text-neon flex items-center gap-2">
              <ShieldCheck size={20} /> Tournament Rules
            </h2>
            <div className="text-sm text-muted-foreground whitespace-pre-line leading-relaxed">{tournament.rules}</div>
          </div>
        </section>
      )}

        </>
      )}

      {/* Winners block rendered above when status is completed */}

      {/* GALLERY */}
      {gallery.length > 0 && (
        <section className="container mx-auto px-4 sm:px-6 py-12">
          <SectionHeader eyebrow="Gallery" title="Tournament Moments" />
          <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4 max-w-6xl mx-auto">
            {gallery.map((img) => (
              <button
                key={img.id}
                type="button"
                onClick={() => setLightbox(img)}
                className="relative rounded-xl overflow-hidden border border-border group cursor-pointer aspect-[4/3] focus:outline-none focus:ring-2 focus:ring-neon"
              >
                <img
                  src={img.image_url}
                  alt={img.caption ?? "Tournament photo"}
                  loading="lazy"
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background/90 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                {img.caption && (
                  <div className="absolute bottom-0 left-0 right-0 p-3 text-xs sm:text-sm text-foreground text-left opacity-0 group-hover:opacity-100 transition-all">
                    {img.caption}
                  </div>
                )}
              </button>
            ))}
          </div>
        </section>
      )}

      {/* LIGHTBOX */}
      {lightbox && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/95 backdrop-blur"
          onClick={() => setLightbox(null)}
        >
          <button
            type="button"
            onClick={(e) => { e.stopPropagation(); setLightbox(null); }}
            className="absolute top-4 right-4 p-2 rounded-full bg-card/80 border border-border text-neon hover:bg-card"
            aria-label="Close"
          >
            <XIcon size={20} />
          </button>
          <div className="max-w-6xl max-h-[90vh] w-full flex flex-col items-center gap-3" onClick={(e) => e.stopPropagation()}>
            <img
              src={lightbox.image_url}
              alt={lightbox.caption ?? "Tournament photo"}
              className="max-h-[80vh] w-auto max-w-full object-contain rounded-lg"
            />
            {lightbox.caption && (
              <p className="text-sm text-muted-foreground text-center">{lightbox.caption}</p>
            )}
          </div>
        </div>
      )}

      {/* FAQS */}
      {faqs.length > 0 && (
        <section className="container mx-auto px-4 sm:px-6 py-12">
          <SectionHeader eyebrow="Help" title="Frequently Asked Questions" />
          <div className="max-w-3xl mx-auto space-y-2">
            {faqs.map((f) => {
              const open = openFaq === f.id;
              return (
                <button
                  key={f.id}
                  onClick={() => setOpenFaq(open ? null : f.id)}
                  className="w-full text-left rounded-xl border border-border bg-card/50 p-5 hover:border-neon transition-colors"
                >
                  <div className="flex items-center justify-between gap-3">
                    <h4 className="font-display text-base">{f.question}</h4>
                    <ChevronDown size={16} className={`text-neon shrink-0 transition-transform ${open ? "rotate-180" : ""}`} />
                  </div>
                  {open && <p className="mt-3 text-sm text-muted-foreground whitespace-pre-line">{f.answer}</p>}
                </button>
              );
            })}
          </div>
        </section>
      )}

      {/* CTA */}
      {canRegister && (
        <section className="container mx-auto px-4 sm:px-6 py-12 pb-20">
          <div className="rounded-2xl border border-neon/40 bg-gradient-to-r from-card via-primary/20 to-card p-8 sm:p-12 text-center shadow-glow">
            <h2 className="font-display text-3xl sm:text-4xl mb-3">
              Ready to <span className="text-gradient-neon">Compete</span>?
            </h2>
            <p className="text-muted-foreground mb-6">Lock in your team for <span className="text-neon font-bold">{tournament.name}</span> today.</p>
            <button
              onClick={() => navigate({ to: "/register", search: { t: tournament.slug } as never })}
              className="inline-flex items-center gap-2 px-8 py-4 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground font-bold uppercase tracking-wider shadow-neon hover:scale-105 transition-transform"
            >
              <IndianRupee size={18} /> Register for ₹{tournament.registration_fee.toLocaleString("en-IN")}
            </button>
          </div>
        </section>
      )}
    </div>
  );
}
