import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Calendar, MapPin, Trophy, Zap, ArrowRight, Star, Loader2, Users, Crown } from "lucide-react";
import { Countdown } from "@/components/Countdown";
import { SectionHeader } from "@/components/SectionHeader";
import { SponsorsMarquee } from "@/components/SponsorsMarquee";
import { useFeaturedTournament } from "@/hooks/use-featured-tournament";
import { supabase } from "@/integrations/supabase/client";
import heroImg from "@/assets/hero-bowling.jpg";
import lanex from "@/assets/lanex-logo.png";
import { formatDateDMY } from "@/lib/format-date";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Strike Masters Bowling Tournaments — Register Your Team" },
      {
        name: "description",
        content:
          "Strike Masters — premier bowling tournaments at LaneX Bowling Alley, AR Mall, Surat. Browse upcoming events and lock in your team today.",
      },
      { property: "og:title", content: "Strike Masters Bowling Tournaments" },
      { property: "og:description", content: "Premier competitive bowling events in Surat. Register your 3-player team — slots are limited." },
      { property: "og:image", content: heroImg },
    ],
  }),
  component: HomePage,
});

function formatRange(qualification?: string | null, finals?: string | null) {
  if (!qualification && !finals) return "Dates To Be Announced";
  if (qualification && finals) {
    return `Qualification: ${formatDateDMY(qualification)} · Finals: ${formatDateDMY(finals)}`;
  }
  if (qualification) return `Qualification: ${formatDateDMY(qualification)}`;
  return `Finals: ${formatDateDMY(finals!)}`;
}

interface UpcomingTournament {
  id: string;
  slug: string;
  name: string;
  subtitle: string | null;
  banner_url: string | null;
  venue: string | null;
  qualification_date: string | null;
  finals_date: string | null;
  registration_fee: number;
  team_size: number;
  tournament_type: string;
  status: string;
  prize_pool: string;
}

function HomePage() {
  const { tournament: featuredFallback, loading } = useFeaturedTournament();
  const [allUpcoming, setAllUpcoming] = useState<UpcomingTournament[]>([]);

  // Hero tournament = the soonest upcoming tournament (earliest qualification date).
  // Falls back to the admin-featured one if no upcoming tournaments have dates.
  const heroFromUpcoming = allUpcoming.find((t) => t.qualification_date) ?? allUpcoming[0];
  const tournament = heroFromUpcoming
    ? {
        ...heroFromUpcoming,
        description: (heroFromUpcoming as any).description ?? null,
        registration_open: true,
        prize_pool: heroFromUpcoming.prize_pool,
        featured: false,
      } as any
    : featuredFallback;

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const { data } = await supabase
        .from("tournaments")
        .select("id, slug, name, subtitle, banner_url, venue, qualification_date, finals_date, registration_fee, team_size, tournament_type, status, prize_pool")
        .in("status", ["upcoming", "active"])
        .order("qualification_date", { ascending: true, nullsFirst: false });
      if (cancelled) return;
      setAllUpcoming((data ?? []) as UpcomingTournament[]);
    })();
    return () => { cancelled = true; };
  }, []);

  // Build the carousel list = all upcoming tournaments sorted by date (earliest first).
  // Always include the featured/hero tournament too so the user can scroll back to it.
  const upcoming = allUpcoming;

  const heroEyebrow = tournament
    ? `${formatRange(tournament.qualification_date, tournament.finals_date)}${tournament.venue ? " · " + tournament.venue.split(",")[0] : ""}`
    : "Upcoming Season";

  const tournamentName = tournament?.name ?? "Strike Masters";
  const tournamentSubtitle = tournament?.subtitle ?? "Tournament";
  const tournamentDescription = tournament?.description ?? "A premier competitive bowling event built for skill, rivalry, and community. Assemble your 3-player squad and battle through qualification and finals at LaneX Bowling Alley.";

  return (
    <>
      {/* HERO */}
      <section className="relative min-h-[92vh] flex items-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src={tournament?.banner_url ?? heroImg}
            alt="Bowling ball striking pins with explosive force"
            className="w-full h-full object-cover"
            width={1920}
            height={1080}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/85 to-background/40" />
          <div className="absolute inset-0 bg-gradient-to-r from-background via-background/30 to-transparent" />
        </div>

        <div className="relative container mx-auto px-4 sm:px-6 py-16 sm:py-20 grid lg:grid-cols-2 gap-10 sm:gap-12 items-center">
          <div className="animate-[fade-up_0.8s_ease-out]">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-neon/40 bg-neon/10 text-neon text-xs font-bold uppercase tracking-widest mb-6">
              <Zap size={12} /> {loading ? "Loading…" : heroEyebrow}
            </div>
            <h1 className="font-display text-4xl sm:text-6xl md:text-7xl lg:text-8xl leading-[0.95] mb-5 sm:mb-6">
              <span className="text-gradient-neon">{tournamentName}</span>
              {tournamentSubtitle && (
                <>
                  <br />
                  <span className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl text-muted-foreground tracking-wide">
                    {tournamentSubtitle}
                  </span>
                </>
              )}
            </h1>
            <p className="text-base sm:text-lg text-muted-foreground max-w-xl mb-7 sm:mb-8">
              {tournamentDescription}
            </p>

            <div className="flex flex-wrap gap-4 mb-10">
              <Link
                to="/register"
                className="group inline-flex items-center gap-2 px-7 py-4 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground font-bold uppercase tracking-wider shadow-neon hover:scale-105 transition-transform"
              >
                Register Now
                <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
              </Link>
              {tournament ? (
                <Link
                  to="/tournaments/$slug"
                  params={{ slug: tournament.slug }}
                  className="inline-flex items-center gap-2 px-7 py-4 rounded-md border border-border bg-card/40 backdrop-blur font-bold uppercase tracking-wider hover:border-neon transition-colors"
                >
                  View Details
                </Link>
              ) : (
                <Link
                  to="/tournaments"
                  className="inline-flex items-center gap-2 px-7 py-4 rounded-md border border-border bg-card/40 backdrop-blur font-bold uppercase tracking-wider hover:border-neon transition-colors"
                >
                  Browse Tournaments
                </Link>
              )}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-sm">
              <div className="flex items-center gap-2 text-muted-foreground">
                <Calendar size={16} className="text-neon" /> {formatRange(tournament?.qualification_date, tournament?.finals_date)}
              </div>
              <div className="flex items-center gap-2 text-muted-foreground">
                <MapPin size={16} className="text-neon" /> {tournament?.venue ?? "LaneX, AR Mall, Surat"}
              </div>
              <div className="flex items-center gap-2 text-muted-foreground">
                <Trophy size={16} className="text-neon" /> {tournament?.prize_pool ?? "Prize Pool Scales With Registrations"}
              </div>
            </div>
          </div>

          <div className="lg:justify-self-end w-full max-w-md space-y-4">
            {loading ? (
              <div className="rounded-2xl border border-border bg-card/60 backdrop-blur-md p-6 shadow-glow text-center py-10">
                <Loader2 className="w-6 h-6 mx-auto animate-spin text-neon" />
              </div>
            ) : (
              <>
                {(() => {
                  // Build an ordered queue from ALL upcoming tournaments, sorted by earliest date.
                  type Slot = { slug: string; name: string; qualification_date: string | null; finals_date: string | null };
                  const seen = new Set<string>();
                  const queue: Slot[] = [];
                  for (const u of upcoming) {
                    if (seen.has(u.id)) continue;
                    seen.add(u.id);
                    queue.push({ slug: u.slug, name: u.name, qualification_date: u.qualification_date, finals_date: u.finals_date });
                  }
                  // Sort by earliest qualification date (TBA goes last)
                  queue.sort((a, b) => {
                    const aT = a.qualification_date ? new Date(a.qualification_date).getTime() : Infinity;
                    const bT = b.qualification_date ? new Date(b.qualification_date).getTime() : Infinity;
                    return aT - bT;
                  });
                  const slots = queue.slice(0, 2);
                  if (slots.length === 0) {
                    return (
                      <div className="rounded-2xl border border-border bg-card/60 backdrop-blur-md p-6 shadow-glow">
                        <div className="text-center text-xs uppercase tracking-widest text-neon font-bold mb-5">Tournament Starts In</div>
                        <Countdown />
                      </div>
                    );
                  }
                  return slots.map((s, idx) => (
                    <Link
                      key={s.slug}
                      to="/tournaments/$slug"
                      params={{ slug: s.slug }}
                      className="block rounded-2xl border border-border bg-card/60 backdrop-blur-md p-6 shadow-glow hover:border-neon transition-colors group"
                    >
                      <div className="text-center mb-4">
                        <div className="text-[10px] uppercase tracking-widest text-muted-foreground font-bold mb-1">
                          {idx === 0 ? "Next Tournament" : "Then Up Next"}
                        </div>
                        <div className="text-sm uppercase tracking-widest text-neon font-bold truncate group-hover:underline">
                          {s.name}
                        </div>
                        <div className="text-[11px] text-muted-foreground mt-1 inline-flex items-center gap-1.5">
                          <Calendar size={11} className="text-neon" />
                          {formatRange(s.qualification_date, s.finals_date)}
                        </div>
                      </div>
                      <Countdown
                        qualificationDate={s.qualification_date}
                        finalsDate={s.finals_date}
                      />
                    </Link>
                  ));
                })()}
              </>
            )}
          </div>
        </div>
      </section>

      {/* SPONSORS MARQUEE */}
      <SponsorsMarquee />

      {/* HIGHLIGHTS */}
      <section className="py-16 sm:py-20 container mx-auto px-4 sm:px-6">
        <SectionHeader
          eyebrow="Why Compete"
          title="The Ultimate Bowling Stage"
          description="Two days of high-stakes competition, professional lanes, and unforgettable moments."
        />
        <div className="grid md:grid-cols-3 gap-6">
          {[
            { icon: Trophy, title: "Scaling Prize Pool", desc: "More registrations grow the pool — bigger fields, bigger rewards." },
            { icon: Zap, title: "Pro-Spec Lanes", desc: "Tournament-grade lanes with electronic scoring at LaneX." },
            { icon: Calendar, title: "2 Days of Action", desc: "Qualification rounds, top-team finals, and the awards ceremony." },
          ].map((f, i) => (
            <div
              key={i}
              className="group rounded-xl border border-border bg-card/50 p-6 hover:border-neon transition-all hover:-translate-y-1 hover:shadow-glow"
            >
              <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-neon to-primary flex items-center justify-center mb-4 group-hover:animate-pulse">
                <f.icon className="text-neon-foreground" size={24} />
              </div>
              <h3 className="font-display text-xl mb-2">{f.title}</h3>
              <p className="text-sm text-muted-foreground">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>


      {/* UPCOMING TOURNAMENTS */}
      {upcoming.length > 0 && (
        <section className="container mx-auto px-4 sm:px-6 py-16">
          <SectionHeader
            eyebrow="On The Calendar"
            title="Upcoming Tournaments"
            description="More events to compete in. Lock in your team early — slots fill fast."
          />
          <div className="-mx-4 sm:-mx-6 px-4 sm:px-6 overflow-x-auto scroll-smooth snap-x snap-mandatory pb-4">
            <div className="flex gap-5 min-w-min">
              {upcoming.map((t) => (
                <Link
                  key={t.id}
                  to="/tournaments/$slug"
                  params={{ slug: t.slug }}
                  className="group rounded-2xl overflow-hidden border border-border bg-card/60 hover:border-neon transition-all hover:-translate-y-1 hover:shadow-glow flex flex-col snap-start shrink-0 w-[280px] sm:w-[320px]"
                >
                  <div className="aspect-video relative overflow-hidden bg-gradient-to-br from-card via-primary/20 to-background">
                    {t.banner_url && (
                      <img src={t.banner_url} alt={t.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                    )}
                    <div className="absolute top-3 left-3 inline-flex items-center gap-1 px-2 py-1 rounded-full bg-background/80 backdrop-blur border border-neon/40 text-neon text-[10px] font-bold uppercase tracking-widest">
                      <Zap size={10} /> {t.status}
                    </div>
                  </div>
                  <div className="p-5 flex-1 flex flex-col">
                    <h3 className="font-display text-xl mb-1 group-hover:text-neon transition-colors">{t.name}</h3>
                    {t.subtitle && <p className="text-xs text-muted-foreground mb-3 line-clamp-2">{t.subtitle}</p>}
                    <div className="space-y-1.5 text-xs text-muted-foreground mt-auto">
                      <div className="flex items-center gap-1.5"><Calendar size={12} className="text-neon" /> {formatRange(t.qualification_date, t.finals_date)}</div>
                      {t.venue && <div className="flex items-center gap-1.5"><MapPin size={12} className="text-neon" /> {t.venue.split(",")[0]}</div>}
                      <div className="flex items-center gap-1.5">
                        {t.tournament_type === "solo" ? <Crown size={12} className="text-neon" /> : <Users size={12} className="text-neon" />}
                        {t.tournament_type === "solo" ? "Solo" : `Team of ${t.team_size}`} · ₹{t.registration_fee.toLocaleString("en-IN")}
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
          <div className="mt-8 text-center">
            <Link to="/tournaments" className="inline-flex items-center gap-2 px-6 py-3 rounded-md border border-border hover:border-neon text-xs uppercase tracking-wider font-bold">
              View All Tournaments <ArrowRight size={14} />
            </Link>
          </div>
        </section>
      )}

      {/* CO-SPONSOR STRIP */}
      <section className="container mx-auto px-4 sm:px-6 py-12">
        <div className="rounded-2xl border border-gold/40 bg-gradient-to-r from-card via-gold/5 to-card p-6 sm:p-8 shadow-glow">
          <div className="grid md:grid-cols-[auto,1fr,auto] gap-6 items-center">
            <div className="rounded-xl bg-background/60 border border-border p-4 flex items-center justify-center">
              <img src={lanex} alt="LaneX Bowling Alley logo" className="h-20 sm:h-24 w-auto object-contain" />
            </div>
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-gold/50 bg-gold/10 text-gold text-xs font-bold uppercase tracking-widest mb-3">
                <Star size={12} /> Official Venue Partner
              </div>
              <h3 className="font-display text-2xl sm:text-3xl mb-1">LaneX Bowling Alley</h3>
              <p className="text-sm text-muted-foreground">
                Official venue of Strike Masters — pro-spec lanes, electronic scoring, and a championship-ready atmosphere.
              </p>
            </div>
            <Link
              to="/sponsors"
              className="inline-flex items-center gap-2 px-5 py-3 rounded-md border border-gold text-gold font-bold uppercase tracking-wider text-xs hover:bg-gold/10 transition-colors"
            >
              View Sponsors
            </Link>
          </div>
        </div>
      </section>

      {/* CTA STRIP */}
      <section className="container mx-auto px-4 sm:px-6 pb-10">
        <div className="rounded-2xl border border-neon/40 bg-gradient-to-r from-card via-primary/20 to-card p-8 sm:p-12 text-center shadow-glow">
          <h2 className="font-display text-3xl sm:text-5xl mb-4">
            Ready to <span className="text-gradient-neon">Strike</span>?
          </h2>
          <p className="text-muted-foreground mb-6 max-w-xl mx-auto">
            Limited slots available based on lane capacity — early registration is recommended. Lock your team in before slots fill up.
          </p>
          <div className="flex flex-wrap gap-3 justify-center">
            <Link
              to="/register"
              className="inline-flex items-center gap-2 px-8 py-4 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground font-bold uppercase tracking-wider shadow-neon hover:scale-105 transition-transform"
            >
              Secure Your Spot <ArrowRight size={18} />
            </Link>
            <Link
              to="/tournaments"
              className="inline-flex items-center gap-2 px-8 py-4 rounded-md border border-border hover:border-neon font-bold uppercase tracking-wider"
            >
              Browse All Tournaments
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
