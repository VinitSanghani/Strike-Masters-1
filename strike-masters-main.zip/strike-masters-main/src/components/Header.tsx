import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Menu, X, LogIn, LogOut, LayoutDashboard, Shield } from "lucide-react";
import logo from "@/assets/strike-masters-logo.png";
import { useAuth } from "@/hooks/use-auth";

const links = [
  { to: "/", label: "Home" },
  { to: "/about", label: "About" },
  { to: "/tournaments", label: "Tournaments" },
  { to: "/gallery", label: "Gallery" },
  { to: "/sponsors", label: "Sponsors" },
  { to: "/contact", label: "Contact" },
] as const;

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const { user, isAdmin, signOut } = useAuth();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-background/80 backdrop-blur-md border-b border-border"
          : "bg-transparent"
      }`}
    >
      <div className="container mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-3">
        <Link to="/" className="flex items-center group min-w-0" aria-label="Strike Masters">
          <img
            src={logo}
            alt="Strike Masters Tournament logo"
            className="h-12 sm:h-14 w-auto object-contain drop-shadow-[0_0_14px_color-mix(in_oklab,var(--neon)_55%,transparent)] transition-transform group-hover:scale-105"
          />
        </Link>

        <nav className="hidden lg:flex items-center gap-1">
          {links.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              className="px-3 py-2 text-xs xl:text-sm font-medium uppercase tracking-wider text-muted-foreground hover:text-foreground transition-colors"
              activeProps={{ className: "text-neon" }}
              activeOptions={{ exact: true }}
            >
              {l.label}
            </Link>
          ))}

          {user ? (
            <>
              {isAdmin && (
                <Link
                  to="/admin"
                  className="ml-2 inline-flex items-center gap-1.5 px-3 py-2 rounded-md border border-neon/40 text-neon hover:bg-neon/10 text-xs xl:text-sm font-bold uppercase tracking-wider transition-colors"
                >
                  <Shield size={14} /> Admin
                </Link>
              )}
              <Link
                to="/dashboard"
                className="ml-2 inline-flex items-center gap-1.5 px-3 py-2 rounded-md border border-border hover:border-neon text-xs xl:text-sm font-bold uppercase tracking-wider transition-colors"
              >
                <LayoutDashboard size={14} /> Dashboard
              </Link>
              <button
                onClick={() => signOut()}
                className="ml-2 inline-flex items-center gap-1.5 px-3 py-2 rounded-md border border-border hover:border-destructive text-xs xl:text-sm font-bold uppercase tracking-wider transition-colors"
              >
                <LogOut size={14} /> Logout
              </button>
            </>
          ) : (
            <>
              <Link
                to="/login"
                className="ml-2 inline-flex items-center gap-1.5 px-3 py-2 rounded-md border border-border hover:border-neon text-xs xl:text-sm font-bold uppercase tracking-wider transition-colors"
              >
                <LogIn size={14} /> Login
              </Link>
              <Link
                to="/register"
                className="ml-2 px-4 py-2 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground font-bold text-xs xl:text-sm uppercase tracking-wider shadow-neon hover:scale-105 transition-transform"
              >
                Register
              </Link>
            </>
          )}
        </nav>

        <button
          className="lg:hidden p-2 text-foreground"
          onClick={() => setOpen(!open)}
          aria-label="Toggle menu"
        >
          {open ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {open && (
        <div className="lg:hidden border-t border-border bg-background/95 backdrop-blur">
          <nav className="container mx-auto px-4 py-4 flex flex-col gap-1">
            {links.map((l) => (
              <Link
                key={l.to}
                to={l.to}
                onClick={() => setOpen(false)}
                className="px-4 py-3 text-sm font-medium uppercase tracking-wider text-muted-foreground hover:text-foreground hover:bg-accent rounded-md"
                activeProps={{ className: "text-neon bg-accent" }}
              >
                {l.label}
              </Link>
            ))}
            {user ? (
              <>
                {isAdmin && (
                  <Link
                    to="/admin"
                    onClick={() => setOpen(false)}
                    className="mt-2 px-4 py-3 rounded-md border border-neon/40 text-neon text-sm font-bold uppercase tracking-wider text-center"
                  >
                    Admin Panel
                  </Link>
                )}
                <Link
                  to="/dashboard"
                  onClick={() => setOpen(false)}
                  className="mt-2 px-4 py-3 rounded-md border border-border text-sm font-bold uppercase tracking-wider text-center"
                >
                  Dashboard
                </Link>
                <button
                  onClick={() => {
                    setOpen(false);
                    signOut();
                  }}
                  className="mt-2 px-4 py-3 rounded-md border border-border text-sm font-bold uppercase tracking-wider"
                >
                  Logout
                </button>
              </>
            ) : (
              <>
                <Link
                  to="/login"
                  onClick={() => setOpen(false)}
                  className="mt-2 px-4 py-3 rounded-md border border-border text-sm font-bold uppercase tracking-wider text-center"
                >
                  Login
                </Link>
                <Link
                  to="/register"
                  onClick={() => setOpen(false)}
                  className="mt-2 px-4 py-3 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground font-bold text-sm uppercase tracking-wider text-center"
                >
                  Register Now
                </Link>
              </>
            )}
          </nav>
        </div>
      )}
    </header>
  );
}
