import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Lock, Loader2, AlertCircle } from "lucide-react";
import { SectionHeader } from "@/components/SectionHeader";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Reset Password — Strike Masters" },
      { name: "description", content: "Set a new password for your Strike Masters account." },
    ],
  }),
  component: ResetPasswordPage,
});

function ResetPasswordPage() {
  const navigate = useNavigate();
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    // Supabase recovery link sets a session via hash fragment
    const { data: sub } = supabase.auth.onAuthStateChange((event) => {
      if (event === "PASSWORD_RECOVERY" || event === "SIGNED_IN") setReady(true);
    });
    supabase.auth.getSession().then(({ data }) => { if (data.session) setReady(true); });
    return () => sub.subscription.unsubscribe();
  }, []);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password.length < 6) return setError("Password must be at least 6 characters");
    if (password !== confirm) return setError("Passwords do not match");
    setError("");
    setLoading(true);
    const { error: err } = await supabase.auth.updateUser({ password });
    setLoading(false);
    if (err) {
      toast.error(err.message);
      return;
    }
    toast.success("Password updated. Please log in again.");
    await supabase.auth.signOut();
    navigate({ to: "/login" });
  };

  const inputCls = "w-full pl-10 pr-4 py-3 rounded-md bg-input/60 border border-border focus:border-neon focus:outline-none focus:ring-2 focus:ring-neon/30 transition-all text-sm";

  return (
    <div className="container mx-auto px-4 sm:px-6 py-14 sm:py-20">
      <SectionHeader eyebrow="Account Recovery" title="Set A New Password" description="Choose a new password to access your account." />
      <form onSubmit={onSubmit} className="max-w-md mx-auto rounded-2xl border border-border bg-card/60 backdrop-blur p-8 shadow-glow space-y-5">
        {!ready && <p className="text-center text-sm text-muted-foreground">Validating reset link…</p>}
        <div>
          <label className="block text-xs font-bold uppercase tracking-widest text-muted-foreground mb-2">New Password</label>
          <div className="relative">
            <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input type="password" className={inputCls} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" />
          </div>
        </div>
        <div>
          <label className="block text-xs font-bold uppercase tracking-widest text-muted-foreground mb-2">Confirm Password</label>
          <div className="relative">
            <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input type="password" className={inputCls} value={confirm} onChange={(e) => setConfirm(e.target.value)} placeholder="••••••••" />
          </div>
        </div>
        {error && (
          <div className="flex items-center gap-1.5 text-xs text-destructive">
            <AlertCircle size={12} /> {error}
          </div>
        )}
        <button type="submit" disabled={loading || !ready} className="w-full inline-flex items-center justify-center gap-2 py-3 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground font-bold uppercase tracking-wider shadow-neon disabled:opacity-50">
          {loading && <Loader2 size={16} className="animate-spin" />}
          Update Password
        </button>
      </form>
    </div>
  );
}
