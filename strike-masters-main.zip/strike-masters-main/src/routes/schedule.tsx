import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Clock, Trophy, Calendar, Loader2, MapPin, ArrowRight } from "lucide-react";
import { SectionHeader } from "@/components/SectionHeader";
import { supabase } from "@/integrations/supabase/client";
import { formatDateDMY } from "@/lib/format-date";

export const Route = createFileRoute("/schedule")({
  head: () => ({
    meta: [
      { title: "Schedule — Strike Masters Bowling Tournament" },
      { name: "description", content: "Tournament schedule and event timeline for the upcoming Strike Masters bowling event." },
      { property: "og:title", content: "Strike Masters — Format & Schedule" },
      { property: "og:description", content: "Tournament format, match timings, and event flow." },
    ],
  }),
  component: SchedulePage,
});

interface Tournament {
  id: string;
  slug: string;
  name: string;
  subtitle: string | null;
  venue: string | null;
  qualification_date: string | null;
  finals_date: string | null;
  status: string;
  team_size: number;
  number_of_winners: number;
  tournament_type: string;
}

interface ScheduleItem {
  id: string;
  day_label: string;
  time_label: string | null;
  title: string;
  description: string | null;
}

function SchedulePage() {
  const [tournament, setTournament] = useState<Tournament | null>(null);
  const [items, setItems] = useState<ScheduleItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      // Find upcoming/active tournament — featured first, then earliest qualification date
      const { data } = await supabase
        .from("tournaments")
        .select("*")
        .in("status", ["upcoming", "active"])
        .order("featured", { ascending: false })
        .order("qualification_date", { ascending: true })
        .limit(1);
      const t = (data ?? [])[0] as Tournament | undefined;
      if (cancelled) return;
      if (!t) { setLoading(false); return; }
      setTournament(t);
      const { data: sched } = await supabase
        .from("tournament_schedule")
        .select("id, day_label, time_label, title, description")
        .eq("tournament_id", t.id)
        .order("sort_order", { ascending: true });
      if (cancelled) return;
      setItems((sched ?? []) as ScheduleItem[]);
      setLoading(false);
    })();
    return () => { cancelled = true; };
  }, []);

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-32 text-center">
        <Loader2 className="w-8 h-8 mx-auto animate-spin text-neon" />
      </div>
    );
  }

  if (!tournament) {
    return (
      <div className="container mx-auto px-4 sm:px-6 py-20">
        <SectionHeader
          eyebrow="Format & Schedule"
          title="Schedule Coming Soon"
          description="No upcoming tournament is currently scheduled. Check back soon."
        />
        <div className="text-center mt-8">
          <Link to="/tournaments" className="inline-flex items-center gap-2 px-5 py-3 rounded-md border border-border hover:border-neon text-xs uppercase tracking-wider font-bold">
            Browse All Tournaments <ArrowRight size={14} />
          </Link>
        </div>
      </div>
    );
  }

  // Group schedule items by day_label preserving order of first appearance
  const grouped: { day_label: string; rows: ScheduleItem[] }[] = [];
  for (const it of items) {
    const g = grouped.find((x) => x.day_label === it.day_label);
    if (g) g.rows.push(it);
    else grouped.push({ day_label: it.day_label, rows: [it] });
  }

  return (
    <div className="container mx-auto px-4 sm:px-6 py-14 sm:py-20">
      <SectionHeader
        eyebrow="Format & Schedule"
        title={tournament.name}
        description={tournament.subtitle ?? "Tournament timeline and event flow."}
      />

      {/* Header summary card */}
      <div className="max-w-4xl mx-auto mb-12 rounded-2xl border border-neon/30 bg-gradient-to-br from-card to-primary/10 p-6 sm:p-8 shadow-glow">
        <div className="grid sm:grid-cols-3 gap-4 text-sm">
          {tournament.qualification_date && (
            <div className="rounded-xl border border-border bg-background/40 p-4">
              <div className="flex items-center gap-2 text-[10px] uppercase tracking-widest text-neon mb-1">
                <Calendar size={12} /> Qualification
              </div>
              <div className="font-display text-lg">{formatDateDMY(tournament.qualification_date)}</div>
            </div>
          )}
          {tournament.finals_date && (
            <div className="rounded-xl border border-border bg-background/40 p-4">
              <div className="flex items-center gap-2 text-[10px] uppercase tracking-widest text-gold mb-1">
                <Trophy size={12} /> Finals
              </div>
              <div className="font-display text-lg">{formatDateDMY(tournament.finals_date)}</div>
            </div>
          )}
          {tournament.venue && (
            <div className="rounded-xl border border-border bg-background/40 p-4">
              <div className="flex items-center gap-2 text-[10px] uppercase tracking-widest text-muted-foreground mb-1">
                <MapPin size={12} /> Venue
              </div>
              <div className="font-display text-base">{tournament.venue}</div>
            </div>
          )}
        </div>
      </div>

      {grouped.length === 0 ? (
        <div className="max-w-3xl mx-auto rounded-xl border border-dashed border-border bg-card/40 p-10 text-center">
          <p className="text-sm text-muted-foreground mb-4">Detailed schedule will be published soon.</p>
          <Link to="/tournaments/$slug" params={{ slug: tournament.slug }} className="inline-flex items-center gap-2 px-5 py-3 rounded-md border border-border hover:border-neon text-xs uppercase tracking-wider font-bold">
            View Tournament Details <ArrowRight size={14} />
          </Link>
        </div>
      ) : (
        <div className="space-y-12 max-w-4xl mx-auto">
          {grouped.map((day, i) => (
            <div key={day.day_label}>
              <div className="flex items-center gap-4 mb-6">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-neon to-primary flex items-center justify-center font-display text-neon-foreground text-lg shadow-neon">
                  {i + 1}
                </div>
                <div>
                  <div className="font-display text-2xl">{day.day_label}</div>
                </div>
              </div>

              <div className="space-y-4 ml-4 sm:ml-6 border-l-2 border-border pl-6 sm:pl-8 relative">
                {day.rows.map((r) => (
                  <div
                    key={r.id}
                    className="relative rounded-xl border border-border bg-card/50 p-5 hover:border-neon transition-colors shadow-glow"
                  >
                    <div className="absolute -left-[34px] sm:-left-[42px] top-6 w-3 h-3 rounded-full bg-neon shadow-neon" />
                    <div className="flex flex-wrap items-baseline gap-3 mb-2">
                      {r.time_label && (
                        <div className="flex items-center gap-2 text-neon font-bold text-sm">
                          <Clock size={14} /> {r.time_label}
                        </div>
                      )}
                      <h4 className="font-display text-lg">{r.title}</h4>
                    </div>
                    {r.description && (
                      <p className="text-sm text-muted-foreground whitespace-pre-line">{r.description}</p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="text-center mt-12">
        <Link to="/tournaments/$slug" params={{ slug: tournament.slug }} className="inline-flex items-center gap-2 px-6 py-3 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground text-xs uppercase tracking-wider font-bold shadow-neon">
          View Full Tournament Details <ArrowRight size={14} />
        </Link>
      </div>
    </div>
  );
}
