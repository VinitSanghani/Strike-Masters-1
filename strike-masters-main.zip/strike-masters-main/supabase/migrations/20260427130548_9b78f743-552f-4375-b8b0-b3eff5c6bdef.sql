
-- ========== Tournaments expansion ==========
ALTER TABLE public.tournaments
  ADD COLUMN IF NOT EXISTS tournament_type text NOT NULL DEFAULT 'team',
  ADD COLUMN IF NOT EXISTS payment_methods text[] NOT NULL DEFAULT ARRAY['online']::text[],
  ADD COLUMN IF NOT EXISTS upi_qr_url text,
  ADD COLUMN IF NOT EXISTS upi_id text,
  ADD COLUMN IF NOT EXISTS payment_instructions text,
  ADD COLUMN IF NOT EXISTS cash_payment_deadline date,
  ADD COLUMN IF NOT EXISTS auto_confirm_online boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS number_of_winners integer NOT NULL DEFAULT 3;

-- Validate tournament_type via trigger (avoids brittle CHECK constraints)
CREATE OR REPLACE FUNCTION public.validate_tournament_fields()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  IF NEW.tournament_type NOT IN ('solo','team') THEN
    RAISE EXCEPTION 'tournament_type must be solo or team';
  END IF;
  IF NEW.number_of_winners < 1 OR NEW.number_of_winners > 20 THEN
    RAISE EXCEPTION 'number_of_winners must be between 1 and 20';
  END IF;
  -- Ensure payment_methods only contains known values
  IF NEW.payment_methods IS NOT NULL THEN
    IF EXISTS (
      SELECT 1 FROM unnest(NEW.payment_methods) m
      WHERE m NOT IN ('online','cash','upi_qr')
    ) THEN
      RAISE EXCEPTION 'payment_methods may only contain online, cash, upi_qr';
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS validate_tournament_fields_trg ON public.tournaments;
CREATE TRIGGER validate_tournament_fields_trg
BEFORE INSERT OR UPDATE ON public.tournaments
FOR EACH ROW EXECUTE FUNCTION public.validate_tournament_fields();

-- ========== Registrations expansion ==========
ALTER TABLE public.registrations
  ADD COLUMN IF NOT EXISTS payment_method text NOT NULL DEFAULT 'online',
  ADD COLUMN IF NOT EXISTS payment_status text NOT NULL DEFAULT 'pending',
  ADD COLUMN IF NOT EXISTS payment_proof_url text,
  ADD COLUMN IF NOT EXISTS upi_transaction_ref text,
  ADD COLUMN IF NOT EXISTS verification_notes text,
  ADD COLUMN IF NOT EXISTS verified_at timestamp with time zone,
  ADD COLUMN IF NOT EXISTS verified_by uuid;

CREATE OR REPLACE FUNCTION public.validate_registration_fields()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  IF NEW.payment_method NOT IN ('online','cash','upi_qr') THEN
    RAISE EXCEPTION 'payment_method must be online, cash, or upi_qr';
  END IF;
  IF NEW.payment_status NOT IN ('pending','awaiting_verification','verified','rejected') THEN
    RAISE EXCEPTION 'payment_status must be pending, awaiting_verification, verified, or rejected';
  END IF;
  -- Keep legacy payment_verified in sync
  IF NEW.payment_status = 'verified' THEN
    NEW.payment_verified := true;
  ELSIF TG_OP = 'UPDATE' AND OLD.payment_status = 'verified' AND NEW.payment_status <> 'verified' THEN
    NEW.payment_verified := false;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS validate_registration_fields_trg ON public.registrations;
CREATE TRIGGER validate_registration_fields_trg
BEFORE INSERT OR UPDATE ON public.registrations
FOR EACH ROW EXECUTE FUNCTION public.validate_registration_fields();

-- Backfill payment_status for existing rows
UPDATE public.registrations
SET payment_status = CASE WHEN payment_verified THEN 'verified' ELSE 'pending' END
WHERE payment_status = 'pending' AND payment_verified = true;

-- ========== Tournament rounds ==========
CREATE TABLE IF NOT EXISTS public.tournament_rounds (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tournament_id uuid NOT NULL,
  name text NOT NULL,
  description text,
  scheduled_at timestamp with time zone,
  participants_advancing integer,
  selection_criteria text,
  sort_order integer NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'upcoming',
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.tournament_rounds ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Rounds publicly readable" ON public.tournament_rounds;
CREATE POLICY "Rounds publicly readable"
ON public.tournament_rounds FOR SELECT
USING (true);

DROP POLICY IF EXISTS "Admins manage rounds" ON public.tournament_rounds;
CREATE POLICY "Admins manage rounds"
ON public.tournament_rounds FOR ALL
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE TRIGGER update_tournament_rounds_updated_at
BEFORE UPDATE ON public.tournament_rounds
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ========== Round scores ==========
CREATE TABLE IF NOT EXISTS public.round_scores (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  round_id uuid NOT NULL,
  registration_id uuid NOT NULL,
  tournament_id uuid NOT NULL,
  score numeric,
  position integer,
  advanced boolean NOT NULL DEFAULT false,
  notes text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE (round_id, registration_id)
);

ALTER TABLE public.round_scores ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Scores readable by participants and admins" ON public.round_scores;
CREATE POLICY "Scores readable by participants and admins"
ON public.round_scores FOR SELECT
TO authenticated
USING (
  has_role(auth.uid(), 'admin'::app_role)
  OR EXISTS (
    SELECT 1 FROM public.registrations r
    WHERE r.id = round_scores.registration_id
      AND r.user_id = auth.uid()
  )
);

DROP POLICY IF EXISTS "Scores publicly readable" ON public.round_scores;
CREATE POLICY "Scores publicly readable"
ON public.round_scores FOR SELECT
TO anon
USING (true);

DROP POLICY IF EXISTS "Admins manage scores" ON public.round_scores;
CREATE POLICY "Admins manage scores"
ON public.round_scores FOR ALL
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE TRIGGER update_round_scores_updated_at
BEFORE UPDATE ON public.round_scores
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ========== Tournament winners ==========
CREATE TABLE IF NOT EXISTS public.tournament_winners (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tournament_id uuid NOT NULL,
  registration_id uuid,
  place integer NOT NULL,
  place_label text NOT NULL,
  prize_title text,
  prize_amount integer,
  notes text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE (tournament_id, place)
);

ALTER TABLE public.tournament_winners ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Winners publicly readable" ON public.tournament_winners;
CREATE POLICY "Winners publicly readable"
ON public.tournament_winners FOR SELECT
USING (true);

DROP POLICY IF EXISTS "Admins manage winners" ON public.tournament_winners;
CREATE POLICY "Admins manage winners"
ON public.tournament_winners FOR ALL
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE TRIGGER update_tournament_winners_updated_at
BEFORE UPDATE ON public.tournament_winners
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ========== Indexes ==========
CREATE INDEX IF NOT EXISTS idx_rounds_tournament ON public.tournament_rounds(tournament_id, sort_order);
CREATE INDEX IF NOT EXISTS idx_round_scores_round ON public.round_scores(round_id);
CREATE INDEX IF NOT EXISTS idx_round_scores_registration ON public.round_scores(registration_id);
CREATE INDEX IF NOT EXISTS idx_winners_tournament ON public.tournament_winners(tournament_id, place);
CREATE INDEX IF NOT EXISTS idx_registrations_tournament_status ON public.registrations(tournament_id, payment_status);

-- ========== Storage bucket: payment proofs (private) ==========
INSERT INTO storage.buckets (id, name, public)
VALUES ('payment-proofs', 'payment-proofs', false)
ON CONFLICT (id) DO NOTHING;

-- Authenticated users can upload to a folder named with their user id
DROP POLICY IF EXISTS "Users upload own payment proof" ON storage.objects;
CREATE POLICY "Users upload own payment proof"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'payment-proofs'
  AND auth.uid()::text = (storage.foldername(name))[1]
);

-- Users (and anonymous registrants via service role) can read their own
DROP POLICY IF EXISTS "Users read own payment proof" ON storage.objects;
CREATE POLICY "Users read own payment proof"
ON storage.objects FOR SELECT
TO authenticated
USING (
  bucket_id = 'payment-proofs'
  AND (
    auth.uid()::text = (storage.foldername(name))[1]
    OR has_role(auth.uid(), 'admin'::app_role)
  )
);

-- Users can update their own (re-upload)
DROP POLICY IF EXISTS "Users update own payment proof" ON storage.objects;
CREATE POLICY "Users update own payment proof"
ON storage.objects FOR UPDATE
TO authenticated
USING (
  bucket_id = 'payment-proofs'
  AND auth.uid()::text = (storage.foldername(name))[1]
);

-- Admins can delete
DROP POLICY IF EXISTS "Admins delete payment proofs" ON storage.objects;
CREATE POLICY "Admins delete payment proofs"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'payment-proofs'
  AND has_role(auth.uid(), 'admin'::app_role)
);

-- Anonymous (public) can also upload — needed because new participants self-register before login.
-- Folder must be 'anon' to namespace these uploads.
DROP POLICY IF EXISTS "Anon upload payment proof" ON storage.objects;
CREATE POLICY "Anon upload payment proof"
ON storage.objects FOR INSERT
TO anon
WITH CHECK (
  bucket_id = 'payment-proofs'
  AND (storage.foldername(name))[1] = 'anon'
);
