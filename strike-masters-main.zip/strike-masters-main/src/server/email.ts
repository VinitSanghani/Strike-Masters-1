// Gmail-based email sender via Lovable connector gateway.
// Sends from the connected Gmail account (strikemasters.in@gmail.com).

const GATEWAY_URL = "https://connector-gateway.lovable.dev/google_mail/gmail/v1";
export const ADMIN_EMAIL = "strikemasters.in@gmail.com";
const FROM_NAME = "Strike Masters";

function b64url(input: string): string {
  // UTF-8 safe base64url
  const bytes = new TextEncoder().encode(input);
  let bin = "";
  for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
  return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function buildRaw(to: string, subject: string, html: string, text: string): string {
  const boundary = "sm_" + Math.random().toString(36).slice(2);
  const headers = [
    `From: ${FROM_NAME} <${ADMIN_EMAIL}>`,
    `To: ${to}`,
    `Subject: ${subject}`,
    "MIME-Version: 1.0",
    `Content-Type: multipart/alternative; boundary="${boundary}"`,
  ].join("\r\n");

  const body = [
    "",
    `--${boundary}`,
    'Content-Type: text/plain; charset="UTF-8"',
    "Content-Transfer-Encoding: 7bit",
    "",
    text,
    "",
    `--${boundary}`,
    'Content-Type: text/html; charset="UTF-8"',
    "Content-Transfer-Encoding: 7bit",
    "",
    html,
    "",
    `--${boundary}--`,
    "",
  ].join("\r\n");

  return b64url(headers + "\r\n" + body);
}

export async function sendGmail(opts: {
  to: string;
  subject: string;
  html: string;
  text: string;
}): Promise<void> {
  const lovableKey = process.env.LOVABLE_API_KEY;
  const gmailKey = process.env.GOOGLE_MAIL_API_KEY;
  if (!lovableKey || !gmailKey) {
    console.warn("[email] Gmail connector not configured; skipping send to", opts.to);
    return;
  }

  try {
    const raw = buildRaw(opts.to, opts.subject, opts.html, opts.text);
    const res = await fetch(`${GATEWAY_URL}/users/me/messages/send`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${lovableKey}`,
        "X-Connection-Api-Key": gmailKey,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ raw }),
    });
    if (!res.ok) {
      const errBody = await res.text();
      console.error(`[email] Gmail send failed [${res.status}] to=${opts.to}: ${errBody}`);
    }
  } catch (err) {
    console.error("[email] Gmail send error:", err);
  }
}

function esc(s: string | null | undefined): string {
  if (s == null) return "";
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function shell(title: string, bodyHtml: string): string {
  return `<!doctype html><html><body style="margin:0;padding:0;background:#f6f7f9;font-family:Arial,Helvetica,sans-serif;color:#1a1a1a">
<div style="max-width:560px;margin:0 auto;padding:24px">
  <div style="background:#0f172a;color:#fff;padding:20px 24px;border-radius:12px 12px 0 0">
    <div style="font-size:20px;font-weight:700;letter-spacing:.5px">STRIKE MASTERS</div>
    <div style="font-size:13px;opacity:.8;margin-top:4px">${title}</div>
  </div>
  <div style="background:#fff;padding:24px;border-radius:0 0 12px 12px;line-height:1.55;font-size:14px">
    ${bodyHtml}
    <hr style="margin:24px 0;border:none;border-top:1px solid #eee"/>
    <div style="font-size:12px;color:#777">Strike Masters Tournament Team<br/>${ADMIN_EMAIL}</div>
  </div>
</div></body></html>`;
}

export function registrationUserEmail(opts: {
  captainName: string;
  teamName: string;
  tournamentName: string;
  paymentMethod: string;
  status: string; // "pending" | "awaiting_verification"
}): { subject: string; html: string; text: string } {
  const niceMethod =
    opts.paymentMethod === "cash"
      ? "Cash"
      : opts.paymentMethod === "upi_qr"
      ? "UPI / QR"
      : "Online";
  const statusLine =
    opts.status === "awaiting_verification"
      ? "Your payment screenshot is under review by our team. Verification usually completes within 24 hours."
      : "Your registration is pending. Please complete the payment as instructed to confirm your slot.";

  const subject = `Registration received — ${opts.tournamentName}`;
  const html = shell(
    "Registration received",
    `
    <p>Hi <b>${esc(opts.captainName)}</b>,</p>
    <p>Thanks for registering <b>${esc(opts.teamName)}</b> for <b>${esc(opts.tournamentName)}</b>.</p>
    <table style="width:100%;border-collapse:collapse;margin:16px 0">
      <tr><td style="padding:6px 0;color:#666">Team</td><td style="padding:6px 0"><b>${esc(opts.teamName)}</b></td></tr>
      <tr><td style="padding:6px 0;color:#666">Tournament</td><td style="padding:6px 0"><b>${esc(opts.tournamentName)}</b></td></tr>
      <tr><td style="padding:6px 0;color:#666">Payment method</td><td style="padding:6px 0"><b>${esc(niceMethod)}</b></td></tr>
      <tr><td style="padding:6px 0;color:#666">Status</td><td style="padding:6px 0"><b>${esc(opts.status.replace(/_/g, " "))}</b></td></tr>
    </table>
    <p>${esc(statusLine)}</p>
    <p>You can <b>log in any time</b> with your captain email to view your registration, payment status and tournament details.</p>
    <p>Good luck on the carrom board! 🎯</p>
    `,
  );
  const text = `Hi ${opts.captainName},

Thanks for registering ${opts.teamName} for ${opts.tournamentName}.

Payment method: ${niceMethod}
Status: ${opts.status.replace(/_/g, " ")}

${statusLine}

Log in any time with your captain email to view your registration and payment status.

— Strike Masters`;
  return { subject, html, text };
}

export function registrationAdminEmail(opts: {
  captainName: string;
  captainEmail: string;
  captainPhone: string;
  teamName: string;
  tournamentName: string;
  paymentMethod: string;
  upiTransactionRef?: string | null;
}): { subject: string; html: string; text: string } {
  const subject = `New registration — ${opts.teamName} (${opts.tournamentName})`;
  const html = shell(
    "New tournament registration",
    `
    <p>A new team has registered.</p>
    <table style="width:100%;border-collapse:collapse;margin:16px 0">
      <tr><td style="padding:6px 0;color:#666">Tournament</td><td style="padding:6px 0"><b>${esc(opts.tournamentName)}</b></td></tr>
      <tr><td style="padding:6px 0;color:#666">Team</td><td style="padding:6px 0"><b>${esc(opts.teamName)}</b></td></tr>
      <tr><td style="padding:6px 0;color:#666">Captain</td><td style="padding:6px 0">${esc(opts.captainName)}</td></tr>
      <tr><td style="padding:6px 0;color:#666">Email</td><td style="padding:6px 0">${esc(opts.captainEmail)}</td></tr>
      <tr><td style="padding:6px 0;color:#666">Phone</td><td style="padding:6px 0">${esc(opts.captainPhone)}</td></tr>
      <tr><td style="padding:6px 0;color:#666">Payment method</td><td style="padding:6px 0">${esc(opts.paymentMethod)}</td></tr>
      ${opts.upiTransactionRef ? `<tr><td style="padding:6px 0;color:#666">UTR / Ref</td><td style="padding:6px 0">${esc(opts.upiTransactionRef)}</td></tr>` : ""}
    </table>
    <p>Open the <b>Admin → Payments</b> tab to verify the screenshot and approve the registration.</p>
    `,
  );
  const text = `New registration

Tournament: ${opts.tournamentName}
Team: ${opts.teamName}
Captain: ${opts.captainName}
Email: ${opts.captainEmail}
Phone: ${opts.captainPhone}
Payment: ${opts.paymentMethod}
${opts.upiTransactionRef ? `UTR/Ref: ${opts.upiTransactionRef}\n` : ""}
Open Admin → Payments to verify.`;
  return { subject, html, text };
}

export function paymentVerifiedEmail(opts: {
  captainName: string;
  teamName: string;
  tournamentName: string;
  notes?: string | null;
}): { subject: string; html: string; text: string } {
  const subject = `Payment confirmed — ${opts.tournamentName}`;
  const html = shell(
    "Payment confirmed ✅",
    `
    <p>Hi <b>${esc(opts.captainName)}</b>,</p>
    <p>Great news — your payment for <b>${esc(opts.teamName)}</b> has been <b>verified</b> and your slot in <b>${esc(opts.tournamentName)}</b> is now <b>confirmed</b>.</p>
    ${opts.notes ? `<p style="background:#f6f7f9;padding:10px 14px;border-radius:8px"><b>Note from admin:</b> ${esc(opts.notes)}</p>` : ""}
    <p>Log in to your dashboard to view fixtures, schedule and updates as the tournament approaches.</p>
    <p>See you on the board! 🎯</p>
    `,
  );
  const text = `Hi ${opts.captainName},

Your payment for ${opts.teamName} has been verified. Your slot in ${opts.tournamentName} is confirmed.
${opts.notes ? `\nNote from admin: ${opts.notes}\n` : ""}
Log in to your dashboard for fixtures and updates.

— Strike Masters`;
  return { subject, html, text };
}

export function paymentRejectedEmail(opts: {
  captainName: string;
  teamName: string;
  tournamentName: string;
  notes?: string | null;
}): { subject: string; html: string; text: string } {
  const subject = `Action needed — Payment proof rejected (${opts.tournamentName})`;
  const html = shell(
    "Payment proof needs attention",
    `
    <p>Hi <b>${esc(opts.captainName)}</b>,</p>
    <p>We reviewed the payment proof submitted for <b>${esc(opts.teamName)}</b> in <b>${esc(opts.tournamentName)}</b> and unfortunately it could not be verified.</p>
    <p style="background:#fff5f5;padding:10px 14px;border-radius:8px;border:1px solid #fed7d7"><b>Reason:</b> ${esc(opts.notes || "Payment proof was rejected. Please re-submit a clearer screenshot or correct UTR.")}</p>
    <p>Please log in to your dashboard and <b>re-submit the payment screenshot</b> so we can confirm your slot.</p>
    `,
  );
  const text = `Hi ${opts.captainName},

The payment proof for ${opts.teamName} in ${opts.tournamentName} could not be verified.

Reason: ${opts.notes || "Payment proof was rejected. Please re-submit."}

Please log in and re-submit the payment screenshot.

— Strike Masters`;
  return { subject, html, text };
}
