import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

interface SponsorRow {
  id: string;
  name: string;
  logo_url: string | null;
  link_url: string | null;
}

/**
 * Auto-scrolling sponsor row for a tournament.
 * Logos are 280×220 on desktop, scaled down on mobile.
 * The strip is hidden if the tournament has no active sponsors.
 */
export function TournamentSponsorsStrip({ tournamentId }: { tournamentId: string }) {
  const [items, setItems] = useState<SponsorRow[]>([]);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const { data } = await supabase
        .from("tournament_sponsors")
        .select("id, name, logo_url, link_url")
        .eq("tournament_id", tournamentId)
        .eq("active", true)
        .order("sort_order", { ascending: true })
        .order("created_at", { ascending: true });
      if (cancelled) return;
      setItems((data ?? []) as SponsorRow[]);
      setLoaded(true);
    })();
    return () => { cancelled = true; };
  }, [tournamentId]);

  if (!loaded || items.length === 0) return null;

  // Duplicate the list so the marquee animates seamlessly.
  const loop = [...items, ...items];

  return (
    <section className="container mx-auto px-4 sm:px-6 py-8">
      <div className="text-center text-[10px] uppercase tracking-[0.3em] text-muted-foreground mb-4">
        Our Sponsors
      </div>
      <div
        className="group relative overflow-hidden rounded-2xl border border-border bg-card/40"
        style={{
          maskImage:
            "linear-gradient(to right, transparent 0, black 6%, black 94%, transparent 100%)",
          WebkitMaskImage:
            "linear-gradient(to right, transparent 0, black 6%, black 94%, transparent 100%)",
        }}
      >
        <div
          className="flex w-max gap-4 sm:gap-6 py-4 sm:py-5 animate-[sponsor-marquee_40s_linear_infinite] group-hover:[animation-play-state:paused]"
        >
          {loop.map((s, i) => {
            const inner = (
              <div className="flex items-center justify-center h-full w-full p-3 sm:p-5 bg-background/60">
                {s.logo_url ? (
                  <img
                    src={s.logo_url}
                    alt={s.name}
                    loading="lazy"
                    className="max-h-full max-w-full object-contain"
                  />
                ) : (
                  <div className="font-display text-sm sm:text-lg text-muted-foreground text-center">
                    {s.name}
                  </div>
                )}
              </div>
            );
            return (
              <div
                key={`${s.id}-${i}`}
                className="shrink-0 rounded-xl border border-border overflow-hidden
                  w-[160px] h-[120px]
                  sm:w-[220px] sm:h-[170px]
                  md:w-[280px] md:h-[220px]"
              >
                {s.link_url ? (
                  <a
                    href={s.link_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block h-full w-full"
                    aria-label={s.name}
                  >
                    {inner}
                  </a>
                ) : (
                  inner
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
