import { createFileRoute } from "@tanstack/react-router";
import { SectionHeader } from "@/components/SectionHeader";

export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: [
      { title: "Privacy Policy — Strike Masters Bowling Tournament 2026" },
      { name: "description", content: "How Strike Masters collects, uses, and protects your personal information." },
      { property: "og:title", content: "Privacy Policy — Strike Masters 2026" },
      { property: "og:description", content: "How we handle your personal information." },
    ],
  }),
  component: PrivacyPage,
});

function PrivacyPage() {
  return (
    <div className="container mx-auto px-4 sm:px-6 py-14 sm:py-20">
      <SectionHeader
        eyebrow="Legal"
        title="Privacy Policy"
        description="Last updated: April 2026. This policy explains how we handle your data."
      />

      <div className="max-w-3xl mx-auto rounded-2xl border border-border bg-card/50 p-6 sm:p-10 space-y-8">
        <Section title="1. Information We Collect">
          We collect information you provide when registering — name, email, phone number, team
          details, and payment reference. We also collect basic usage data (IP address, browser
          type, pages visited) to improve the site.
        </Section>
        <Section title="2. How We Use Your Information">
          Your data is used to process your registration, send tournament updates, share schedule
          changes, verify payments, and announce results. We never sell your data to third parties.
        </Section>
        <Section title="3. Data Sharing">
          We share information only with our payment processor and venue staff for tournament
          operations. Team names and scores may be displayed publicly during the event.
        </Section>
        <Section title="4. Data Security">
          We use industry-standard encryption for data in transit. Payment details are not stored
          on our servers — only references are kept for verification.
        </Section>
        <Section title="5. Your Rights">
          You can request a copy of your data, ask us to correct inaccuracies, or request deletion
          at any time by emailing <span className="text-neon">privacy@strikemasters.com</span>.
        </Section>
        <Section title="6. Cookies">
          We use minimal cookies for site functionality and analytics. You can disable cookies in
          your browser settings without affecting registration.
        </Section>
        <Section title="7. Contact">
          Questions about this policy? Reach out at <span className="text-neon">privacy@strikemasters.com</span>.
        </Section>
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h3 className="font-display text-xl text-neon mb-2">{title}</h3>
      <p className="text-sm text-muted-foreground leading-relaxed">{children}</p>
    </div>
  );
}
