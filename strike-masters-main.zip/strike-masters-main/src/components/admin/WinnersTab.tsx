import { useEffect, useState } from "react";
import { Loader2, Plus, Trash2, Save, X, Crown, Edit3 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface TournamentMini { id: string; name: string; number_of_winners: number; status: string; }
interface Winner {
  id: string;
  tournament_id: string;
  registration_id: string | null;
  place: number;
  place_label: string;
  prize_title: string | null;
  prize_amount: number | null;
  notes: string | null;
}
interface Reg { id: string; team_name: string; captain_name: string; }

const PLACE_LABELS: Record<number, string> = { 1: "1st Place — Champion", 2: "2nd Place — Runner-Up", 3: "3rd Place" };

export function WinnersTab() {
  const [tournaments, setTournaments] = useState<TournamentMini[]>([]);
  const [tid, setTid] = useState<string>("");
  const [winners, setWinners] = useState<Winner[]>([]);
  const [regs, setRegs] = useState<Reg[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<Partial<Winner> | null>(null);

  useEffect(() => {
    (async () => {
      const { data } = await supabase.from("tournaments").select("id, name, number_of_winners, status").order("created_at", { ascending: false });
      const list = (data ?? []) as TournamentMini[];
      setTournaments(list);
      if (list.length && !tid) setTid(list[0].id);
      setLoading(false);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const refresh = async (tournamentId: string) => {
    const [{ data: w }, { data: r }] = await Promise.all([
      supabase.from("tournament_winners").select("*").eq("tournament_id", tournamentId).order("place"),
      supabase.from("registrations").select("id, team_name, captain_name").eq("tournament_id", tournamentId).eq("payment_status", "verified"),
    ]);
    setWinners((w ?? []) as Winner[]);
    setRegs((r ?? []) as Reg[]);
  };

  useEffect(() => { if (tid) refresh(tid); }, [tid]);

  const t = tournaments.find((x) => x.id === tid);
  const filledPlaces = new Set(winners.map((w) => w.place));
  const targetCount = t?.number_of_winners ?? 3;

  const save = async () => {
    if (!editing || !tid) return;
    if (!editing.place || !editing.place_label) return toast.error("Place is required");
    const payload = {
      tournament_id: tid,
      registration_id: editing.registration_id || null,
      place: editing.place,
      place_label: editing.place_label,
      prize_title: editing.prize_title || null,
      prize_amount: editing.prize_amount ?? null,
      notes: editing.notes || null,
    };
    const { error } = editing.id
      ? await supabase.from("tournament_winners").update(payload).eq("id", editing.id)
      : await supabase.from("tournament_winners").insert(payload);
    if (error) return toast.error(error.message);
    toast.success("Winner saved");
    setEditing(null);
    await refresh(tid);
  };

  const remove = async (id: string) => {
    if (!confirm("Remove this winner?")) return;
    const { error } = await supabase.from("tournament_winners").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Removed");
    await refresh(tid);
  };

  const addPlace = (place: number) => {
    setEditing({ place, place_label: PLACE_LABELS[place] ?? `${place}th Place` });
  };

  if (loading) return <div className="text-center py-12"><Loader2 className="w-6 h-6 mx-auto animate-spin text-neon" /></div>;

  if (!tournaments.length) {
    return <div className="rounded-2xl border border-dashed border-border p-10 text-center text-sm text-muted-foreground">Create a tournament first.</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center gap-3">
        <label className="text-[10px] uppercase tracking-widest text-muted-foreground">Tournament</label>
        <select value={tid} onChange={(e) => setTid(e.target.value)} className="px-3 py-2 rounded-md bg-input/60 border border-border text-sm">
          {tournaments.map((x) => <option key={x.id} value={x.id}>{x.name} · {x.status}</option>)}
        </select>
        {t && <span className="text-xs text-muted-foreground">Configured for <span className="text-neon font-bold">{t.number_of_winners}</span> winner places.</span>}
      </div>

      {/* Quick-add buttons for unfilled standard places */}
      <div className="flex flex-wrap gap-2">
        {Array.from({ length: targetCount }, (_, i) => i + 1).map((p) => (
          <button
            key={p}
            disabled={filledPlaces.has(p)}
            onClick={() => addPlace(p)}
            className={`inline-flex items-center gap-2 px-3 py-2 rounded-md text-xs uppercase tracking-wider font-bold border ${
              filledPlaces.has(p)
                ? "border-success/40 text-success cursor-not-allowed opacity-60"
                : "border-neon/40 text-neon hover:bg-neon/10"
            }`}
          >
            <Plus size={12} /> {PLACE_LABELS[p] ?? `${p}th Place`}
          </button>
        ))}
        <button
          onClick={() => addPlace(Math.max(targetCount, ...winners.map((w) => w.place), 0) + 1)}
          className="inline-flex items-center gap-2 px-3 py-2 rounded-md text-xs uppercase tracking-wider font-bold border border-border hover:border-neon"
        >
          <Plus size={12} /> Additional Award
        </button>
      </div>

      {winners.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border p-10 text-center text-sm text-muted-foreground">
          <Crown className="w-10 h-10 mx-auto text-gold mb-2" /> No winners assigned yet.
        </div>
      ) : (
        <div className="space-y-3">
          {winners.map((w) => {
            const reg = regs.find((r) => r.id === w.registration_id);
            return (
              <div key={w.id} className="rounded-2xl border border-gold/30 bg-gradient-to-r from-card via-gold/5 to-card p-5 shadow-glow flex items-center justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-baseline gap-2 mb-1">
                    <span className="font-display text-2xl text-gold">#{w.place}</span>
                    <span className="font-display text-base">{w.place_label}</span>
                  </div>
                  <div className="text-sm">
                    {reg ? (
                      <span><span className="text-neon font-bold">{reg.team_name}</span> · <span className="text-muted-foreground">{reg.captain_name}</span></span>
                    ) : (
                      <span className="text-muted-foreground italic">No team linked</span>
                    )}
                  </div>
                  {(w.prize_title || w.prize_amount) && (
                    <div className="text-xs text-muted-foreground mt-1">
                      {w.prize_title && <span>{w.prize_title}</span>}
                      {w.prize_amount != null && <span> · ₹{w.prize_amount.toLocaleString("en-IN")}</span>}
                    </div>
                  )}
                  {w.notes && <p className="text-xs text-muted-foreground mt-1 italic">{w.notes}</p>}
                </div>
                <div className="flex items-center gap-1">
                  <button onClick={() => setEditing(w)} className="p-1.5 rounded text-neon hover:bg-neon/10"><Edit3 size={14} /></button>
                  <button onClick={() => remove(w.id)} className="p-1.5 rounded text-destructive hover:bg-destructive/10"><Trash2 size={14} /></button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {editing && (
        <WinnerModal value={editing} regs={regs} onChange={setEditing} onSave={save} onClose={() => setEditing(null)} />
      )}
    </div>
  );
}

function WinnerModal({
  value, regs, onChange, onSave, onClose,
}: {
  value: Partial<Winner>;
  regs: Reg[];
  onChange: (v: Partial<Winner>) => void;
  onSave: () => void;
  onClose: () => void;
}) {
  const inputCls = "w-full px-3 py-2 rounded-md bg-input/60 border border-border text-sm focus:border-neon focus:outline-none";
  const labelCls = "block text-[10px] uppercase tracking-widest text-muted-foreground mb-1";
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur" onClick={onClose}>
      <div className="w-full max-w-lg rounded-2xl border border-border bg-card p-6 shadow-glow max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display text-xl text-gold">{value.id ? "Edit Winner" : "Add Winner"}</h3>
          <button onClick={onClose} className="p-2 hover:bg-accent rounded"><X size={16} /></button>
        </div>
        <div className="space-y-3">
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className={labelCls}>Place #</label>
              <input type="number" min={1} className={inputCls} value={value.place ?? ""} onChange={(e) => onChange({ ...value, place: parseInt(e.target.value) || 1 })} />
            </div>
            <div className="col-span-2">
              <label className={labelCls}>Place Label</label>
              <input className={inputCls} value={value.place_label ?? ""} onChange={(e) => onChange({ ...value, place_label: e.target.value })} placeholder="e.g. 1st Place — Champion" />
            </div>
          </div>
          <div>
            <label className={labelCls}>Winning Team</label>
            <select className={inputCls} value={value.registration_id ?? ""} onChange={(e) => onChange({ ...value, registration_id: e.target.value || null })}>
              <option value="">— Select team —</option>
              {regs.map((r) => <option key={r.id} value={r.id}>{r.team_name} · {r.captain_name}</option>)}
            </select>
          </div>
          <div className="grid sm:grid-cols-2 gap-3">
            <div>
              <label className={labelCls}>Prize Title</label>
              <input className={inputCls} value={value.prize_title ?? ""} onChange={(e) => onChange({ ...value, prize_title: e.target.value })} placeholder="e.g. Cash Prize + Trophy" />
            </div>
            <div>
              <label className={labelCls}>Prize Amount (₹)</label>
              <input type="number" min={0} className={inputCls} value={value.prize_amount ?? ""} onChange={(e) => onChange({ ...value, prize_amount: e.target.value ? parseInt(e.target.value) : null })} />
            </div>
          </div>
          <div>
            <label className={labelCls}>Notes</label>
            <textarea rows={2} className={inputCls} value={value.notes ?? ""} onChange={(e) => onChange({ ...value, notes: e.target.value })} />
          </div>
        </div>
        <div className="mt-5 flex justify-end gap-2">
          <button onClick={onClose} className="px-4 py-2 rounded-md border border-border text-xs uppercase tracking-wider font-bold">Cancel</button>
          <button onClick={onSave} className="inline-flex items-center gap-2 px-4 py-2 rounded-md bg-gradient-to-r from-gold to-amber-500 text-background text-xs uppercase tracking-wider font-bold">
            <Save size={14} /> Save
          </button>
        </div>
      </div>
    </div>
  );
}
