DROP VIEW IF EXISTS public.registrations_public;

CREATE OR REPLACE FUNCTION public.get_public_registrations(_tournament_id uuid)
RETURNS TABLE (id uuid, tournament_id uuid, team_name text, captain_name text)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT id, tournament_id, team_name, captain_name
  FROM public.registrations
  WHERE payment_status = 'verified'
    AND (_tournament_id IS NULL OR tournament_id = _tournament_id);
$$;

REVOKE ALL ON FUNCTION public.get_public_registrations(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_public_registrations(uuid) TO anon, authenticated;