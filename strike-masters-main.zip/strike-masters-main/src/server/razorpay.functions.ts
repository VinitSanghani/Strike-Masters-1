import { createServerFn } from "@tanstack/react-start";
import { createHmac, timingSafeEqual } from "crypto";
import { z } from "zod";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import {
  sendGmail,
  registrationUserEmail,
  registrationAdminEmail,
  paymentVerifiedEmail,
  paymentRejectedEmail,
  ADMIN_EMAIL,
} from "./email";

type PaymentMethod = "online" | "cash" | "upi_qr";

interface ResolvedTournament {
  id: string;
  slug: string;
  name: string;
  registration_open: boolean;
  registration_open_date: string | null;
  registration_close_date: string | null;
  registration_fee: number;
  max_teams: number | null;
  status: string;
  payment_methods: string[];
  payment_required: boolean;
  team_size: number;
  tournament_type: string;
  cash_payment_deadline: string | null;
  auto_confirm_online: boolean;
}

const TOURNAMENT_FIELDS =
  "id, slug, name, registration_open, registration_open_date, registration_close_date, registration_fee, max_teams, status, payment_methods, payment_required, team_size, tournament_type, cash_payment_deadline, auto_confirm_online";

function isWithinRegistrationWindow(t: { registration_open: boolean; status: string; registration_open_date: string | null; registration_close_date: string | null; }): { ok: boolean; reason?: string } {
  if (t.status === "completed" || t.status === "archived") return { ok: false, reason: "Tournament has ended." };
  if (!t.registration_open) return { ok: false, reason: "Registration is currently closed for this tournament." };
  const now = new Date();
  if (t.registration_open_date) {
    const openAt = new Date(t.registration_open_date);
    if (!Number.isNaN(openAt.getTime()) && now < openAt) {
      return { ok: false, reason: `Registration opens on ${openAt.toISOString().slice(0, 10)}.` };
    }
  }
  if (t.registration_close_date) {
    const closeRaw = t.registration_close_date;
    const closeAt = new Date(closeRaw);
    if (!Number.isNaN(closeAt.getTime())) {
      const isDateOnly = /^\d{4}-\d{2}-\d{2}$/.test(closeRaw);
      const effective = isDateOnly
        ? new Date(closeAt.getFullYear(), closeAt.getMonth(), closeAt.getDate(), 23, 59, 59, 999)
        : closeAt;
      if (now > effective) return { ok: false, reason: "Registration window has closed for this tournament." };
    }
  }
  return { ok: true };
}

async function resolveTournamentBySlug(slug?: string | null): Promise<ResolvedTournament | null> {
  if (slug) {
    const { data } = await supabaseAdmin
      .from("tournaments")
      .select(TOURNAMENT_FIELDS)
      .eq("slug", slug)
      .maybeSingle();
    if (data) return data as ResolvedTournament;
  }
  const { data: featured } = await supabaseAdmin
    .from("tournaments")
    .select(TOURNAMENT_FIELDS)
    .eq("featured", true)
    .neq("status", "draft")
    .neq("status", "archived")
    .maybeSingle();
  if (featured) return featured as ResolvedTournament;
  const { data: active } = await supabaseAdmin
    .from("tournaments")
    .select(TOURNAMENT_FIELDS)
    .in("status", ["active", "upcoming"])
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  return (active as ResolvedTournament) ?? null;
}

// Public config: returns key id + fee. Legacy single-event call still works.
export const getPaymentConfig = createServerFn({ method: "GET" }).handler(async () => {
  const keyId = process.env.RAZORPAY_KEY_ID;
  if (!keyId) throw new Error("Razorpay not configured");
  const t = await resolveTournamentBySlug(null);
  if (t) {
    return { keyId, fee: t.registration_fee, currency: "INR" };
  }
  return { keyId, fee: 3000, currency: "INR" };
});

// Pre-flight check scoped to a tournament
export const checkRegistrationEligibility = createServerFn({ method: "POST" })
  .inputValidator(
    z.object({
      teamName: z.string().trim().min(2).max(80),
      email: z.string().trim().email().max(255),
      tournamentSlug: z.string().trim().min(1).max(80).optional().nullable(),
    }).parse,
  )
  .handler(async ({ data }) => {
    const tournament = await resolveTournamentBySlug(data.tournamentSlug);
    const tournamentId = tournament?.id ?? null;

    // Only block on VERIFIED registrations — pending/awaiting/rejected are not duplicates
    const baseTeamQuery = supabaseAdmin
      .from("registrations")
      .select("id")
      .ilike("team_name", data.teamName.trim())
      .eq("payment_status", "verified");
    const teamQ = tournamentId
      ? baseTeamQuery.eq("tournament_id", tournamentId)
      : baseTeamQuery.is("tournament_id", null);
    const { data: existingByTeam } = await teamQ.maybeSingle();

    if (existingByTeam) {
      return {
        ok: false as const,
        reason: "team_name_taken",
        message: `The team name "${data.teamName}" is already registered for this tournament. Please choose a different name.`,
      };
    }

    const baseEmailQuery = supabaseAdmin
      .from("registrations")
      .select("id, team_name")
      .ilike("captain_email", data.email.trim())
      .eq("payment_status", "verified");
    const emailQ = tournamentId
      ? baseEmailQuery.eq("tournament_id", tournamentId)
      : baseEmailQuery.is("tournament_id", null);
    const { data: existingByEmail } = await emailQ.maybeSingle();

    if (existingByEmail) {
      return {
        ok: false as const,
        reason: "email_already_registered",
        message: `${data.email} is already registered for this tournament (team "${existingByEmail.team_name}"). Please log in to your dashboard.`,
      };
    }

    return { ok: true as const, tournamentId, tournamentName: tournament?.name ?? null };
  });

// Create Razorpay order on backend — no auth required
export const createPaymentOrder = createServerFn({ method: "POST" })
  .inputValidator(
    z.object({
      teamName: z.string().min(2).max(80),
      email: z.string().email().max(255),
      tournamentSlug: z.string().min(1).max(80).optional().nullable(),
    }).parse,
  )
  .handler(async ({ data }) => {
    const keyId = process.env.RAZORPAY_KEY_ID;
    const keySecret = process.env.RAZORPAY_KEY_SECRET;
    if (!keyId || !keySecret) throw new Error("Razorpay not configured");

    const tournament = await resolveTournamentBySlug(data.tournamentSlug);

    let feeInr: number;
    let windowCheck: { ok: boolean; reason?: string } = { ok: false, reason: "Registration is currently closed for this tournament." };
    let tournamentId: string | null = null;
    let tournamentName: string | null = null;

    if (tournament) {
      tournamentId = tournament.id;
      tournamentName = tournament.name;
      feeInr = tournament.registration_fee;
      windowCheck = isWithinRegistrationWindow(tournament);
      if (!tournament.payment_methods.includes("online")) {
        throw new Error("Online payment is not enabled for this tournament.");
      }

      // Capacity check
      if (tournament.max_teams) {
        const { count } = await supabaseAdmin
          .from("registrations")
          .select("id", { count: "exact", head: true })
          .eq("tournament_id", tournament.id)
          .eq("payment_status", "verified");
        if ((count ?? 0) >= tournament.max_teams) {
          throw new Error("This tournament is sold out.");
        }
      }
    } else {
      throw new Error("No tournament found for online payment.");
    }

    if (!windowCheck.ok) throw new Error(windowCheck.reason ?? "Registration is currently closed for this tournament.");
    const amountPaise = feeInr * 100;

    const auth = Buffer.from(`${keyId}:${keySecret}`).toString("base64");
    const receipt = `sm-${Date.now().toString(36)}`;

    const res = await fetch("https://api.razorpay.com/v1/orders", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Basic ${auth}`,
      },
      body: JSON.stringify({
        amount: amountPaise,
        currency: "INR",
        receipt,
        notes: {
          team_name: data.teamName,
          email: data.email,
          tournament_id: tournamentId ?? "",
        },
      }),
    });

    if (!res.ok) {
      const text = await res.text();
      console.error("Razorpay order error:", res.status, text);
      throw new Error("Failed to create payment order");
    }

    const order = (await res.json()) as { id: string; amount: number; currency: string };
    return {
      orderId: order.id,
      amount: order.amount,
      currency: order.currency,
      keyId,
      tournamentId,
      tournamentName,
    };
  });

// Shared registration payload schema
const registrationFields = z.object({
  teamName: z.string().min(2).max(80),
  captainName: z.string().min(2).max(80),
  captainEmail: z.string().email().max(255),
  captainPhone: z.string().min(7).max(20),
  password: z.string().min(6).max(100),
  player2Name: z.string().max(80).optional().nullable(),
  player2Phone: z.string().max(20).optional().nullable(),
  player3Name: z.string().max(80).optional().nullable(),
  player3Phone: z.string().max(20).optional().nullable(),
  player4Name: z.string().max(80).optional().nullable(),
  player4Phone: z.string().max(20).optional().nullable(),
  player5Name: z.string().max(80).optional().nullable(),
  player5Phone: z.string().max(20).optional().nullable(),
});

// Create or fetch user account, then return userId
async function createOrLinkAccount(email: string, password: string, captainName: string, teamName: string): Promise<string> {
  const { data: created, error: createErr } = await supabaseAdmin.auth.admin.createUser({
    email,
    password,
    email_confirm: true,
    user_metadata: { captain_name: captainName, team_name: teamName },
  });

  if (createErr) {
    if (/already|registered|exists/i.test(createErr.message)) {
      // Find existing user across paginated results
      let found: { id: string; email_confirmed_at: string | null } | null = null;
      for (let page = 1; page <= 20 && !found; page++) {
        const { data: list } = await supabaseAdmin.auth.admin.listUsers({ page, perPage: 200 });
        const u = list?.users.find((x) => x.email?.toLowerCase() === email);
        if (u) found = { id: u.id, email_confirmed_at: u.email_confirmed_at ?? null };
        if (!list?.users || list.users.length < 200) break;
      }
      if (!found) throw new Error("Could not link existing account.");
      // Force-confirm email if previously unconfirmed so user can log in immediately
      if (!found.email_confirmed_at) {
        await supabaseAdmin.auth.admin.updateUserById(found.id, { email_confirm: true });
      }
      return found.id;
    }
    console.error("Create user error:", createErr);
    throw new Error("Could not create your account. Please contact support.");
  }
  if (!created.user?.id) throw new Error("Account creation failed");
  return created.user.id;
}

// Verify Razorpay payment, create user account, finalize registration
export const verifyAndCreateRegistration = createServerFn({ method: "POST" })
  .inputValidator(
    z.object({
      razorpay_order_id: z.string().min(1),
      razorpay_payment_id: z.string().min(1),
      razorpay_signature: z.string().min(1),
      tournamentSlug: z.string().min(1).max(80).optional().nullable(),
      registration: registrationFields,
    }).parse,
  )
  .handler(async ({ data }) => {
    const keySecret = process.env.RAZORPAY_KEY_SECRET;
    if (!keySecret) throw new Error("Razorpay not configured");

    const expected = createHmac("sha256", keySecret)
      .update(`${data.razorpay_order_id}|${data.razorpay_payment_id}`)
      .digest("hex");
    const expectedBuf = Buffer.from(expected, "hex");
    const receivedBuf = Buffer.from(data.razorpay_signature, "hex");
    if (expectedBuf.length !== receivedBuf.length || !timingSafeEqual(expectedBuf, receivedBuf)) {
      throw new Error("Invalid payment signature");
    }

    const keyId = process.env.RAZORPAY_KEY_ID!;
    const auth = Buffer.from(`${keyId}:${keySecret}`).toString("base64");
    const payRes = await fetch(`https://api.razorpay.com/v1/payments/${data.razorpay_payment_id}`, {
      headers: { Authorization: `Basic ${auth}` },
    });
    if (!payRes.ok) throw new Error("Could not verify payment with Razorpay");
    const payment = (await payRes.json()) as { status: string; amount: number; order_id: string };
    if (payment.order_id !== data.razorpay_order_id) throw new Error("Payment/order mismatch");
    if (!["captured", "authorized"].includes(payment.status)) {
      throw new Error(`Payment not successful (status: ${payment.status})`);
    }

    const tournament = await resolveTournamentBySlug(data.tournamentSlug);
    const tournamentId = tournament?.id ?? null;

    const r = data.registration;
    const email = r.captainEmail.trim().toLowerCase();
    const userId = await createOrLinkAccount(email, r.password, r.captainName, r.teamName);

    // Final duplicate guard
    const baseDup = supabaseAdmin
      .from("registrations")
      .select("id")
      .eq("user_id", userId)
      .eq("payment_status", "verified");
    const dupQ = tournamentId ? baseDup.eq("tournament_id", tournamentId) : baseDup.is("tournament_id", null);
    const { data: existing } = await dupQ.maybeSingle();
    if (existing) return { registrationId: existing.id, alreadyRegistered: true };

    const { data: inserted, error } = await supabaseAdmin
      .from("registrations")
      .insert({
        user_id: userId,
        tournament_id: tournamentId,
        team_name: r.teamName,
        captain_name: r.captainName,
        captain_email: email,
        captain_phone: r.captainPhone,
        player2_name: r.player2Name || "",
        player2_phone: r.player2Phone || null,
        player3_name: r.player3Name || "",
        player3_phone: r.player3Phone || null,
        skill_level: "intermediate",
        razorpay_order_id: data.razorpay_order_id,
        razorpay_payment_id: data.razorpay_payment_id,
        razorpay_signature: data.razorpay_signature,
        amount_paid: payment.amount,
        payment_method: "online",
        payment_status: "verified",
        payment_verified: true,
        payment_transaction_id: data.razorpay_payment_id,
        verified_at: new Date().toISOString(),
      })
      .select("id")
      .single();

    if (error) {
      console.error("Registration insert error:", error);
      throw new Error(error.message);
    }

    // Send notification emails (await so the serverless worker doesn't terminate first)
    const tName = tournament?.name ?? "Strike Masters Tournament";
    const userMail = registrationUserEmail({
      captainName: r.captainName,
      teamName: r.teamName,
      tournamentName: tName,
      paymentMethod: "online",
      status: "verified",
    });
    const adminMail = registrationAdminEmail({
      captainName: r.captainName,
      captainEmail: email,
      captainPhone: r.captainPhone,
      teamName: r.teamName,
      tournamentName: tName,
      paymentMethod: "online",
    });
    await Promise.allSettled([
      sendGmail({ to: email, ...userMail }),
      sendGmail({ to: ADMIN_EMAIL, ...adminMail }),
    ]);

    return { registrationId: inserted.id, alreadyRegistered: false };
  });
export const createManualRegistration = createServerFn({ method: "POST" })
  .inputValidator(
    z.object({
      tournamentSlug: z.string().min(1).max(80).optional().nullable(),
      paymentMethod: z.enum(["cash", "upi_qr"]),
      // Accept either a storage path (e.g. "payment-proofs/foo.png") or a full URL
      paymentProofUrl: z.string().trim().min(1).max(1024).optional().nullable(),
      upiTransactionRef: z.string().trim().max(80).optional().nullable(),
      registration: registrationFields,
    }).parse,
  )
  .handler(async ({ data }) => {
    const tournament = await resolveTournamentBySlug(data.tournamentSlug);
    if (!tournament) throw new Error("Tournament not found.");
    {
      const w = isWithinRegistrationWindow(tournament);
      if (!w.ok) throw new Error(w.reason ?? "Registration is currently closed for this tournament.");
    }
    if (!tournament.payment_methods.includes(data.paymentMethod)) {
      throw new Error(`This tournament does not accept ${data.paymentMethod === "cash" ? "cash" : "UPI / QR"} payments.`);
    }
    if (data.paymentMethod === "upi_qr" && !data.paymentProofUrl) {
      throw new Error("Please upload a payment screenshot before submitting.");
    }

    // Capacity check uses verified count only
    if (tournament.max_teams) {
      const { count } = await supabaseAdmin
        .from("registrations")
        .select("id", { count: "exact", head: true })
        .eq("tournament_id", tournament.id)
        .eq("payment_status", "verified");
      if ((count ?? 0) >= tournament.max_teams) {
        throw new Error("This tournament is sold out.");
      }
    }

    const r = data.registration;
    const email = r.captainEmail.trim().toLowerCase();
    const userId = await createOrLinkAccount(email, r.password, r.captainName, r.teamName);

    // Block exact duplicate verified entry
    const { data: existingVerified } = await supabaseAdmin
      .from("registrations")
      .select("id")
      .eq("user_id", userId)
      .eq("tournament_id", tournament.id)
      .eq("payment_status", "verified")
      .maybeSingle();
    if (existingVerified) {
      return { registrationId: existingVerified.id, alreadyRegistered: true };
    }

    // Block duplicate pending submission
    const { data: existingPending } = await supabaseAdmin
      .from("registrations")
      .select("id, payment_status")
      .eq("user_id", userId)
      .eq("tournament_id", tournament.id)
      .in("payment_status", ["awaiting_verification", "pending"])
      .maybeSingle();
    if (existingPending) {
      return { registrationId: existingPending.id, alreadyRegistered: true };
    }

    const status = data.paymentMethod === "cash" ? "pending" : "awaiting_verification";

    const { data: inserted, error } = await supabaseAdmin
      .from("registrations")
      .insert({
        user_id: userId,
        tournament_id: tournament.id,
        team_name: r.teamName,
        captain_name: r.captainName,
        captain_email: email,
        captain_phone: r.captainPhone,
        player2_name: r.player2Name || "",
        player2_phone: r.player2Phone || null,
        player3_name: r.player3Name || "",
        player3_phone: r.player3Phone || null,
        skill_level: "intermediate",
        amount_paid: tournament.registration_fee * 100,
        payment_method: data.paymentMethod,
        payment_status: status,
        payment_verified: false,
        payment_proof_url: data.paymentProofUrl || null,
        upi_transaction_ref: data.upiTransactionRef || null,
      })
      .select("id")
      .single();

    if (error) {
      console.error("Manual registration insert error:", error);
      throw new Error(error.message);
    }
    // Send notification emails (await so the serverless worker doesn't terminate first)
    const tName = tournament.name;
    const userMail = registrationUserEmail({
      captainName: r.captainName,
      teamName: r.teamName,
      tournamentName: tName,
      paymentMethod: data.paymentMethod,
      status,
    });
    const adminMail = registrationAdminEmail({
      captainName: r.captainName,
      captainEmail: email,
      captainPhone: r.captainPhone,
      teamName: r.teamName,
      tournamentName: tName,
      paymentMethod: data.paymentMethod,
      upiTransactionRef: data.upiTransactionRef,
    });
    await Promise.allSettled([
      sendGmail({ to: email, ...userMail }),
      sendGmail({ to: ADMIN_EMAIL, ...adminMail }),
    ]);

    return { registrationId: inserted.id, alreadyRegistered: false, status };
  });

// User re-uploads payment proof (after rejection)
export const resubmitPaymentProof = createServerFn({ method: "POST" })
  .inputValidator(
    z.object({
      registrationId: z.string().uuid(),
      paymentProofUrl: z.string().trim().min(1).max(1024),
      upiTransactionRef: z.string().trim().max(80).optional().nullable(),
    }).parse,
  )
  .handler(async ({ data }) => {
    const { error } = await supabaseAdmin
      .from("registrations")
      .update({
        payment_proof_url: data.paymentProofUrl,
        upi_transaction_ref: data.upiTransactionRef || null,
        payment_status: "awaiting_verification",
        verification_notes: null,
      })
      .eq("id", data.registrationId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// Admin: get signed URL for a payment proof (path is stored as full public-style URL or storage path)
function extractStoragePath(urlOrPath: string): string {
  // Accepts full URL ending in /payment-proofs/<path>, "payment-proofs/<path>", or bare <path>
  const marker = "/payment-proofs/";
  const idx = urlOrPath.indexOf(marker);
  if (idx >= 0) return urlOrPath.slice(idx + marker.length);
  let p = urlOrPath.replace(/^\/+/, "");
  if (p.startsWith("payment-proofs/")) p = p.slice("payment-proofs/".length);
  return p;
}

export const getPaymentProofSignedUrl = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(
    z.object({ registrationId: z.string().uuid() }).parse,
  )
  .handler(async ({ data, context }) => {
    const { userId } = context;
    const { data: roleRow } = await supabaseAdmin
      .from("user_roles")
      .select("role")
      .eq("user_id", userId)
      .eq("role", "admin")
      .maybeSingle();
    if (!roleRow) throw new Error("Forbidden: admin only");
    const { data: reg, error } = await supabaseAdmin
      .from("registrations")
      .select("payment_proof_url")
      .eq("id", data.registrationId)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!reg?.payment_proof_url) return { url: null as string | null };
    const path = extractStoragePath(reg.payment_proof_url);
    const { data: signed, error: sErr } = await supabaseAdmin.storage
      .from("payment-proofs")
      .createSignedUrl(path, 60 * 30); // 30 min
    if (sErr) {
      console.error("Signed URL error:", sErr);
      throw new Error("Could not load payment proof.");
    }
    return { url: signed.signedUrl };
  });

// Admin: verify or reject a manual payment
export const adminUpdatePaymentStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(
    z.object({
      registrationId: z.string().uuid(),
      action: z.enum(["verify", "reject"]),
      notes: z.string().trim().max(500).optional().nullable(),
    }).parse,
  )
  .handler(async ({ data, context }) => {
    const { userId } = context;
    const { data: roleRow } = await supabaseAdmin
      .from("user_roles")
      .select("role")
      .eq("user_id", userId)
      .eq("role", "admin")
      .maybeSingle();
    if (!roleRow) throw new Error("Forbidden: admin only");
    if (data.action === "verify") {
      const { error } = await supabaseAdmin
        .from("registrations")
        .update({
          payment_status: "verified",
          payment_verified: true,
          verified_at: new Date().toISOString(),
          verification_notes: data.notes || null,
          status: "approved",
        })
        .eq("id", data.registrationId);
      if (error) throw new Error(error.message);
    } else {
      const { error } = await supabaseAdmin
        .from("registrations")
        .update({
          payment_status: "rejected",
          payment_verified: false,
          verification_notes: data.notes || "Payment proof was rejected. Please re-submit.",
        })
        .eq("id", data.registrationId);
      if (error) throw new Error(error.message);
    }

    // Notify the user about the decision
    const { data: reg } = await supabaseAdmin
      .from("registrations")
      .select("captain_name, captain_email, team_name, verification_notes, tournament_id")
      .eq("id", data.registrationId)
      .maybeSingle();
    if (reg?.captain_email) {
      let tName = "Strike Masters Tournament";
      if (reg.tournament_id) {
        const { data: t } = await supabaseAdmin
          .from("tournaments")
          .select("name")
          .eq("id", reg.tournament_id)
          .maybeSingle();
        if (t?.name) tName = t.name;
      }
      const mail =
        data.action === "verify"
          ? paymentVerifiedEmail({
              captainName: reg.captain_name,
              teamName: reg.team_name,
              tournamentName: tName,
              notes: data.notes,
            })
          : paymentRejectedEmail({
              captainName: reg.captain_name,
              teamName: reg.team_name,
              tournamentName: tName,
              notes: reg.verification_notes,
            });
      await sendGmail({ to: reg.captain_email, ...mail });
    }

    return { ok: true };
  });
