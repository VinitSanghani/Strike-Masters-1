import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Trophy, Medal, Award, TrendingUp, Loader2, ArrowRight } from "lucide-react";
import { SectionHeader } from "@/components/SectionHeader";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/prizes")({
  head: () => ({
    meta: [
      { title: "Prizes — Strike Masters Bowling Tournament" },
      { name: "description", content: "Strike Masters prize pool scales with registrations. Cash and trophies for top finishers." },
      { property: "og:title", content: "Strike Masters Prizes" },
      { property: "og:description", content: "Prize pool scales with registrations — more teams, bigger rewards." },
    ],
  }),
  component: PrizesPage,
});

interface Tournament {
  id: string; slug: string; name: string;
  prize_pool: string; prize_pool_amount: number | null; status: string;
  qualification_date: string | null; finals_date: string | null;
}
interface Prize {
  id: string; rank_label: string; title: string;
  description: string | null; value: string | null; sort_order: number;
}
interface IndividualAward {
  id: string; title: string; description: string | null; amount: number | null;
}

const rankStyles = [
  { color: "text-gold", border: "border-gold/50", glow: "shadow-[0_0_40px_-10px_var(--gold)]", icon: Trophy },
  { color: "text-silver", border: "border-silver/50", glow: "shadow-[0_0_40px_-10px_var(--silver)]", icon: Medal },
  { color: "text-bronze", border: "border-bronze/50", glow: "shadow-[0_0_40px_-10px_var(--bronze)]", icon: Award },
];

function PrizesPage() {
  const [tournament, setTournament] = useState<Tournament | null>(null);
  const [prizes, setPrizes] = useState<Prize[]>([]);
  const [awards, setAwards] = useState<IndividualAward[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      // Pick the most relevant tournament: published + soonest upcoming, else most recent.
      const { data: list } = await supabase
        .from("tournaments")
        .select("id, slug, name, prize_pool, prize_pool_amount, status, qualification_date, finals_date")
        .neq("status", "draft")
        .order("qualification_date", { ascending: true });
      if (cancelled) return;
      const now = Date.now();
      const tournaments = (list ?? []) as Tournament[];
      const upcoming = tournaments.find((t) => t.qualification_date && new Date(t.qualification_date).getTime() >= now);
      const t = upcoming ?? tournaments[tournaments.length - 1] ?? null;
      setTournament(t);
      if (t) {
        const [pRes, aRes] = await Promise.all([
          supabase.from("tournament_prizes").select("*").eq("tournament_id", t.id).order("sort_order"),
          (supabase as any).from("tournament_individual_awards")
            .select("id, title, description, amount, active, sort_order")
            .eq("tournament_id", t.id).eq("active", true).order("sort_order"),
        ]);
        if (cancelled) return;
        setPrizes((pRes.data ?? []) as Prize[]);
        setAwards(((aRes as any).data ?? []) as IndividualAward[]);
      }
      setLoading(false);
    })();
    return () => { cancelled = true; };
  }, []);

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-32 text-center">
        <Loader2 className="w-8 h-8 mx-auto animate-spin text-neon" />
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 sm:px-6 py-14 sm:py-20">
      <SectionHeader
        eyebrow="What's At Stake"
        title={tournament ? `${tournament.name} — Prizes` : "Prizes"}
        description={tournament?.prize_pool ?? "Prize details will be announced soon."}
      />

      {!tournament ? (
        <div className="max-w-2xl mx-auto rounded-2xl border border-border bg-card/60 p-8 text-center text-muted-foreground">
          No published tournament yet. Check back soon.
        </div>
      ) : (
        <>
          <div className="max-w-3xl mx-auto mb-14 rounded-2xl border border-neon/30 bg-gradient-to-br from-card to-primary/10 p-6 sm:p-8 shadow-glow">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-neon to-primary flex items-center justify-center shrink-0">
                <TrendingUp className="text-neon-foreground" size={22} />
              </div>
              <div>
                <h3 className="font-display text-xl sm:text-2xl mb-2 text-neon">Dynamic Prize Pool</h3>
                <p className="text-sm text-muted-foreground">
                  More registrations increase the total prize pool and rewards. Final amounts will be confirmed once registrations close.
                </p>
              </div>
            </div>
          </div>

          {prizes.length === 0 ? (
            <div className="max-w-2xl mx-auto rounded-xl border border-dashed border-border bg-card/40 p-8 text-center text-sm text-muted-foreground">
              Prizes for this tournament haven't been published yet.
            </div>
          ) : (
            <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto items-end">
              {prizes.slice(0, 3).map((p, i) => {
                const style = rankStyles[i] ?? rankStyles[2];
                const Icon = style.icon;
                const isFirst = i === 0;
                const order = isFirst ? "md:order-2 md:scale-110" : i === 1 ? "md:order-1" : "md:order-3";
                return (
                  <div
                    key={p.id}
                    className={`rounded-2xl border-2 ${style.border} bg-card/60 backdrop-blur p-6 sm:p-8 text-center ${style.glow} hover:-translate-y-2 transition-transform ${order}`}
                  >
                    <div className="flex justify-center mb-4">
                      <div className={`w-20 h-20 rounded-full bg-card flex items-center justify-center ${style.color} animate-[float_6s_ease-in-out_infinite]`}>
                        <Icon size={40} />
                      </div>
                    </div>
                    <div className={`font-display text-5xl ${style.color} mb-1`}>{p.rank_label}</div>
                    <div className="text-xs uppercase tracking-widest text-muted-foreground mb-4">{p.title}</div>
                    {p.value && <div className="font-display text-lg text-gradient-neon mb-4">{p.value}</div>}
                    {p.description && (
                      <p className="text-sm text-muted-foreground whitespace-pre-line text-left">{p.description}</p>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {awards.length > 0 && (
            <div className="mt-16 max-w-3xl mx-auto rounded-xl border border-border bg-card/40 p-8">
              <h3 className="font-display text-2xl mb-5 text-neon text-center">Plus Individual Awards</h3>
              <div className="grid sm:grid-cols-2 gap-4">
                {awards.map((a) => (
                  <div key={a.id} className="rounded-lg border border-border bg-card/60 p-4">
                    <div className="flex items-baseline justify-between gap-3">
                      <div className="font-semibold">{a.title}</div>
                      {a.amount != null && (
                        <div className="font-display text-gradient-neon">₹{a.amount.toLocaleString()}</div>
                      )}
                    </div>
                    {a.description && <p className="text-sm text-muted-foreground mt-1">{a.description}</p>}
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="mt-12 text-center">
            <Link
              to="/tournaments/$slug"
              params={{ slug: tournament.slug }}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-gradient-to-r from-neon to-primary text-neon-foreground font-semibold hover:opacity-90"
            >
              View Tournament Details <ArrowRight size={18} />
            </Link>
          </div>
        </>
      )}
    </div>
  );
}
