import { useEffect, useState } from "react";
import { Loader2, Trophy, Users, Calendar, IndianRupee, TrendingUp, Star, Clock } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Link } from "@tanstack/react-router";
import { formatDateDMY, formatDateTimeDMY } from "@/lib/format-date";

interface OverviewTournament {
  id: string;
  slug: string;
  name: string;
  status: string;
  featured: boolean;
  qualification_date: string | null;
  registration_fee: number;
  max_teams: number | null;
}

interface OverviewRegistration {
  tournament_id: string | null;
  payment_verified: boolean;
  amount_paid: number | null;
  created_at: string;
}

function timeUntil(date: string) {
  const diff = new Date(date).getTime() - Date.now();
  if (diff <= 0) return "Started";
  const days = Math.floor(diff / 86400000);
  const hours = Math.floor((diff / 3600000) % 24);
  if (days > 0) return `${days}d ${hours}h`;
  const minutes = Math.floor((diff / 60000) % 60);
  return `${hours}h ${minutes}m`;
}

export function AdminOverviewTab({ onJump }: { onJump: (tab: "tournaments" | "registrations") => void }) {
  const [tournaments, setTournaments] = useState<OverviewTournament[]>([]);
  const [registrations, setRegistrations] = useState<OverviewRegistration[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      supabase.from("tournaments").select("id, slug, name, status, featured, qualification_date, registration_fee, max_teams").order("created_at", { ascending: false }),
      supabase.from("registrations").select("tournament_id, payment_verified, amount_paid, created_at"),
    ]).then(([tRes, rRes]) => {
      setTournaments((tRes.data ?? []) as OverviewTournament[]);
      setRegistrations((rRes.data ?? []) as OverviewRegistration[]);
      setLoading(false);
    });
  }, []);

  if (loading) {
    return <div className="text-center py-12"><Loader2 className="w-6 h-6 mx-auto animate-spin text-neon" /></div>;
  }

  const totalTournaments = tournaments.length;
  const activeCount = tournaments.filter((t) => t.status === "active" || t.status === "upcoming").length;
  const completedCount = tournaments.filter((t) => t.status === "completed").length;
  const paidRegs = registrations.filter((r) => r.payment_verified);
  const totalRevenuePaise = paidRegs.reduce((sum, r) => sum + (r.amount_paid ?? 0), 0);
  const totalRevenueInr = totalRevenuePaise / 100;

  const now = Date.now();
  const upcoming = [...tournaments]
    .filter((t) => t.qualification_date && new Date(t.qualification_date).getTime() > now && t.status !== "draft" && t.status !== "archived")
    .sort((a, b) => new Date(a.qualification_date!).getTime() - new Date(b.qualification_date!).getTime())[0];

  // Per-tournament breakdown
  const counts: Record<string, { paid: number; revenue: number }> = {};
  for (const r of paidRegs) {
    const key = r.tournament_id ?? "_legacy";
    const c = counts[key] ?? { paid: 0, revenue: 0 };
    c.paid += 1;
    c.revenue += (r.amount_paid ?? 0) / 100;
    counts[key] = c;
  }

  return (
    <div className="space-y-6">
      {/* Top stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard icon={<Trophy size={16} />} label="Total Tournaments" value={String(totalTournaments)} sub={`${activeCount} active · ${completedCount} done`} />
        <StatCard icon={<Users size={16} />} label="Paid Registrations" value={String(paidRegs.length)} sub={`${registrations.length - paidRegs.length} pending`} accent="success" />
        <StatCard icon={<IndianRupee size={16} />} label="Total Revenue" value={`₹${totalRevenueInr.toLocaleString("en-IN")}`} sub="Across all events" accent="neon" />
        <StatCard icon={<TrendingUp size={16} />} label="Avg / Team" value={paidRegs.length ? `₹${Math.round(totalRevenueInr / paidRegs.length).toLocaleString("en-IN")}` : "—"} sub="Average entry" />
      </div>

      {/* Upcoming countdown + featured */}
      <div className="grid lg:grid-cols-2 gap-4">
        {upcoming ? (
          <div className="rounded-2xl border border-neon/40 bg-gradient-to-br from-card to-primary/10 p-6 shadow-glow">
            <div className="flex items-center gap-2 text-[10px] uppercase tracking-widest text-neon mb-2">
              <Clock size={12} /> Next Tournament Starts In
            </div>
            <div className="font-display text-4xl text-gradient-neon mb-2">{timeUntil(upcoming.qualification_date!)}</div>
            <div className="text-sm">{upcoming.name}</div>
            <div className="text-xs text-muted-foreground">{formatDateTimeDMY(upcoming.qualification_date!)}</div>
            <div className="mt-4 flex gap-2">
              <Link to="/tournaments/$slug" params={{ slug: upcoming.slug }} className="text-xs uppercase tracking-wider font-bold px-3 py-1.5 rounded border border-neon/40 text-neon hover:bg-neon/10">View Public Page</Link>
              <button onClick={() => onJump("tournaments")} className="text-xs uppercase tracking-wider font-bold px-3 py-1.5 rounded border border-border hover:border-neon">Manage</button>
            </div>
          </div>
        ) : (
          <div className="rounded-2xl border border-border bg-card/40 p-6 text-center">
            <Calendar className="w-8 h-8 mx-auto text-muted-foreground mb-2" />
            <p className="text-sm text-muted-foreground">No upcoming tournaments scheduled.</p>
            <button onClick={() => onJump("tournaments")} className="mt-3 text-xs uppercase tracking-wider font-bold px-3 py-1.5 rounded border border-neon/40 text-neon hover:bg-neon/10">Create One</button>
          </div>
        )}

        <div className="rounded-2xl border border-border bg-card/40 p-6">
          <div className="flex items-center gap-2 text-[10px] uppercase tracking-widest text-muted-foreground mb-3">
            <Star size={12} className="text-neon" /> Featured on Homepage
          </div>
          {tournaments.find((t) => t.featured) ? (
            <>
              <div className="font-display text-xl mb-1">{tournaments.find((t) => t.featured)!.name}</div>
              <div className="text-xs text-muted-foreground capitalize">{tournaments.find((t) => t.featured)!.status}</div>
            </>
          ) : (
            <div className="text-sm text-muted-foreground">No featured tournament. Set one to control the homepage hero.</div>
          )}
          <button onClick={() => onJump("tournaments")} className="mt-4 text-xs uppercase tracking-wider font-bold px-3 py-1.5 rounded border border-border hover:border-neon">Change</button>
        </div>
      </div>

      {/* Per-tournament table */}
      <div className="rounded-2xl border border-border bg-card/40 overflow-hidden">
        <div className="px-5 py-3 border-b border-border flex items-center justify-between">
          <h3 className="font-display text-base">Per-Tournament Performance</h3>
          <button onClick={() => onJump("registrations")} className="text-xs uppercase tracking-wider font-bold text-neon hover:underline">View Registrations →</button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-card/80">
              <tr className="text-left text-[10px] uppercase tracking-widest text-muted-foreground">
                <th className="px-4 py-3">Tournament</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3">Paid Teams</th>
                <th className="px-4 py-3">Revenue</th>
                <th className="px-4 py-3">Capacity</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {tournaments.length === 0 && (
                <tr><td colSpan={5} className="px-4 py-12 text-center text-sm text-muted-foreground">No tournaments yet.</td></tr>
              )}
              {tournaments.map((t) => {
                const c = counts[t.id] ?? { paid: 0, revenue: 0 };
                const capacity = t.max_teams ? `${c.paid}/${t.max_teams}` : `${c.paid} / ∞`;
                const fillPct = t.max_teams ? Math.min(100, (c.paid / t.max_teams) * 100) : 0;
                return (
                  <tr key={t.id} className="hover:bg-accent/40">
                    <td className="px-4 py-3">
                      <div className="font-display flex items-center gap-2">
                        {t.name}
                        {t.featured && <Star size={11} className="text-neon" fill="currentColor" />}
                      </div>
                      {t.qualification_date && (
                        <div className="text-[11px] text-muted-foreground">{formatDateDMY(t.qualification_date)}</div>
                      )}
                    </td>
                    <td className="px-4 py-3 capitalize text-xs">{t.status}</td>
                    <td className="px-4 py-3 font-display text-base">{c.paid}</td>
                    <td className="px-4 py-3 font-display text-base text-neon">₹{c.revenue.toLocaleString("en-IN")}</td>
                    <td className="px-4 py-3">
                      <div className="text-xs mb-1">{capacity}</div>
                      {t.max_teams && (
                        <div className="h-1.5 w-24 rounded-full bg-border overflow-hidden">
                          <div className="h-full bg-gradient-to-r from-neon to-primary" style={{ width: `${fillPct}%` }} />
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })}
              {counts._legacy && (
                <tr className="hover:bg-accent/40 text-muted-foreground">
                  <td className="px-4 py-3 italic">Legacy (pre-multi-tournament)</td>
                  <td className="px-4 py-3 text-xs">—</td>
                  <td className="px-4 py-3 font-display text-base">{counts._legacy.paid}</td>
                  <td className="px-4 py-3 font-display text-base">₹{counts._legacy.revenue.toLocaleString("en-IN")}</td>
                  <td className="px-4 py-3 text-xs">—</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon, label, value, sub, accent }: { icon: React.ReactNode; label: string; value: string; sub?: string; accent?: "success" | "neon" }) {
  const cls = accent === "success" ? "text-success" : accent === "neon" ? "text-neon" : "text-foreground";
  return (
    <div className="rounded-xl border border-border bg-card/60 p-4 shadow-glow">
      <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-widest text-muted-foreground mb-2">
        {icon} {label}
      </div>
      <div className={`font-display text-2xl ${cls}`}>{value}</div>
      {sub && <div className="text-[11px] text-muted-foreground mt-1">{sub}</div>}
    </div>
  );
}
