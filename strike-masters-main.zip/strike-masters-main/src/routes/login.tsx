import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { Mail, Lock, AlertCircle, LogIn, Loader2 } from "lucide-react";
import { SectionHeader } from "@/components/SectionHeader";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { toast } from "sonner";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Login — Strike Masters Tournament 2026" },
      { name: "description", content: "Login to your Strike Masters 2026 participant account to manage your team and track your registration." },
      { property: "og:title", content: "Strike Masters 2026 — Participant Login" },
      { property: "og:description", content: "Access your Strike Masters dashboard." },
    ],
  }),
  component: LoginPage,
});

const schema = z.object({
  email: z.string().trim().email("Enter a valid email").max(255),
  password: z.string().min(6, "Password must be at least 6 characters").max(100),
});

function LoginPage() {
  const { user, isAdmin, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [forgotMode, setForgotMode] = useState(false);

  useEffect(() => {
    if (!authLoading && user) {
      navigate({ to: isAdmin ? "/admin" : "/dashboard" });
    }
  }, [user, isAdmin, authLoading, navigate]);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const r = schema.safeParse({ email, password });
    if (!r.success) {
      const errs: Record<string, string> = {};
      r.error.issues.forEach((i) => (errs[i.path[0] as string] = i.message));
      setErrors(errs);
      return;
    }
    setErrors({});
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Welcome back!");
  };

  const onForgot = async (e: React.FormEvent) => {
    e.preventDefault();
    const r = z.string().email().safeParse(email);
    if (!r.success) {
      setErrors({ email: "Enter a valid email" });
      return;
    }
    setLoading(true);
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    setLoading(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Password reset link sent — check your inbox.");
    setForgotMode(false);
  };

  const inputCls = "w-full pl-10 pr-4 py-3 rounded-md bg-input/60 border border-border focus:border-neon focus:outline-none focus:ring-2 focus:ring-neon/30 transition-all text-sm";
  const labelCls = "block text-xs font-bold uppercase tracking-widest text-muted-foreground mb-2";

  return (
    <div className="container mx-auto px-4 sm:px-6 py-14 sm:py-20">
      <SectionHeader
        eyebrow={forgotMode ? "Password Reset" : "Participant Login"}
        title={forgotMode ? "Reset Your Password" : "Access Your Account"}
        description={forgotMode ? "Enter your account email and we'll send you a reset link." : "Sign in to manage your team and track your registration."}
      />

      <form onSubmit={forgotMode ? onForgot : onSubmit} className="max-w-md mx-auto rounded-2xl border border-border bg-card/60 backdrop-blur p-8 shadow-glow space-y-5">
        <div>
          <label className={labelCls}>Email</label>
          <div className="relative">
            <Mail size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input type="email" className={inputCls} value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@email.com" />
          </div>
          {errors.email && <ErrorMsg msg={errors.email} />}
        </div>

        {!forgotMode && (
          <div>
            <label className={labelCls}>Password</label>
            <div className="relative">
              <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input type="password" className={inputCls} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" />
            </div>
            {errors.password && <ErrorMsg msg={errors.password} />}
          </div>
        )}

        {!forgotMode && (
          <div className="flex items-center justify-end text-xs">
            <button type="button" onClick={() => setForgotMode(true)} className="text-neon hover:underline">Forgot password?</button>
          </div>
        )}

        <button
          type="submit"
          disabled={loading}
          className="w-full inline-flex items-center justify-center gap-2 py-3 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground font-bold uppercase tracking-wider shadow-neon hover:scale-[1.02] transition-transform disabled:opacity-50"
        >
          {loading ? <Loader2 size={16} className="animate-spin" /> : <LogIn size={16} />}
          {forgotMode ? "Send Reset Link" : "Sign In"}
        </button>

        {forgotMode ? (
          <p className="text-center text-xs">
            <button type="button" onClick={() => setForgotMode(false)} className="text-neon hover:underline">Back to login</button>
          </p>
        ) : (
          <p className="text-center text-xs text-muted-foreground">
            Not registered yet?{" "}
            <Link to="/register" className="text-neon hover:underline">Register your team</Link>
          </p>
        )}
      </form>
    </div>
  );
}

function ErrorMsg({ msg }: { msg: string }) {
  return (
    <div className="flex items-center gap-1.5 mt-2 text-xs text-destructive">
      <AlertCircle size={12} /> {msg}
    </div>
  );
}
