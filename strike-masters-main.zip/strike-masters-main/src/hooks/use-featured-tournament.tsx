import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export interface FeaturedTournament {
  id: string;
  slug: string;
  name: string;
  subtitle: string | null;
  description: string | null;
  banner_url: string | null;
  venue: string | null;
  qualification_date: string | null;
  finals_date: string | null;
  registration_open: boolean;
  registration_fee: number;
  prize_pool: string;
  status: string;
  featured: boolean;
}

export function useFeaturedTournament() {
  const [tournament, setTournament] = useState<FeaturedTournament | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      // Try the explicit featured tournament first
      const { data: featured } = await supabase
        .from("tournaments")
        .select("id, slug, name, subtitle, description, banner_url, venue, qualification_date, finals_date, registration_open, registration_fee, prize_pool, status, featured")
        .eq("featured", true)
        .neq("status", "draft")
        .neq("status", "archived")
        .maybeSingle();

      if (cancelled) return;

      if (featured) {
        setTournament(featured as FeaturedTournament);
        setLoading(false);
        return;
      }

      // Fallback: most recently created active/upcoming tournament
      const { data: fallback } = await supabase
        .from("tournaments")
        .select("id, slug, name, subtitle, description, banner_url, venue, qualification_date, finals_date, registration_open, registration_fee, prize_pool, status, featured")
        .in("status", ["active", "upcoming"])
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();

      if (cancelled) return;
      setTournament((fallback as FeaturedTournament) ?? null);
      setLoading(false);
    };
    load();
    return () => { cancelled = true; };
  }, []);

  return { tournament, loading };
}
