import { useEffect, useRef, useState } from "react";
import { Loader2, Save, Upload, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface SponsorsPage {
  id: number;
  eyebrow: string;
  title: string;
  description: string;
  featured_enabled: boolean;
  featured_badge: string;
  featured_name: string;
  featured_description: string;
  featured_logo_url: string | null;
  feature_1_label: string;
  feature_2_label: string;
  feature_3_label: string;
  cta_title: string;
  cta_description: string;
  cta_button_label: string;
  cta_button_email: string;
}

const inputCls =
  "w-full px-3 py-2 rounded-md bg-input/60 border border-border text-sm focus:border-neon focus:outline-none";
const labelCls =
  "block text-[10px] uppercase tracking-widest text-muted-foreground mb-1 font-bold";

export function SponsorsPageTab() {
  const [data, setData] = useState<SponsorsPage | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    (async () => {
      const { data: row, error } = await supabase
        .from("sponsors_page")
        .select("*")
        .eq("id", 1)
        .maybeSingle();
      if (error) toast.error(error.message);
      setData(row as SponsorsPage);
      setLoading(false);
    })();
  }, []);

  const save = async () => {
    if (!data) return;
    setSaving(true);
    const { id, ...payload } = data;
    void id;
    const { error } = await supabase.from("sponsors_page").update(payload).eq("id", 1);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Sponsors page updated");
  };

  const uploadLogo = async (file: File) => {
    if (!data) return;
    setUploading(true);
    try {
      const ext = file.name.split(".").pop() || "png";
      const path = `featured-partner/${Date.now()}.${ext}`;
      const { error: upErr } = await supabase.storage
        .from("sponsors")
        .upload(path, file, { upsert: true, cacheControl: "3600" });
      if (upErr) throw upErr;
      const { data: pub } = supabase.storage.from("sponsors").getPublicUrl(path);
      setData({ ...data, featured_logo_url: pub.publicUrl });
      toast.success("Logo uploaded — remember to Save");
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : "Upload failed";
      toast.error(msg);
    } finally {
      setUploading(false);
    }
  };

  if (loading)
    return (
      <div className="text-center py-12">
        <Loader2 className="w-6 h-6 mx-auto animate-spin text-neon" />
      </div>
    );

  if (!data)
    return (
      <div className="rounded-2xl border border-dashed border-border p-10 text-center text-sm text-muted-foreground">
        Sponsors page content not initialised.
      </div>
    );

  const set = <K extends keyof SponsorsPage>(k: K, v: SponsorsPage[K]) =>
    setData({ ...data, [k]: v });

  return (
    <div className="space-y-8">
      {/* Section header */}
      <section className="rounded-2xl border border-border bg-card/60 p-5 sm:p-6 space-y-4">
        <h3 className="font-display text-lg text-neon">Section Header</h3>
        <div>
          <label className={labelCls}>Eyebrow</label>
          <input className={inputCls} value={data.eyebrow} onChange={(e) => set("eyebrow", e.target.value)} />
        </div>
        <div>
          <label className={labelCls}>Title</label>
          <input className={inputCls} value={data.title} onChange={(e) => set("title", e.target.value)} />
        </div>
        <div>
          <label className={labelCls}>Description</label>
          <textarea rows={3} className={inputCls} value={data.description} onChange={(e) => set("description", e.target.value)} />
        </div>
      </section>

      {/* Featured partner card */}
      <section className="rounded-2xl border border-gold/30 bg-card/60 p-5 sm:p-6 space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <h3 className="font-display text-lg text-gold">Featured Venue Partner Card</h3>
          <label className="inline-flex items-center gap-2 text-xs uppercase tracking-widest text-muted-foreground cursor-pointer">
            <input
              type="checkbox"
              checked={data.featured_enabled}
              onChange={(e) => set("featured_enabled", e.target.checked)}
            />
            Show this card
          </label>
        </div>

        <div>
          <label className={labelCls}>Logo</label>
          <div className="flex items-center gap-4">
            <div className="w-32 h-20 rounded-md border border-border bg-background/50 flex items-center justify-center overflow-hidden">
              {data.featured_logo_url ? (
                <img src={data.featured_logo_url} alt="logo" className="max-w-full max-h-full object-contain" />
              ) : (
                <span className="text-[10px] text-muted-foreground">No logo</span>
              )}
            </div>
            <div className="flex flex-col gap-2">
              <input
                ref={fileRef}
                type="file"
                accept="image/*"
                hidden
                onChange={(e) => e.target.files?.[0] && uploadLogo(e.target.files[0])}
              />
              <button
                type="button"
                onClick={() => fileRef.current?.click()}
                disabled={uploading}
                className="inline-flex items-center gap-2 px-3 py-2 rounded-md border border-neon/40 text-neon text-xs font-bold uppercase tracking-wider hover:bg-neon/10"
              >
                {uploading ? <Loader2 size={12} className="animate-spin" /> : <Upload size={12} />} Upload Logo
              </button>
              {data.featured_logo_url && (
                <button
                  type="button"
                  onClick={() => set("featured_logo_url", null)}
                  className="inline-flex items-center gap-2 px-3 py-2 rounded-md border border-destructive/40 text-destructive text-xs font-bold uppercase tracking-wider hover:bg-destructive/10"
                >
                  <Trash2 size={12} /> Remove
                </button>
              )}
            </div>
          </div>
        </div>

        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className={labelCls}>Badge Text</label>
            <input className={inputCls} value={data.featured_badge} onChange={(e) => set("featured_badge", e.target.value)} />
          </div>
          <div>
            <label className={labelCls}>Partner Name</label>
            <input className={inputCls} value={data.featured_name} onChange={(e) => set("featured_name", e.target.value)} />
          </div>
        </div>
        <div>
          <label className={labelCls}>Description</label>
          <textarea rows={4} className={inputCls} value={data.featured_description} onChange={(e) => set("featured_description", e.target.value)} />
        </div>
        <div className="grid sm:grid-cols-3 gap-4">
          <div>
            <label className={labelCls}>Feature 1 (Trophy icon)</label>
            <input className={inputCls} value={data.feature_1_label} onChange={(e) => set("feature_1_label", e.target.value)} />
          </div>
          <div>
            <label className={labelCls}>Feature 2 (Map pin)</label>
            <input className={inputCls} value={data.feature_2_label} onChange={(e) => set("feature_2_label", e.target.value)} placeholder="e.g. AR Mall, Surat" />
          </div>
          <div>
            <label className={labelCls}>Feature 3 (Phone)</label>
            <input className={inputCls} value={data.feature_3_label} onChange={(e) => set("feature_3_label", e.target.value)} placeholder="e.g. +91 95869 95356" />
          </div>
        </div>
      </section>

      {/* CTA block */}
      <section className="rounded-2xl border border-border bg-card/60 p-5 sm:p-6 space-y-4">
        <h3 className="font-display text-lg text-neon">"Become a Partner" CTA</h3>
        <div>
          <label className={labelCls}>Title</label>
          <input className={inputCls} value={data.cta_title} onChange={(e) => set("cta_title", e.target.value)} />
        </div>
        <div>
          <label className={labelCls}>Description</label>
          <textarea rows={3} className={inputCls} value={data.cta_description} onChange={(e) => set("cta_description", e.target.value)} />
        </div>
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className={labelCls}>Button Label</label>
            <input className={inputCls} value={data.cta_button_label} onChange={(e) => set("cta_button_label", e.target.value)} />
          </div>
          <div>
            <label className={labelCls}>Button Email</label>
            <input type="email" className={inputCls} value={data.cta_button_email} onChange={(e) => set("cta_button_email", e.target.value)} />
          </div>
        </div>
      </section>

      <div className="sticky bottom-4 z-10 flex justify-end">
        <button
          onClick={save}
          disabled={saving}
          className="inline-flex items-center gap-2 px-6 py-3 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground text-sm font-bold uppercase tracking-wider shadow-glow disabled:opacity-60"
        >
          {saving ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />} Save Changes
        </button>
      </div>
    </div>
  );
}
