// Date formatting helpers — site-wide standard is dd/mm/yyyy.

const pad = (n: number) => String(n).padStart(2, "0");

function parseDisplayDate(input: string | Date): Date | null {
  if (input instanceof Date) return isNaN(input.getTime()) ? null : input;
  const dateOnly = input.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (dateOnly) {
    const d = new Date(Number(dateOnly[1]), Number(dateOnly[2]) - 1, Number(dateOnly[3]));
    return isNaN(d.getTime()) ? null : d;
  }
  const d = new Date(input);
  return isNaN(d.getTime()) ? null : d;
}

export function formatDateDMY(input: string | Date | null | undefined): string {
  if (!input) return "";
  const d = parseDisplayDate(input);
  if (!d) return "";
  return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()}`;
}

export function formatDateTimeDMY(input: string | Date | null | undefined): string {
  if (!input) return "";
  const d = parseDisplayDate(input);
  if (!d) return "";
  return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
