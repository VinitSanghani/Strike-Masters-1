CREATE TABLE public.site_settings (
  id integer PRIMARY KEY DEFAULT 1,
  copyright_text text NOT NULL DEFAULT '© 2026 Strike Masters Tournament. Hosted at LaneX Bowling Alley, Surat. All rights reserved.',
  instagram_url text NOT NULL DEFAULT '#',
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  CONSTRAINT site_settings_singleton CHECK (id = 1)
);

ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Site settings publicly readable" ON public.site_settings FOR SELECT USING (true);
CREATE POLICY "Admins manage site settings" ON public.site_settings FOR ALL TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE TRIGGER update_site_settings_updated_at BEFORE UPDATE ON public.site_settings
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

INSERT INTO public.site_settings (id) VALUES (1) ON CONFLICT DO NOTHING;