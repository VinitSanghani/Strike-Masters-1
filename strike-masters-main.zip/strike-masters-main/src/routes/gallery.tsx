import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, useMemo } from "react";
import { Loader2, Image as ImageIcon, X as XIcon } from "lucide-react";
import { SectionHeader } from "@/components/SectionHeader";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/gallery")({
  head: () => ({
    meta: [
      { title: "Gallery — Strike Masters Bowling Tournament 2026" },
      { name: "description", content: "Highlights from past Strike Masters bowling tournaments." },
      { property: "og:title", content: "Strike Masters Gallery" },
      { property: "og:description", content: "Past tournament moments and venue shots." },
    ],
  }),
  component: GalleryPage,
});

interface GalleryImage {
  id: string;
  image_url: string;
  caption: string | null;
  tournament_id: string | null;
  sort_order: number;
}

interface TournamentLite {
  id: string;
  name: string;
}

function GalleryPage() {
  const [images, setImages] = useState<GalleryImage[]>([]);
  const [tournaments, setTournaments] = useState<TournamentLite[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<string>("all");
  const [lightbox, setLightbox] = useState<GalleryImage | null>(null);

  useEffect(() => {
    (async () => {
      const [imgRes, tRes] = await Promise.all([
        supabase.from("gallery_images").select("id, image_url, caption, tournament_id, sort_order").eq("active", true).order("sort_order", { ascending: true }).order("created_at", { ascending: false }),
        supabase.from("tournaments").select("id, name").neq("status", "draft"),
      ]);
      setImages((imgRes.data ?? []) as GalleryImage[]);
      setTournaments((tRes.data ?? []) as TournamentLite[]);
      setLoading(false);
    })();
  }, []);

  const tournamentsWithImages = useMemo(() => {
    const ids = new Set(images.map((i) => i.tournament_id).filter(Boolean) as string[]);
    return tournaments.filter((t) => ids.has(t.id));
  }, [tournaments, images]);

  const filtered = useMemo(() => {
    if (filter === "all") return images;
    if (filter === "general") return images.filter((i) => !i.tournament_id);
    return images.filter((i) => i.tournament_id === filter);
  }, [images, filter]);

  return (
    <div className="container mx-auto px-4 sm:px-6 py-14 sm:py-20">
      <SectionHeader
        eyebrow="Gallery"
        title="Moments of Glory"
        description="A glimpse into the energy, the lights, and the competition that defines Strike Masters."
      />

      {(tournamentsWithImages.length > 0 || images.some((i) => !i.tournament_id)) && (
        <div className="max-w-6xl mx-auto flex flex-wrap gap-2 justify-center mb-8">
          <FilterPill active={filter === "all"} onClick={() => setFilter("all")}>All</FilterPill>
          {images.some((i) => !i.tournament_id) && (
            <FilterPill active={filter === "general"} onClick={() => setFilter("general")}>General</FilterPill>
          )}
          {tournamentsWithImages.map((t) => (
            <FilterPill key={t.id} active={filter === t.id} onClick={() => setFilter(t.id)}>{t.name}</FilterPill>
          ))}
        </div>
      )}

      {loading ? (
        <div className="text-center py-20"><Loader2 className="w-8 h-8 mx-auto animate-spin text-neon" /></div>
      ) : filtered.length === 0 ? (
        <div className="max-w-md mx-auto rounded-2xl border border-dashed border-border bg-card/40 p-10 text-center">
          <ImageIcon className="w-10 h-10 mx-auto text-muted-foreground mb-2" />
          <p className="text-sm text-muted-foreground">No photos available yet. Check back after the tournament!</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4 max-w-6xl mx-auto">
          {filtered.map((img) => (
            <button
              key={img.id}
              type="button"
              onClick={() => setLightbox(img)}
              className="relative rounded-xl overflow-hidden border border-border group cursor-pointer aspect-[4/3] focus:outline-none focus:ring-2 focus:ring-neon"
            >
              <img
                src={img.image_url}
                alt={img.caption ?? "Tournament photo"}
                loading="lazy"
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background/90 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              {img.caption && (
                <div className="absolute bottom-0 left-0 right-0 p-4 text-sm text-foreground text-left translate-y-2 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all">
                  {img.caption}
                </div>
              )}
            </button>
          ))}
        </div>
      )}

      {lightbox && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/95 backdrop-blur"
          onClick={() => setLightbox(null)}
        >
          <button
            type="button"
            onClick={(e) => { e.stopPropagation(); setLightbox(null); }}
            className="absolute top-4 right-4 p-2 rounded-full bg-card/80 border border-border text-neon hover:bg-card"
            aria-label="Close"
          >
            <XIcon size={20} />
          </button>
          <div className="max-w-6xl max-h-[90vh] w-full flex flex-col items-center gap-3" onClick={(e) => e.stopPropagation()}>
            <img
              src={lightbox.image_url}
              alt={lightbox.caption ?? "Tournament photo"}
              className="max-h-[80vh] w-auto max-w-full object-contain rounded-lg"
            />
            {lightbox.caption && (
              <p className="text-sm text-muted-foreground text-center">{lightbox.caption}</p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function FilterPill({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={`px-4 py-2 rounded-full text-xs uppercase tracking-widest font-bold border transition-colors ${
        active ? "bg-neon text-neon-foreground border-neon shadow-neon" : "border-border text-muted-foreground hover:text-neon hover:border-neon/40"
      }`}
    >
      {children}
    </button>
  );
}
