CREATE TABLE public.contact_content (
  id integer PRIMARY KEY DEFAULT 1,
  eyebrow text NOT NULL DEFAULT 'Get In Touch',
  title text NOT NULL DEFAULT 'Contact Us',
  description text NOT NULL DEFAULT 'Questions about registration, sponsorship, or the event? We''re here to help.',
  organizers_label text NOT NULL DEFAULT 'Organizers',
  organizers_value text NOT NULL DEFAULT 'Vinit Sanghani & Harsh Vasoya',
  email_label text NOT NULL DEFAULT 'Email',
  email_value text NOT NULL DEFAULT 'strikemasters.in@gmail.com',
  phone_label text NOT NULL DEFAULT 'Phone',
  phone_value text NOT NULL DEFAULT '+91 95869 95356',
  whatsapp_number text NOT NULL DEFAULT '919586995356',
  whatsapp_message text NOT NULL DEFAULT 'Hi! I''d like to know more about Strike Masters 2026.',
  venue_label text NOT NULL DEFAULT 'Venue',
  venue_value text NOT NULL DEFAULT 'LaneX Bowling Alley, AR Mall, Surat, Gujarat',
  map_query text NOT NULL DEFAULT 'AR Mall Surat',
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  CONSTRAINT contact_content_singleton CHECK (id = 1)
);

ALTER TABLE public.contact_content ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Contact content publicly readable"
ON public.contact_content FOR SELECT
USING (true);

CREATE POLICY "Admins manage contact content"
ON public.contact_content FOR ALL
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE TRIGGER update_contact_content_updated_at
BEFORE UPDATE ON public.contact_content
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

INSERT INTO public.contact_content (id) VALUES (1) ON CONFLICT (id) DO NOTHING;