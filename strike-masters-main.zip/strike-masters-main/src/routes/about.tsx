import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Users, Target, Award, CheckCircle2, Loader2 } from "lucide-react";
import { SectionHeader } from "@/components/SectionHeader";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — Strike Masters Bowling Tournament" },
      { name: "description", content: "Learn about the Strike Masters tournament format, rules, scoring system, and eligibility criteria." },
      { property: "og:title", content: "About Strike Masters" },
      { property: "og:description", content: "Tournament format, rules, scoring, and eligibility." },
    ],
  }),
  component: AboutPage,
});

interface AboutContent {
  eyebrow: string;
  hero_title: string;
  hero_description: string;
  format_title: string;
  format_intro: string;
  format_bullets: string[];
  scoring_title: string;
  scoring_intro: string;
  scoring_bullets: string[];
  who_title: string;
  eligibility_label: string;
  eligibility_text: string;
  team_label: string;
  team_text: string;
  equipment_label: string;
  equipment_text: string;
}

function AboutPage() {
  const [c, setC] = useState<AboutContent | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const { data } = await (supabase as any).from("about_content").select("*").eq("id", 1).maybeSingle();
      if (cancelled) return;
      setC((data ?? null) as AboutContent | null);
      setLoading(false);
    })();
    return () => { cancelled = true; };
  }, []);

  if (loading) {
    return <div className="container mx-auto px-4 py-32 text-center"><Loader2 className="w-8 h-8 mx-auto animate-spin text-neon" /></div>;
  }
  if (!c) {
    return <div className="container mx-auto px-4 py-32 text-center text-sm text-muted-foreground">About content not available.</div>;
  }

  return (
    <div className="container mx-auto px-4 sm:px-6 py-14 sm:py-20">
      <SectionHeader
        eyebrow={c.eyebrow}
        title={c.hero_title}
        description={c.hero_description}
      />

      <div className="grid lg:grid-cols-2 gap-8 mb-16">
        <div className="rounded-xl border border-border bg-card/50 p-8 shadow-glow">
          <Target className="text-neon mb-4" size={32} />
          <h3 className="font-display text-2xl mb-3">{c.format_title}</h3>
          <p className="text-muted-foreground mb-4 whitespace-pre-line">{c.format_intro}</p>
          <ul className="space-y-2 text-sm">
            {c.format_bullets.map((b, i) => (
              <li key={i} className="flex gap-2"><CheckCircle2 className="text-neon shrink-0 mt-0.5" size={16} /> {b}</li>
            ))}
          </ul>
        </div>

        <div className="rounded-xl border border-border bg-card/50 p-8 shadow-glow">
          <Award className="text-neon mb-4" size={32} />
          <h3 className="font-display text-2xl mb-3">{c.scoring_title}</h3>
          <p className="text-muted-foreground mb-4 whitespace-pre-line">{c.scoring_intro}</p>
          <ul className="space-y-2 text-sm">
            {c.scoring_bullets.map((b, i) => (
              <li key={i} className="flex gap-2"><CheckCircle2 className="text-neon shrink-0 mt-0.5" size={16} /> {b}</li>
            ))}
          </ul>
        </div>
      </div>

      <div className="rounded-2xl border border-neon/30 bg-gradient-to-br from-card to-primary/10 p-8 sm:p-12 shadow-glow">
        <Users className="text-neon mb-4" size={32} />
        <h3 className="font-display text-3xl mb-4">{c.who_title}</h3>
        <div className="grid md:grid-cols-3 gap-6 text-sm">
          <div>
            <div className="font-bold text-neon mb-2 uppercase tracking-wider text-xs">{c.eligibility_label}</div>
            <p className="text-muted-foreground whitespace-pre-line">{c.eligibility_text}</p>
          </div>
          <div>
            <div className="font-bold text-neon mb-2 uppercase tracking-wider text-xs">{c.team_label}</div>
            <p className="text-muted-foreground whitespace-pre-line">{c.team_text}</p>
          </div>
          <div>
            <div className="font-bold text-neon mb-2 uppercase tracking-wider text-xs">{c.equipment_label}</div>
            <p className="text-muted-foreground whitespace-pre-line">{c.equipment_text}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
