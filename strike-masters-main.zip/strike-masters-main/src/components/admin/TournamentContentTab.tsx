import { useEffect, useMemo, useState } from "react";
import { Loader2, Plus, Trash2, Edit3, X, Save, Trophy, Calendar, HelpCircle, Image as ImageIcon, ArrowUp, ArrowDown, Eye, EyeOff, Award, Handshake } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import type { Tournament } from "./TournamentsTab";

type CmsKind = "prizes" | "awards" | "schedule" | "faqs" | "sponsors" | "gallery";

interface Prize { id: string; tournament_id: string; rank_label: string; title: string; description: string | null; value: string | null; sort_order: number; }
interface IndividualAward { id: string; tournament_id: string; title: string; description: string | null; amount: number | null; sort_order: number; active: boolean; }
interface ScheduleItem { id: string; tournament_id: string; day_label: string; time_label: string | null; title: string; description: string | null; sort_order: number; }
interface Faq { id: string; tournament_id: string | null; question: string; answer: string; sort_order: number; }
interface Gallery { id: string; tournament_id: string | null; image_url: string; caption: string | null; sort_order: number; active: boolean; }
interface TSponsor { id: string; tournament_id: string; name: string; logo_url: string | null; link_url: string | null; sort_order: number; active: boolean; }

export function TournamentContentTab({ initialKind = "prizes" }: { initialKind?: CmsKind } = {}) {
  const [kind, setKind] = useState<CmsKind>(initialKind);
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [tournamentId, setTournamentId] = useState<string>("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.from("tournaments").select("*").order("created_at", { ascending: false }).then(({ data }) => {
      const list = (data ?? []) as Tournament[];
      setTournaments(list);
      const featured = list.find((t) => t.featured);
      setTournamentId(featured?.id ?? list[0]?.id ?? "");
      setLoading(false);
    });
  }, []);

  if (loading) return <div className="text-center py-12"><Loader2 className="w-6 h-6 mx-auto animate-spin text-neon" /></div>;

  if (tournaments.length === 0) {
    return (
      <div className="rounded-2xl border border-dashed border-border bg-card/40 p-10 text-center">
        <Trophy className="w-10 h-10 mx-auto text-muted-foreground mb-2" />
        <p className="text-sm text-muted-foreground">Create a tournament first, then manage its prizes, schedule, FAQs, and gallery here.</p>
      </div>
    );
  }

  const needsTournament = kind !== "gallery";

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
        <div className="flex flex-wrap gap-1 bg-card/40 rounded-md p-1 border border-border max-w-full overflow-x-auto">
          {([
            ["prizes", "Prizes", Trophy],
            ["awards", "Individual Awards", Award],
            ["schedule", "Schedule", Calendar],
            ["faqs", "FAQs", HelpCircle],
            ["sponsors", "Sponsors", Handshake],
            ["gallery", "Gallery", ImageIcon],
          ] as const).map(([k, label, Icon]) => (
            <button
              key={k}
              onClick={() => setKind(k)}
              className={`px-3 py-1.5 text-xs uppercase tracking-wider font-bold rounded inline-flex items-center gap-1.5 transition-colors ${
                kind === k ? "bg-neon text-neon-foreground" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Icon size={12} /> {label}
            </button>
          ))}
        </div>
        {needsTournament && (
          <select value={tournamentId} onChange={(e) => setTournamentId(e.target.value)} className="px-3 py-2 rounded-md bg-input/60 border border-border text-sm">
            {tournaments.map((t) => <option key={t.id} value={t.id}>{t.name}{t.featured ? " ★" : ""}</option>)}
          </select>
        )}
      </div>

      {kind === "prizes" && tournamentId && <PrizesEditor tournamentId={tournamentId} />}
      {kind === "awards" && tournamentId && <AwardsEditor tournamentId={tournamentId} />}
      {kind === "schedule" && tournamentId && <ScheduleEditor tournamentId={tournamentId} />}
      {kind === "faqs" && tournamentId && <FaqsEditor tournamentId={tournamentId} />}
      {kind === "sponsors" && tournamentId && <TournamentSponsorsEditor tournamentId={tournamentId} />}
      {kind === "gallery" && <GalleryEditor tournaments={tournaments} />}
    </div>
  );
}

const inputCls = "w-full px-3 py-2 rounded-md bg-input/60 border border-border text-sm focus:border-neon focus:outline-none";
const labelCls = "block text-[10px] uppercase tracking-widest text-muted-foreground mb-1";

/* ---------------- PRIZES ---------------- */
function PrizesEditor({ tournamentId }: { tournamentId: string }) {
  const [items, setItems] = useState<Prize[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<Prize | null>(null);
  const [creating, setCreating] = useState(false);

  const refresh = async () => {
    const { data } = await supabase.from("tournament_prizes").select("*").eq("tournament_id", tournamentId).order("sort_order", { ascending: true });
    setItems((data ?? []) as Prize[]);
    setLoading(false);
  };
  useEffect(() => { setLoading(true); refresh(); /* eslint-disable-next-line */ }, [tournamentId]);

  const remove = async (id: string) => {
    if (!confirm("Delete this prize?")) return;
    const { error } = await supabase.from("tournament_prizes").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Deleted"); refresh();
  };

  if (loading) return <div className="text-center py-8"><Loader2 className="w-5 h-5 mx-auto animate-spin text-neon" /></div>;

  return (
    <div className="space-y-3">
      <div className="flex justify-end">
        <button onClick={() => setCreating(true)} className="inline-flex items-center gap-2 px-3 py-2 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground text-xs uppercase tracking-wider font-bold shadow-neon">
          <Plus size={14} /> Add Prize
        </button>
      </div>
      {items.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground">No prize cards yet.</div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {items.map((p) => (
            <div key={p.id} className="rounded-xl border border-border bg-card/60 p-4">
              <div className="text-[10px] uppercase tracking-widest text-neon font-bold mb-1">{p.rank_label}</div>
              <h4 className="font-display text-base mb-1">{p.title}</h4>
              {p.value && <div className="text-sm text-gold font-bold mb-1">{p.value}</div>}
              {p.description && <p className="text-xs text-muted-foreground line-clamp-3 mb-3">{p.description}</p>}
              <div className="flex justify-end gap-1 pt-2 border-t border-border">
                <button onClick={() => setEditing(p)} className="p-1.5 rounded text-neon hover:bg-neon/10"><Edit3 size={14} /></button>
                <button onClick={() => remove(p.id)} className="p-1.5 rounded text-destructive hover:bg-destructive/10"><Trash2 size={14} /></button>
              </div>
            </div>
          ))}
        </div>
      )}
      {(creating || editing) && (
        <PrizeModal
          item={editing}
          tournamentId={tournamentId}
          nextSort={items.length * 10}
          onClose={() => { setCreating(false); setEditing(null); }}
          onSaved={async () => { setCreating(false); setEditing(null); await refresh(); }}
        />
      )}
    </div>
  );
}

function PrizeModal({ item, tournamentId, nextSort, onClose, onSaved }: { item: Prize | null; tournamentId: string; nextSort: number; onClose: () => void; onSaved: () => Promise<void> }) {
  const [form, setForm] = useState({
    rank_label: item?.rank_label ?? "Champion",
    title: item?.title ?? "",
    value: item?.value ?? "",
    description: item?.description ?? "",
    sort_order: item?.sort_order ?? nextSort,
  });
  const [saving, setSaving] = useState(false);
  const save = async () => {
    if (!form.rank_label.trim() || !form.title.trim()) return toast.error("Rank label and title required");
    setSaving(true);
    const payload = { tournament_id: tournamentId, rank_label: form.rank_label.trim(), title: form.title.trim(), value: form.value.trim() || null, description: form.description.trim() || null, sort_order: form.sort_order };
    const { error } = item ? await supabase.from("tournament_prizes").update(payload).eq("id", item.id) : await supabase.from("tournament_prizes").insert(payload);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success(item ? "Updated" : "Added"); await onSaved();
  };
  return (
    <ModalShell title={item ? "Edit Prize" : "Add Prize"} onClose={onClose}>
      <div className="grid sm:grid-cols-2 gap-3">
        <div><label className={labelCls}>Rank Label *</label><input className={inputCls} value={form.rank_label} onChange={(e) => setForm({ ...form, rank_label: e.target.value })} placeholder="Champion / 1st Place" /></div>
        <div><label className={labelCls}>Sort Order</label><input type="number" className={inputCls} value={form.sort_order} onChange={(e) => setForm({ ...form, sort_order: Number(e.target.value) || 0 })} /></div>
        <div className="sm:col-span-2"><label className={labelCls}>Title *</label><input className={inputCls} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Champion Trophy + Cash Prize" /></div>
        <div className="sm:col-span-2"><label className={labelCls}>Value (optional)</label><input className={inputCls} value={form.value} onChange={(e) => setForm({ ...form, value: e.target.value })} placeholder="₹50,000" /></div>
        <div className="sm:col-span-2"><label className={labelCls}>Description</label><textarea rows={3} className={inputCls} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></div>
      </div>
      <ModalFooter onCancel={onClose} onSave={save} saving={saving} label={item ? "Save Changes" : "Add Prize"} />
    </ModalShell>
  );
}

/* ---------------- INDIVIDUAL AWARDS ---------------- */
const DEFAULT_AWARDS = [
  { title: "Highest Strikes", amount: 1000 },
  { title: "Most Spare", amount: 500 },
];

function AwardsEditor({ tournamentId }: { tournamentId: string }) {
  const [items, setItems] = useState<IndividualAward[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<IndividualAward | null>(null);
  const [creating, setCreating] = useState(false);

  const refresh = async () => {
    const { data } = await (supabase as any).from("tournament_individual_awards").select("*").eq("tournament_id", tournamentId).order("sort_order", { ascending: true });
    setItems((data ?? []) as IndividualAward[]);
    setLoading(false);
  };
  useEffect(() => { setLoading(true); refresh(); /* eslint-disable-next-line */ }, [tournamentId]);

  const remove = async (id: string) => {
    if (!confirm("Delete this award?")) return;
    const { error } = await (supabase as any).from("tournament_individual_awards").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Deleted"); refresh();
  };

  const seedDefaults = async () => {
    const rows = DEFAULT_AWARDS.map((a, i) => ({ tournament_id: tournamentId, title: a.title, amount: a.amount, sort_order: i * 10, active: true }));
    const { error } = await (supabase as any).from("tournament_individual_awards").insert(rows);
    if (error) return toast.error(error.message);
    toast.success("Default awards added"); refresh();
  };

  if (loading) return <div className="text-center py-8"><Loader2 className="w-5 h-5 mx-auto animate-spin text-neon" /></div>;

  return (
    <div className="space-y-3">
      <div className="flex justify-end gap-2">
        {items.length === 0 && (
          <button onClick={seedDefaults} className="inline-flex items-center gap-2 px-3 py-2 rounded-md border border-neon/40 text-neon text-xs uppercase tracking-wider font-bold">
            <Plus size={14} /> Add Defaults
          </button>
        )}
        <button onClick={() => setCreating(true)} className="inline-flex items-center gap-2 px-3 py-2 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground text-xs uppercase tracking-wider font-bold shadow-neon">
          <Plus size={14} /> Add Award
        </button>
      </div>
      {items.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground">No individual awards yet. Click "Add Defaults" to seed Highest Strikes (₹1000) and Most Spare (₹500).</div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {items.map((a) => (
            <div key={a.id} className="rounded-xl border border-border bg-card/60 p-4">
              <h4 className="font-display text-base mb-1">{a.title}</h4>
              {a.amount != null && <div className="text-sm text-gold font-bold mb-1">₹{a.amount.toLocaleString("en-IN")}</div>}
              {a.description && <p className="text-xs text-muted-foreground line-clamp-3 mb-3">{a.description}</p>}
              <div className="flex justify-end gap-1 pt-2 border-t border-border">
                <button onClick={() => setEditing(a)} className="p-1.5 rounded text-neon hover:bg-neon/10"><Edit3 size={14} /></button>
                <button onClick={() => remove(a.id)} className="p-1.5 rounded text-destructive hover:bg-destructive/10"><Trash2 size={14} /></button>
              </div>
            </div>
          ))}
        </div>
      )}
      {(creating || editing) && (
        <AwardModal
          item={editing}
          tournamentId={tournamentId}
          nextSort={items.length * 10}
          onClose={() => { setCreating(false); setEditing(null); }}
          onSaved={async () => { setCreating(false); setEditing(null); await refresh(); }}
        />
      )}
    </div>
  );
}

function AwardModal({ item, tournamentId, nextSort, onClose, onSaved }: { item: IndividualAward | null; tournamentId: string; nextSort: number; onClose: () => void; onSaved: () => Promise<void> }) {
  const [form, setForm] = useState({
    title: item?.title ?? "",
    amount: item?.amount?.toString() ?? "",
    description: item?.description ?? "",
    sort_order: item?.sort_order ?? nextSort,
  });
  const [saving, setSaving] = useState(false);
  const save = async () => {
    if (!form.title.trim()) return toast.error("Title is required");
    setSaving(true);
    const payload = {
      tournament_id: tournamentId,
      title: form.title.trim(),
      amount: form.amount ? Number(form.amount) : null,
      description: form.description.trim() || null,
      sort_order: form.sort_order,
      active: true,
    };
    const { error } = item
      ? await (supabase as any).from("tournament_individual_awards").update(payload).eq("id", item.id)
      : await (supabase as any).from("tournament_individual_awards").insert(payload);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success(item ? "Updated" : "Added"); await onSaved();
  };
  return (
    <ModalShell title={item ? "Edit Award" : "Add Award"} onClose={onClose}>
      <div className="grid sm:grid-cols-2 gap-3">
        <div className="sm:col-span-2"><label className={labelCls}>Title *</label><input className={inputCls} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Highest Strikes" /></div>
        <div><label className={labelCls}>Amount (₹)</label><input type="number" className={inputCls} value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} placeholder="1000" /></div>
        <div><label className={labelCls}>Sort Order</label><input type="number" className={inputCls} value={form.sort_order} onChange={(e) => setForm({ ...form, sort_order: Number(e.target.value) || 0 })} /></div>
        <div className="sm:col-span-2"><label className={labelCls}>Description (optional)</label><textarea rows={3} className={inputCls} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></div>
      </div>
      <ModalFooter onCancel={onClose} onSave={save} saving={saving} label={item ? "Save Changes" : "Add Award"} />
    </ModalShell>
  );
}

/* ---------------- SCHEDULE ---------------- */
function ScheduleEditor({ tournamentId }: { tournamentId: string }) {
  const [items, setItems] = useState<ScheduleItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<ScheduleItem | null>(null);
  const [creating, setCreating] = useState(false);

  const refresh = async () => {
    const { data } = await supabase.from("tournament_schedule").select("*").eq("tournament_id", tournamentId).order("sort_order", { ascending: true });
    setItems((data ?? []) as ScheduleItem[]);
    setLoading(false);
  };
  useEffect(() => { setLoading(true); refresh(); /* eslint-disable-next-line */ }, [tournamentId]);

  const remove = async (id: string) => {
    if (!confirm("Delete this schedule item?")) return;
    const { error } = await supabase.from("tournament_schedule").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Deleted"); refresh();
  };

  if (loading) return <div className="text-center py-8"><Loader2 className="w-5 h-5 mx-auto animate-spin text-neon" /></div>;

  return (
    <div className="space-y-3">
      <div className="flex justify-end">
        <button onClick={() => setCreating(true)} className="inline-flex items-center gap-2 px-3 py-2 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground text-xs uppercase tracking-wider font-bold shadow-neon">
          <Plus size={14} /> Add Schedule Item
        </button>
      </div>
      {items.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground">No schedule items yet.</div>
      ) : (
        <div className="space-y-2">
          {items.map((s) => (
            <div key={s.id} className="rounded-xl border border-border bg-card/60 p-4 flex items-start justify-between gap-3">
              <div>
                <div className="text-[10px] uppercase tracking-widest text-neon font-bold">{s.day_label}{s.time_label ? ` · ${s.time_label}` : ""}</div>
                <h4 className="font-display text-base">{s.title}</h4>
                {s.description && <p className="text-xs text-muted-foreground mt-1">{s.description}</p>}
              </div>
              <div className="flex gap-1 shrink-0">
                <button onClick={() => setEditing(s)} className="p-1.5 rounded text-neon hover:bg-neon/10"><Edit3 size={14} /></button>
                <button onClick={() => remove(s.id)} className="p-1.5 rounded text-destructive hover:bg-destructive/10"><Trash2 size={14} /></button>
              </div>
            </div>
          ))}
        </div>
      )}
      {(creating || editing) && (
        <ScheduleModal item={editing} tournamentId={tournamentId} nextSort={items.length * 10} onClose={() => { setCreating(false); setEditing(null); }} onSaved={async () => { setCreating(false); setEditing(null); await refresh(); }} />
      )}
    </div>
  );
}

function ScheduleModal({ item, tournamentId, nextSort, onClose, onSaved }: { item: ScheduleItem | null; tournamentId: string; nextSort: number; onClose: () => void; onSaved: () => Promise<void> }) {
  const [form, setForm] = useState({
    day_label: item?.day_label ?? "Qualification Round",
    time_label: item?.time_label ?? "",
    title: item?.title ?? "",
    description: item?.description ?? "",
    sort_order: item?.sort_order ?? nextSort,
  });
  const [saving, setSaving] = useState(false);
  const save = async () => {
    if (!form.day_label.trim() || !form.title.trim()) return toast.error("Day and title required");
    setSaving(true);
    const payload = { tournament_id: tournamentId, day_label: form.day_label.trim(), time_label: form.time_label.trim() || null, title: form.title.trim(), description: form.description.trim() || null, sort_order: form.sort_order };
    const { error } = item ? await supabase.from("tournament_schedule").update(payload).eq("id", item.id) : await supabase.from("tournament_schedule").insert(payload);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success(item ? "Updated" : "Added"); await onSaved();
  };
  return (
    <ModalShell title={item ? "Edit Schedule Item" : "Add Schedule Item"} onClose={onClose}>
      <div className="grid sm:grid-cols-2 gap-3">
        <div><label className={labelCls}>Day / Phase Label *</label><input className={inputCls} value={form.day_label} onChange={(e) => setForm({ ...form, day_label: e.target.value })} placeholder="Qualification Round" /></div>
        <div><label className={labelCls}>Time Label</label><input className={inputCls} value={form.time_label} onChange={(e) => setForm({ ...form, time_label: e.target.value })} placeholder="4:00 PM – 9:00 PM" /></div>
        <div className="sm:col-span-2"><label className={labelCls}>Title *</label><input className={inputCls} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Group A Matches" /></div>
        <div className="sm:col-span-2"><label className={labelCls}>Description</label><textarea rows={3} className={inputCls} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></div>
        <div><label className={labelCls}>Sort Order</label><input type="number" className={inputCls} value={form.sort_order} onChange={(e) => setForm({ ...form, sort_order: Number(e.target.value) || 0 })} /></div>
      </div>
      <ModalFooter onCancel={onClose} onSave={save} saving={saving} label={item ? "Save Changes" : "Add Item"} />
    </ModalShell>
  );
}

/* ---------------- FAQS ---------------- */
function FaqsEditor({ tournamentId }: { tournamentId: string }) {
  const [items, setItems] = useState<Faq[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<Faq | null>(null);
  const [creating, setCreating] = useState(false);

  const refresh = async () => {
    const { data } = await supabase.from("tournament_faqs").select("*").eq("tournament_id", tournamentId).order("sort_order", { ascending: true });
    setItems((data ?? []) as Faq[]);
    setLoading(false);
  };
  useEffect(() => { setLoading(true); refresh(); /* eslint-disable-next-line */ }, [tournamentId]);

  const remove = async (id: string) => {
    if (!confirm("Delete this FAQ?")) return;
    const { error } = await supabase.from("tournament_faqs").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Deleted"); refresh();
  };

  if (loading) return <div className="text-center py-8"><Loader2 className="w-5 h-5 mx-auto animate-spin text-neon" /></div>;
  return (
    <div className="space-y-3">
      <div className="flex justify-end">
        <button onClick={() => setCreating(true)} className="inline-flex items-center gap-2 px-3 py-2 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground text-xs uppercase tracking-wider font-bold shadow-neon">
          <Plus size={14} /> Add FAQ
        </button>
      </div>
      {items.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground">No FAQs yet.</div>
      ) : (
        <div className="space-y-2">
          {items.map((f) => (
            <div key={f.id} className="rounded-xl border border-border bg-card/60 p-4 flex items-start justify-between gap-3">
              <div className="flex-1">
                <h4 className="font-display text-sm text-neon">{f.question}</h4>
                <p className="text-xs text-muted-foreground mt-1 whitespace-pre-line">{f.answer}</p>
              </div>
              <div className="flex gap-1 shrink-0">
                <button onClick={() => setEditing(f)} className="p-1.5 rounded text-neon hover:bg-neon/10"><Edit3 size={14} /></button>
                <button onClick={() => remove(f.id)} className="p-1.5 rounded text-destructive hover:bg-destructive/10"><Trash2 size={14} /></button>
              </div>
            </div>
          ))}
        </div>
      )}
      {(creating || editing) && (
        <FaqModal item={editing} tournamentId={tournamentId} nextSort={items.length * 10} onClose={() => { setCreating(false); setEditing(null); }} onSaved={async () => { setCreating(false); setEditing(null); await refresh(); }} />
      )}
    </div>
  );
}

function FaqModal({ item, tournamentId, nextSort, onClose, onSaved }: { item: Faq | null; tournamentId: string; nextSort: number; onClose: () => void; onSaved: () => Promise<void> }) {
  const [form, setForm] = useState({
    question: item?.question ?? "",
    answer: item?.answer ?? "",
    sort_order: item?.sort_order ?? nextSort,
  });
  const [saving, setSaving] = useState(false);
  const save = async () => {
    if (!form.question.trim() || !form.answer.trim()) return toast.error("Question and answer required");
    setSaving(true);
    const payload = { tournament_id: tournamentId, question: form.question.trim(), answer: form.answer.trim(), sort_order: form.sort_order };
    const { error } = item ? await supabase.from("tournament_faqs").update(payload).eq("id", item.id) : await supabase.from("tournament_faqs").insert(payload);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success(item ? "Updated" : "Added"); await onSaved();
  };
  return (
    <ModalShell title={item ? "Edit FAQ" : "Add FAQ"} onClose={onClose}>
      <div className="space-y-3">
        <div><label className={labelCls}>Question *</label><input className={inputCls} value={form.question} onChange={(e) => setForm({ ...form, question: e.target.value })} /></div>
        <div><label className={labelCls}>Answer *</label><textarea rows={5} className={inputCls} value={form.answer} onChange={(e) => setForm({ ...form, answer: e.target.value })} /></div>
        <div><label className={labelCls}>Sort Order</label><input type="number" className={inputCls} value={form.sort_order} onChange={(e) => setForm({ ...form, sort_order: Number(e.target.value) || 0 })} /></div>
      </div>
      <ModalFooter onCancel={onClose} onSave={save} saving={saving} label={item ? "Save Changes" : "Add FAQ"} />
    </ModalShell>
  );
}

/* ---------------- GALLERY ---------------- */
function GalleryEditor({ tournaments }: { tournaments: Tournament[] }) {
  const [items, setItems] = useState<Gallery[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<Gallery | null>(null);
  const [creating, setCreating] = useState(false);

  const refresh = async () => {
    const { data } = await supabase.from("gallery_images").select("*").order("sort_order", { ascending: true }).order("created_at", { ascending: true });
    setItems((data ?? []) as Gallery[]);
    setLoading(false);
  };
  useEffect(() => { refresh(); }, []);

  const tournamentName = useMemo(() => {
    const m = new Map(tournaments.map((t) => [t.id, t.name] as const));
    return m;
  }, [tournaments]);

  const remove = async (g: Gallery) => {
    if (!confirm("Delete this image?")) return;
    if (g.image_url) {
      const m = g.image_url.match(/\/object\/public\/gallery\/(.+)$/);
      if (m) await supabase.storage.from("gallery").remove([decodeURIComponent(m[1])]);
    }
    const { error } = await supabase.from("gallery_images").delete().eq("id", g.id);
    if (error) return toast.error(error.message);
    toast.success("Deleted"); refresh();
  };

  const toggleActive = async (g: Gallery) => {
    const { error } = await supabase.from("gallery_images").update({ active: !g.active }).eq("id", g.id);
    if (error) return toast.error(error.message);
    refresh();
  };

  const move = async (g: Gallery, dir: -1 | 1) => {
    const list = [...items];
    const idx = list.findIndex((x) => x.id === g.id);
    const swap = list[idx + dir];
    if (!swap) return;
    if (g.sort_order === swap.sort_order) {
      for (let i = 0; i < list.length; i++) {
        await supabase.from("gallery_images").update({ sort_order: i * 10 }).eq("id", list[i].id);
      }
      await refresh();
      return;
    }
    await Promise.all([
      supabase.from("gallery_images").update({ sort_order: swap.sort_order }).eq("id", g.id),
      supabase.from("gallery_images").update({ sort_order: g.sort_order }).eq("id", swap.id),
    ]);
    refresh();
  };

  if (loading) return <div className="text-center py-8"><Loader2 className="w-5 h-5 mx-auto animate-spin text-neon" /></div>;
  return (
    <div className="space-y-3">
      <div className="flex justify-end">
        <button onClick={() => setCreating(true)} className="inline-flex items-center gap-2 px-3 py-2 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground text-xs uppercase tracking-wider font-bold shadow-neon">
          <Plus size={14} /> Add Image
        </button>
      </div>
      {items.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground">No gallery images yet.</div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {items.map((g, i) => (
            <div key={g.id} className={`rounded-xl border overflow-hidden bg-card/60 ${g.active ? "border-border" : "border-border/40 opacity-60"}`}>
              <div className="aspect-square bg-background/60">
                <img src={g.image_url} alt={g.caption ?? ""} className="w-full h-full object-cover" loading="lazy" />
              </div>
              <div className="p-2">
                {g.caption && <p className="text-[11px] text-muted-foreground line-clamp-2">{g.caption}</p>}
                {g.tournament_id && <p className="text-[10px] text-neon truncate">{tournamentName.get(g.tournament_id) ?? "—"}</p>}
                <div className="flex items-center justify-between gap-1 mt-2 pt-2 border-t border-border">
                  <div className="flex gap-0.5">
                    <button onClick={() => move(g, -1)} disabled={i === 0} className="p-1 rounded text-muted-foreground hover:text-neon disabled:opacity-30"><ArrowUp size={12} /></button>
                    <button onClick={() => move(g, 1)} disabled={i === items.length - 1} className="p-1 rounded text-muted-foreground hover:text-neon disabled:opacity-30"><ArrowDown size={12} /></button>
                  </div>
                  <div className="flex gap-0.5">
                    <button onClick={() => toggleActive(g)} className="p-1 rounded text-muted-foreground hover:text-neon">{g.active ? <Eye size={12} /> : <EyeOff size={12} />}</button>
                    <button onClick={() => setEditing(g)} className="p-1 rounded text-neon"><Edit3 size={12} /></button>
                    <button onClick={() => remove(g)} className="p-1 rounded text-destructive"><Trash2 size={12} /></button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
      {(creating || editing) && (
        <GalleryModal item={editing} tournaments={tournaments} nextSort={items.length * 10} onClose={() => { setCreating(false); setEditing(null); }} onSaved={async () => { setCreating(false); setEditing(null); await refresh(); }} />
      )}
    </div>
  );
}

function GalleryModal({ item, tournaments, nextSort, onClose, onSaved }: { item: Gallery | null; tournaments: Tournament[]; nextSort: number; onClose: () => void; onSaved: () => Promise<void> }) {
  const [form, setForm] = useState({
    caption: item?.caption ?? "",
    tournament_id: item?.tournament_id ?? "",
    sort_order: item?.sort_order ?? nextSort,
    active: item?.active ?? true,
  });
  const [imageUrl, setImageUrl] = useState<string | null>(item?.image_url ?? null);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);

  const onUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5_000_000) return toast.error("Max 5 MB");
    setUploading(true);
    const ext = file.name.split(".").pop()?.toLowerCase() || "jpg";
    const path = `${crypto.randomUUID()}.${ext}`;
    const { error } = await supabase.storage.from("gallery").upload(path, file, { contentType: file.type, cacheControl: "3600" });
    setUploading(false);
    if (error) return toast.error(error.message);
    const { data } = supabase.storage.from("gallery").getPublicUrl(path);
    setImageUrl(data.publicUrl);
    toast.success("Image uploaded");
  };

  const save = async () => {
    if (!imageUrl) return toast.error("Upload an image");
    setSaving(true);
    const payload = {
      image_url: imageUrl,
      caption: form.caption.trim() || null,
      tournament_id: form.tournament_id || null,
      sort_order: form.sort_order,
      active: form.active,
    };
    const { error } = item ? await supabase.from("gallery_images").update(payload).eq("id", item.id) : await supabase.from("gallery_images").insert(payload);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success(item ? "Updated" : "Added"); await onSaved();
  };

  return (
    <ModalShell title={item ? "Edit Image" : "Add Image"} onClose={onClose}>
      <div className="space-y-3">
        <div>
          <label className={labelCls}>Image *</label>
          <div className="flex gap-3 items-start">
            <div className="w-32 h-32 rounded-md border border-border bg-background/60 flex items-center justify-center overflow-hidden shrink-0">
              {imageUrl ? <img src={imageUrl} alt="preview" className="w-full h-full object-cover" /> : <ImageIcon className="w-6 h-6 text-muted-foreground" />}
            </div>
            <div className="flex-1">
              <input type="file" accept="image/*" onChange={onUpload} disabled={uploading} className="block w-full text-xs file:mr-3 file:py-2 file:px-3 file:rounded-md file:border-0 file:bg-neon file:text-neon-foreground file:font-bold file:text-xs file:uppercase file:cursor-pointer" />
              {uploading && <p className="text-xs text-neon mt-2 inline-flex items-center gap-1"><Loader2 size={12} className="animate-spin" /> Uploading…</p>}
            </div>
          </div>
        </div>
        <div><label className={labelCls}>Caption</label><input className={inputCls} value={form.caption} onChange={(e) => setForm({ ...form, caption: e.target.value })} /></div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className={labelCls}>Tournament (optional)</label>
            <select className={inputCls} value={form.tournament_id} onChange={(e) => setForm({ ...form, tournament_id: e.target.value })}>
              <option value="">— Site-wide —</option>
              {tournaments.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
            </select>
          </div>
          <div><label className={labelCls}>Sort Order</label><input type="number" className={inputCls} value={form.sort_order} onChange={(e) => setForm({ ...form, sort_order: Number(e.target.value) || 0 })} /></div>
        </div>
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={form.active} onChange={(e) => setForm({ ...form, active: e.target.checked })} /> Visible on public site</label>
      </div>
      <ModalFooter onCancel={onClose} onSave={save} saving={saving || uploading} label={item ? "Save" : "Add"} />
    </ModalShell>
  );
}

/* ---------------- TOURNAMENT SPONSORS (auto-scrolling row) ---------------- */
function TournamentSponsorsEditor({ tournamentId }: { tournamentId: string }) {
  const [items, setItems] = useState<TSponsor[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<TSponsor | null>(null);
  const [creating, setCreating] = useState(false);

  const refresh = async () => {
    const { data } = await supabase
      .from("tournament_sponsors")
      .select("*")
      .eq("tournament_id", tournamentId)
      .order("sort_order", { ascending: true })
      .order("created_at", { ascending: true });
    setItems((data ?? []) as TSponsor[]);
    setLoading(false);
  };
  useEffect(() => { setLoading(true); refresh(); /* eslint-disable-next-line */ }, [tournamentId]);

  const remove = async (s: TSponsor) => {
    if (!confirm("Remove this sponsor from the row?")) return;
    if (s.logo_url) {
      const m = s.logo_url.match(/\/object\/public\/sponsors\/(.+)$/);
      if (m) await supabase.storage.from("sponsors").remove([decodeURIComponent(m[1])]);
    }
    const { error } = await supabase.from("tournament_sponsors").delete().eq("id", s.id);
    if (error) return toast.error(error.message);
    toast.success("Removed"); refresh();
  };

  const toggleActive = async (s: TSponsor) => {
    const { error } = await supabase.from("tournament_sponsors").update({ active: !s.active }).eq("id", s.id);
    if (error) return toast.error(error.message);
    refresh();
  };

  const move = async (s: TSponsor, dir: -1 | 1) => {
    const list = [...items];
    const idx = list.findIndex((x) => x.id === s.id);
    const swap = list[idx + dir];
    if (!swap) return;
    if (s.sort_order === swap.sort_order) {
      for (let i = 0; i < list.length; i++) {
        await supabase.from("tournament_sponsors").update({ sort_order: i * 10 }).eq("id", list[i].id);
      }
      await refresh();
      return;
    }
    await Promise.all([
      supabase.from("tournament_sponsors").update({ sort_order: swap.sort_order }).eq("id", s.id),
      supabase.from("tournament_sponsors").update({ sort_order: s.sort_order }).eq("id", swap.id),
    ]);
    refresh();
  };

  if (loading) return <div className="text-center py-8"><Loader2 className="w-5 h-5 mx-auto animate-spin text-neon" /></div>;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between gap-3">
        <p className="text-xs text-muted-foreground">
          Logos appear in an auto-scrolling row between the Prizes and Tournament Structure sections. Recommended logo: 280×220 px (PNG with transparent background).
        </p>
        <button onClick={() => setCreating(true)} className="inline-flex items-center gap-2 px-3 py-2 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground text-xs uppercase tracking-wider font-bold shadow-neon shrink-0">
          <Plus size={14} /> Add Sponsor
        </button>
      </div>
      {items.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground">No sponsors added for this tournament yet.</div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {items.map((s, i) => (
            <div key={s.id} className={`rounded-xl border overflow-hidden bg-card/60 ${s.active ? "border-border" : "border-border/40 opacity-60"}`}>
              <div className="aspect-[280/220] bg-background/60 flex items-center justify-center p-3">
                {s.logo_url ? (
                  <img src={s.logo_url} alt={s.name} className="max-w-full max-h-full object-contain" loading="lazy" />
                ) : (
                  <div className="font-display text-sm text-muted-foreground text-center">{s.name}</div>
                )}
              </div>
              <div className="p-2">
                <p className="text-xs font-bold truncate">{s.name}</p>
                {s.link_url && <p className="text-[10px] text-neon truncate">{s.link_url}</p>}
                <div className="flex items-center justify-between gap-1 mt-2 pt-2 border-t border-border">
                  <div className="flex gap-0.5">
                    <button onClick={() => move(s, -1)} disabled={i === 0} className="p-1 rounded text-muted-foreground hover:text-neon disabled:opacity-30"><ArrowUp size={12} /></button>
                    <button onClick={() => move(s, 1)} disabled={i === items.length - 1} className="p-1 rounded text-muted-foreground hover:text-neon disabled:opacity-30"><ArrowDown size={12} /></button>
                  </div>
                  <div className="flex gap-0.5">
                    <button onClick={() => toggleActive(s)} className="p-1 rounded text-muted-foreground hover:text-neon">{s.active ? <Eye size={12} /> : <EyeOff size={12} />}</button>
                    <button onClick={() => setEditing(s)} className="p-1 rounded text-neon"><Edit3 size={12} /></button>
                    <button onClick={() => remove(s)} className="p-1 rounded text-destructive"><Trash2 size={12} /></button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
      {(creating || editing) && (
        <TournamentSponsorModal
          item={editing}
          tournamentId={tournamentId}
          nextSort={items.length * 10}
          onClose={() => { setCreating(false); setEditing(null); }}
          onSaved={async () => { setCreating(false); setEditing(null); await refresh(); }}
        />
      )}
    </div>
  );
}

function TournamentSponsorModal({ item, tournamentId, nextSort, onClose, onSaved }: { item: TSponsor | null; tournamentId: string; nextSort: number; onClose: () => void; onSaved: () => Promise<void> }) {
  const [form, setForm] = useState({
    name: item?.name ?? "",
    link_url: item?.link_url ?? "",
    sort_order: item?.sort_order ?? nextSort,
    active: item?.active ?? true,
  });
  const [logoUrl, setLogoUrl] = useState<string | null>(item?.logo_url ?? null);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);

  const onUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 3_000_000) return toast.error("Max 3 MB");
    setUploading(true);
    const ext = file.name.split(".").pop()?.toLowerCase() || "png";
    const path = `tournament-${tournamentId}/${crypto.randomUUID()}.${ext}`;
    const { error } = await supabase.storage.from("sponsors").upload(path, file, { contentType: file.type, cacheControl: "3600" });
    setUploading(false);
    if (error) return toast.error(error.message);
    const { data } = supabase.storage.from("sponsors").getPublicUrl(path);
    setLogoUrl(data.publicUrl);
    toast.success("Logo uploaded");
  };

  const save = async () => {
    if (!form.name.trim()) return toast.error("Sponsor name required");
    setSaving(true);
    const payload = {
      tournament_id: tournamentId,
      name: form.name.trim(),
      logo_url: logoUrl,
      link_url: form.link_url.trim() || null,
      sort_order: form.sort_order,
      active: form.active,
    };
    const { error } = item
      ? await supabase.from("tournament_sponsors").update(payload).eq("id", item.id)
      : await supabase.from("tournament_sponsors").insert(payload);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success(item ? "Updated" : "Added"); await onSaved();
  };

  return (
    <ModalShell title={item ? "Edit Sponsor" : "Add Sponsor"} onClose={onClose}>
      <div className="space-y-3">
        <div>
          <label className={labelCls}>Logo (recommended 280×220 px)</label>
          <div className="flex gap-3 items-start">
            <div className="w-32 h-24 rounded-md border border-border bg-background/60 flex items-center justify-center overflow-hidden shrink-0 p-2">
              {logoUrl ? <img src={logoUrl} alt="preview" className="w-full h-full object-contain" /> : <ImageIcon className="w-6 h-6 text-muted-foreground" />}
            </div>
            <div className="flex-1">
              <input type="file" accept="image/*" onChange={onUpload} disabled={uploading} className="block w-full text-xs file:mr-3 file:py-2 file:px-3 file:rounded-md file:border-0 file:bg-neon file:text-neon-foreground file:font-bold file:text-xs file:uppercase file:cursor-pointer" />
              {uploading && <p className="text-xs text-neon mt-2 inline-flex items-center gap-1"><Loader2 size={12} className="animate-spin" /> Uploading…</p>}
            </div>
          </div>
        </div>
        <div><label className={labelCls}>Name *</label><input className={inputCls} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Sponsor name" /></div>
        <div><label className={labelCls}>Link URL (optional)</label><input className={inputCls} value={form.link_url} onChange={(e) => setForm({ ...form, link_url: e.target.value })} placeholder="https://example.com" /></div>
        <div><label className={labelCls}>Sort Order</label><input type="number" className={inputCls} value={form.sort_order} onChange={(e) => setForm({ ...form, sort_order: Number(e.target.value) || 0 })} /></div>
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={form.active} onChange={(e) => setForm({ ...form, active: e.target.checked })} /> Visible in sponsor row</label>
      </div>
      <ModalFooter onCancel={onClose} onSave={save} saving={saving || uploading} label={item ? "Save" : "Add"} />
    </ModalShell>
  );
}

/* ---------------- Shared modal helpers ---------------- */
function ModalShell({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur" onClick={onClose}>
      <div className="w-full max-w-2xl rounded-2xl border border-border bg-card p-6 shadow-glow max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display text-xl text-neon">{title}</h3>
          <button onClick={onClose} className="p-2 hover:bg-accent rounded"><X size={16} /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

function ModalFooter({ onCancel, onSave, saving, label }: { onCancel: () => void; onSave: () => void; saving: boolean; label: string }) {
  return (
    <div className="mt-5 flex justify-end gap-2">
      <button onClick={onCancel} className="px-4 py-2 rounded-md border border-border text-xs uppercase tracking-wider font-bold">Cancel</button>
      <button onClick={onSave} disabled={saving} className="inline-flex items-center gap-2 px-4 py-2 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground text-xs uppercase tracking-wider font-bold disabled:opacity-50">
        {saving && <Loader2 size={14} className="animate-spin" />}
        <Save size={14} /> {label}
      </button>
    </div>
  );
}
