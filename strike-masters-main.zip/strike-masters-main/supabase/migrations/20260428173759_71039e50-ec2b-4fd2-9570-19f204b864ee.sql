CREATE OR REPLACE VIEW public.registrations_public
WITH (security_invoker=off) AS
SELECT id, tournament_id, team_name, captain_name
FROM public.registrations
WHERE payment_status = 'verified';

GRANT SELECT ON public.registrations_public TO anon, authenticated;