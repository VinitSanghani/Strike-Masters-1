CREATE TABLE public.about_content (
  id INTEGER NOT NULL PRIMARY KEY DEFAULT 1,
  eyebrow TEXT NOT NULL DEFAULT 'About the Tournament',
  hero_title TEXT NOT NULL DEFAULT 'A Premier Bowling Event',
  hero_description TEXT NOT NULL DEFAULT 'Strike Masters is a premier competitive bowling event bringing together top teams for a high-energy tournament experience focused on skill, competition, and community.',
  format_title TEXT NOT NULL DEFAULT 'The Format',
  format_intro TEXT NOT NULL DEFAULT 'Team-only competition. Assemble a 3-player squad and battle through qualification rounds and the grand finale.',
  format_bullets TEXT[] NOT NULL DEFAULT ARRAY['3 players per team','Open registration until lane capacity is filled','Qualification scored by total team pinfall','Top-performing teams advance to the Finals','2 days of action — Qualification + Finals'],
  scoring_title TEXT NOT NULL DEFAULT 'Scoring System',
  scoring_intro TEXT NOT NULL DEFAULT 'Standard 10-pin scoring with electronic tracking on every lane at LaneX. Tiebreakers decided by a 9-pin no-tap rolloff.',
  scoring_bullets TEXT[] NOT NULL DEFAULT ARRAY['Team rank: combined pinfall across qualification','Number of finalists may vary based on registrations','Live leaderboard updates between batches','Final standings confirmed at the awards ceremony'],
  who_title TEXT NOT NULL DEFAULT 'Who Can Compete',
  eligibility_label TEXT NOT NULL DEFAULT 'Eligibility',
  eligibility_text TEXT NOT NULL DEFAULT 'Open to bowlers 16 years and older. All skill levels welcome — from passionate amateurs to seasoned competitors.',
  team_label TEXT NOT NULL DEFAULT 'Team Composition',
  team_text TEXT NOT NULL DEFAULT 'Each team must have a designated captain and exactly 3 players. Player names lock once the team is registered.',
  equipment_label TEXT NOT NULL DEFAULT 'Equipment',
  equipment_text TEXT NOT NULL DEFAULT 'House balls and shoes provided by LaneX. Players are welcome to bring their own gear if they prefer.',
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  CONSTRAINT about_content_singleton CHECK (id = 1)
);

ALTER TABLE public.about_content ENABLE ROW LEVEL SECURITY;

CREATE POLICY "About content publicly readable"
ON public.about_content FOR SELECT
TO public
USING (true);

CREATE POLICY "Admins manage about content"
ON public.about_content FOR ALL
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE TRIGGER update_about_content_updated_at
BEFORE UPDATE ON public.about_content
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

INSERT INTO public.about_content (id) VALUES (1) ON CONFLICT (id) DO NOTHING;