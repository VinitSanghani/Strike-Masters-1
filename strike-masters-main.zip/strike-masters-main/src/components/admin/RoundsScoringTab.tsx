import { useEffect, useMemo, useState } from "react";
import { Loader2, Plus, Trash2, Save, X, Layers, Edit3, ChevronUp, ChevronDown, CheckCircle2, Circle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { formatDateDMY, formatDateTimeDMY } from "@/lib/format-date";

interface TournamentMini { id: string; name: string; status: string; }
interface Round {
  id: string;
  tournament_id: string;
  name: string;
  description: string | null;
  status: string;
  sort_order: number;
  participants_advancing: number | null;
  selection_criteria: string | null;
  scheduled_at: string | null;
}
interface ScoreRow {
  id: string;
  round_id: string;
  registration_id: string;
  tournament_id: string;
  score: number | null;
  position: number | null;
  advanced: boolean;
  notes: string | null;
}
interface Reg {
  id: string;
  team_name: string;
  captain_name: string;
  payment_status: string;
}

const ROUND_STATUSES = ["upcoming", "in_progress", "completed"] as const;

export function RoundsScoringTab() {
  const [tournaments, setTournaments] = useState<TournamentMini[]>([]);
  const [tid, setTid] = useState<string>("");
  const [rounds, setRounds] = useState<Round[]>([]);
  const [scores, setScores] = useState<ScoreRow[]>([]);
  const [regs, setRegs] = useState<Reg[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingRound, setEditingRound] = useState<Partial<Round> | null>(null);
  const [scoringRound, setScoringRound] = useState<Round | null>(null);

  useEffect(() => {
    (async () => {
      const { data } = await supabase.from("tournaments").select("id, name, status").order("created_at", { ascending: false });
      const list = (data ?? []) as TournamentMini[];
      setTournaments(list);
      if (list.length && !tid) setTid(list[0].id);
      setLoading(false);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const refreshTournament = async (tournamentId: string) => {
    const [{ data: r }, { data: s }, { data: rg }] = await Promise.all([
      supabase.from("tournament_rounds").select("*").eq("tournament_id", tournamentId).order("sort_order"),
      supabase.from("round_scores").select("*").eq("tournament_id", tournamentId),
      supabase.from("registrations").select("id, team_name, captain_name, payment_status").eq("tournament_id", tournamentId).eq("payment_status", "verified"),
    ]);
    setRounds((r ?? []) as Round[]);
    setScores((s ?? []) as ScoreRow[]);
    setRegs((rg ?? []) as Reg[]);
  };

  useEffect(() => { if (tid) refreshTournament(tid); }, [tid]);

  const saveRound = async () => {
    if (!editingRound || !tid) return;
    if (!editingRound.name?.trim()) return toast.error("Round name is required");
    const payload = {
      tournament_id: tid,
      name: editingRound.name.trim(),
      description: editingRound.description || null,
      status: editingRound.status || "upcoming",
      sort_order: editingRound.sort_order ?? rounds.length,
      participants_advancing: editingRound.participants_advancing ?? null,
      selection_criteria: editingRound.selection_criteria || null,
      scheduled_at: editingRound.scheduled_at || null,
    };
    const { error } = editingRound.id
      ? await supabase.from("tournament_rounds").update(payload).eq("id", editingRound.id)
      : await supabase.from("tournament_rounds").insert(payload);
    if (error) return toast.error(error.message);
    toast.success(editingRound.id ? "Round updated" : "Round created");
    setEditingRound(null);
    await refreshTournament(tid);
  };

  const deleteRound = async (id: string) => {
    if (!confirm("Delete this round and all its scores?")) return;
    await supabase.from("round_scores").delete().eq("round_id", id);
    const { error } = await supabase.from("tournament_rounds").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Round deleted");
    await refreshTournament(tid);
  };

  const move = async (r: Round, dir: -1 | 1) => {
    const newOrder = r.sort_order + dir;
    const swap = rounds.find((x) => x.sort_order === newOrder);
    if (!swap) return;
    await supabase.from("tournament_rounds").update({ sort_order: newOrder }).eq("id", r.id);
    await supabase.from("tournament_rounds").update({ sort_order: r.sort_order }).eq("id", swap.id);
    await refreshTournament(tid);
  };

  if (loading) return <div className="text-center py-12"><Loader2 className="w-6 h-6 mx-auto animate-spin text-neon" /></div>;

  if (!tournaments.length) {
    return <div className="rounded-2xl border border-dashed border-border p-10 text-center text-sm text-muted-foreground">Create a tournament first.</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center gap-3">
        <label className="text-[10px] uppercase tracking-widest text-muted-foreground">Tournament</label>
        <select value={tid} onChange={(e) => setTid(e.target.value)} className="px-3 py-2 rounded-md bg-input/60 border border-border text-sm">
          {tournaments.map((t) => <option key={t.id} value={t.id}>{t.name} · {t.status}</option>)}
        </select>
        <button
          onClick={() => setEditingRound({ name: "", status: "upcoming", sort_order: rounds.length })}
          className="ml-auto inline-flex items-center gap-2 px-4 py-2 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground text-xs uppercase tracking-wider font-bold shadow-neon"
        >
          <Plus size={14} /> New Round
        </button>
      </div>

      {rounds.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border p-10 text-center text-sm text-muted-foreground">
          <Layers className="w-10 h-10 mx-auto text-neon mb-2" />
          No rounds yet. Add Qualification, Quarter-Finals, Finals, etc.
        </div>
      ) : (
        <div className="space-y-3">
          {rounds.map((r, idx) => {
            const myScores = scores.filter((s) => s.round_id === r.id);
            const advancedCount = myScores.filter((s) => s.advanced).length;
            return (
              <div key={r.id} className="rounded-2xl border border-border bg-card/60 p-5 shadow-glow">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2 mb-1">
                      <span className="text-[10px] uppercase tracking-widest text-muted-foreground font-bold">Round {idx + 1}</span>
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] uppercase tracking-wider font-bold border ${
                        r.status === "completed" ? "border-success/40 text-success" :
                        r.status === "in_progress" ? "border-neon/40 text-neon" :
                        "border-amber-400/40 text-amber-400"
                      }`}>
                        {r.status === "completed" ? <CheckCircle2 size={10} /> : <Circle size={10} />}
                        {r.status.replace("_", " ")}
                      </span>
                      {r.scheduled_at && <span className="text-[10px] text-muted-foreground">{formatDateTimeDMY(r.scheduled_at)}</span>}
                    </div>
                    <h4 className="font-display text-xl">{r.name}</h4>
                    {r.description && <p className="text-xs text-muted-foreground mt-1">{r.description}</p>}
                    <div className="mt-2 flex flex-wrap gap-3 text-[11px] text-muted-foreground">
                      <span>Entries scored: <span className="text-foreground font-bold">{myScores.length}</span></span>
                      {r.participants_advancing != null && (
                        <span>Advancing: <span className="text-foreground font-bold">{advancedCount} / {r.participants_advancing}</span></span>
                      )}
                      {r.selection_criteria && <span>Criteria: <span className="text-foreground">{r.selection_criteria}</span></span>}
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-1">
                    <div className="flex items-center gap-1">
                      <button disabled={idx === 0} onClick={() => move(r, -1)} className="p-1.5 rounded text-muted-foreground hover:text-neon disabled:opacity-30"><ChevronUp size={14} /></button>
                      <button disabled={idx === rounds.length - 1} onClick={() => move(r, 1)} className="p-1.5 rounded text-muted-foreground hover:text-neon disabled:opacity-30"><ChevronDown size={14} /></button>
                    </div>
                    <div className="flex items-center gap-1">
                      <button onClick={() => setScoringRound(r)} className="px-2 py-1 rounded text-[10px] uppercase font-bold tracking-wider border border-neon/40 text-neon hover:bg-neon/10">Enter Scores</button>
                      <button onClick={() => setEditingRound(r)} className="p-1.5 rounded text-neon hover:bg-neon/10" title="Edit"><Edit3 size={14} /></button>
                      <button onClick={() => deleteRound(r.id)} className="p-1.5 rounded text-destructive hover:bg-destructive/10" title="Delete"><Trash2 size={14} /></button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {editingRound && (
        <RoundModal value={editingRound} onChange={setEditingRound} onSave={saveRound} onClose={() => setEditingRound(null)} />
      )}

      {scoringRound && (
        <ScoresModal
          round={scoringRound}
          regs={regs}
          existing={scores.filter((s) => s.round_id === scoringRound.id)}
          onClose={() => setScoringRound(null)}
          onSaved={async () => { setScoringRound(null); await refreshTournament(tid); }}
        />
      )}
    </div>
  );
}

function RoundModal({
  value, onChange, onSave, onClose,
}: { value: Partial<Round>; onChange: (v: Partial<Round>) => void; onSave: () => void; onClose: () => void; }) {
  const inputCls = "w-full px-3 py-2 rounded-md bg-input/60 border border-border text-sm focus:border-neon focus:outline-none";
  const labelCls = "block text-[10px] uppercase tracking-widest text-muted-foreground mb-1";
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur" onClick={onClose}>
      <div className="w-full max-w-xl rounded-2xl border border-border bg-card p-6 shadow-glow max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display text-xl text-neon">{value.id ? "Edit Round" : "New Round"}</h3>
          <button onClick={onClose} className="p-2 hover:bg-accent rounded"><X size={16} /></button>
        </div>
        <div className="space-y-3">
          <div>
            <label className={labelCls}>Round Name</label>
            <input className={inputCls} value={value.name ?? ""} onChange={(e) => onChange({ ...value, name: e.target.value })} placeholder="e.g. Qualification, Quarter-Finals, Finals" />
          </div>
          <div>
            <label className={labelCls}>Description</label>
            <textarea rows={2} className={inputCls} value={value.description ?? ""} onChange={(e) => onChange({ ...value, description: e.target.value })} />
          </div>
          <div className="grid sm:grid-cols-2 gap-3">
            <div>
              <label className={labelCls}>Status</label>
              <select className={inputCls} value={value.status ?? "upcoming"} onChange={(e) => onChange({ ...value, status: e.target.value })}>
                {ROUND_STATUSES.map((s) => <option key={s} value={s}>{s.replace("_", " ")}</option>)}
              </select>
            </div>
            <div>
              <label className={labelCls}>Scheduled At</label>
              <input type="datetime-local" className={inputCls}
                value={value.scheduled_at ? new Date(value.scheduled_at).toISOString().slice(0, 16) : ""}
                onChange={(e) => onChange({ ...value, scheduled_at: e.target.value ? new Date(e.target.value).toISOString() : null })} />
            </div>
            <div>
              <label className={labelCls}>Participants Advancing</label>
              <input type="number" min={0} className={inputCls} value={value.participants_advancing ?? ""} onChange={(e) => onChange({ ...value, participants_advancing: e.target.value ? parseInt(e.target.value) : null })} placeholder="e.g. 8" />
            </div>
            <div>
              <label className={labelCls}>Selection Criteria</label>
              <input className={inputCls} value={value.selection_criteria ?? ""} onChange={(e) => onChange({ ...value, selection_criteria: e.target.value })} placeholder="e.g. Top 8 by score" />
            </div>
          </div>
        </div>
        <div className="mt-5 flex justify-end gap-2">
          <button onClick={onClose} className="px-4 py-2 rounded-md border border-border text-xs uppercase tracking-wider font-bold">Cancel</button>
          <button onClick={onSave} className="inline-flex items-center gap-2 px-4 py-2 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground text-xs uppercase tracking-wider font-bold">
            <Save size={14} /> Save
          </button>
        </div>
      </div>
    </div>
  );
}

function ScoresModal({
  round, regs, existing, onClose, onSaved,
}: { round: Round; regs: Reg[]; existing: ScoreRow[]; onClose: () => void; onSaved: () => Promise<void>; }) {
  const initial = useMemo(() => {
    const map = new Map<string, { score: string; advanced: boolean; notes: string }>();
    for (const r of regs) map.set(r.id, { score: "", advanced: false, notes: "" });
    for (const s of existing) {
      map.set(s.registration_id, {
        score: s.score?.toString() ?? "",
        advanced: s.advanced,
        notes: s.notes ?? "",
      });
    }
    return map;
  }, [regs, existing]);
  const [rows, setRows] = useState<Map<string, { score: string; advanced: boolean; notes: string }>>(initial);
  const [saving, setSaving] = useState(false);

  const update = (id: string, patch: Partial<{ score: string; advanced: boolean; notes: string }>) => {
    const next = new Map(rows);
    next.set(id, { ...next.get(id)!, ...patch });
    setRows(next);
  };

  const sorted = useMemo(() => {
    return [...regs].sort((a, b) => {
      const sa = parseFloat(rows.get(a.id)?.score || "0");
      const sb = parseFloat(rows.get(b.id)?.score || "0");
      return sb - sa;
    });
  }, [regs, rows]);

  const autoMarkTop = () => {
    if (!round.participants_advancing) return toast.error("Set 'Participants Advancing' on the round first.");
    const top = new Set(sorted.slice(0, round.participants_advancing).map((r) => r.id));
    const next = new Map(rows);
    for (const r of regs) {
      const cur = next.get(r.id)!;
      next.set(r.id, { ...cur, advanced: top.has(r.id) });
    }
    setRows(next);
    toast.success(`Marked top ${round.participants_advancing} as advancing`);
  };

  const save = async () => {
    setSaving(true);
    try {
      const ranked = [...regs].sort((a, b) => {
        const sa = parseFloat(rows.get(a.id)?.score || "0");
        const sb = parseFloat(rows.get(b.id)?.score || "0");
        return sb - sa;
      });
      const positionMap = new Map<string, number>();
      ranked.forEach((r, i) => {
        const v = rows.get(r.id);
        if (v && v.score !== "") positionMap.set(r.id, i + 1);
      });

      // Delete existing for this round, then insert fresh
      await supabase.from("round_scores").delete().eq("round_id", round.id);
      const inserts = regs
        .filter((r) => {
          const v = rows.get(r.id)!;
          return v.score !== "" || v.advanced || v.notes;
        })
        .map((r) => {
          const v = rows.get(r.id)!;
          return {
            round_id: round.id,
            tournament_id: round.tournament_id,
            registration_id: r.id,
            score: v.score === "" ? null : parseFloat(v.score),
            position: positionMap.get(r.id) ?? null,
            advanced: v.advanced,
            notes: v.notes || null,
          };
        });
      if (inserts.length) {
        const { error } = await supabase.from("round_scores").insert(inserts);
        if (error) throw error;
      }
      // Update qualification_status text on advancing registrations
      const advancingIds = inserts.filter((i) => i.advanced).map((i) => i.registration_id);
      if (advancingIds.length) {
        await supabase.from("registrations").update({ qualification_status: `Advanced from ${round.name}` }).in("id", advancingIds);
      }
      toast.success("Scores saved");
      await onSaved();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Save failed");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur" onClick={onClose}>
      <div className="w-full max-w-4xl rounded-2xl border border-border bg-card p-6 shadow-glow max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-start justify-between mb-4 gap-3">
          <div>
            <h3 className="font-display text-xl text-neon">{round.name} — Enter Scores</h3>
            <p className="text-xs text-muted-foreground">Verified registrations only. Positions auto-assigned by score (highest first).</p>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-accent rounded"><X size={16} /></button>
        </div>

        {regs.length === 0 ? (
          <div className="text-center py-12 text-sm text-muted-foreground">No verified registrations in this tournament yet.</div>
        ) : (
          <>
            {round.participants_advancing != null && (
              <button onClick={autoMarkTop} className="mb-3 px-3 py-2 rounded-md border border-neon/40 text-neon text-xs uppercase tracking-wider font-bold hover:bg-neon/10">
                Auto-mark top {round.participants_advancing} as advancing
              </button>
            )}
            <div className="overflow-x-auto rounded-xl border border-border">
              <table className="w-full text-sm">
                <thead className="bg-card/80 text-left text-[10px] uppercase tracking-widest text-muted-foreground">
                  <tr>
                    <th className="px-3 py-2 w-10">#</th>
                    <th className="px-3 py-2">Team</th>
                    <th className="px-3 py-2 w-28">Score</th>
                    <th className="px-3 py-2 w-24">Advance</th>
                    <th className="px-3 py-2">Notes</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {sorted.map((r, i) => {
                    const v = rows.get(r.id)!;
                    return (
                      <tr key={r.id}>
                        <td className="px-3 py-2 text-xs text-muted-foreground">{v.score ? i + 1 : "—"}</td>
                        <td className="px-3 py-2">
                          <div className="font-display text-sm">{r.team_name}</div>
                          <div className="text-[11px] text-muted-foreground">{r.captain_name}</div>
                        </td>
                        <td className="px-3 py-2">
                          <input type="number" step="0.01" value={v.score} onChange={(e) => update(r.id, { score: e.target.value })}
                            className="w-full px-2 py-1.5 rounded-md bg-input/60 border border-border text-sm focus:border-neon focus:outline-none" />
                        </td>
                        <td className="px-3 py-2 text-center">
                          <input type="checkbox" checked={v.advanced} onChange={(e) => update(r.id, { advanced: e.target.checked })} />
                        </td>
                        <td className="px-3 py-2">
                          <input value={v.notes} onChange={(e) => update(r.id, { notes: e.target.value })}
                            className="w-full px-2 py-1.5 rounded-md bg-input/60 border border-border text-xs focus:border-neon focus:outline-none" />
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            <div className="mt-5 flex justify-end gap-2">
              <button onClick={onClose} className="px-4 py-2 rounded-md border border-border text-xs uppercase tracking-wider font-bold">Cancel</button>
              <button onClick={save} disabled={saving} className="inline-flex items-center gap-2 px-4 py-2 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground text-xs uppercase tracking-wider font-bold disabled:opacity-50">
                {saving && <Loader2 size={14} className="animate-spin" />}
                <Save size={14} /> Save Scores
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
