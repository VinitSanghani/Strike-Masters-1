export function SectionHeader({
  eyebrow,
  title,
  description,
  centered = true,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
  centered?: boolean;
}) {
  return (
    <div className={`mb-10 sm:mb-12 ${centered ? "text-center mx-auto max-w-2xl px-2" : ""}`}>
      {eyebrow && (
        <div className="inline-block px-3 py-1 rounded-full border border-neon/40 bg-neon/10 text-neon text-[11px] sm:text-xs font-bold uppercase tracking-widest mb-4">
          {eyebrow}
        </div>
      )}
      <h2 className="font-display text-3xl sm:text-4xl md:text-5xl leading-tight">
        <span className="text-gradient-neon">{title}</span>
      </h2>
      {description && (
        <p className="mt-3 sm:mt-4 text-muted-foreground text-sm sm:text-base md:text-lg">{description}</p>
      )}
    </div>
  );
}
