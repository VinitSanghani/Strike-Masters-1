-- Per-tournament sponsor strip (auto-scrolling row of logos)
CREATE TABLE public.tournament_sponsors (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tournament_id UUID NOT NULL REFERENCES public.tournaments(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  logo_url TEXT,
  link_url TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0,
  active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

CREATE INDEX idx_tournament_sponsors_tournament ON public.tournament_sponsors(tournament_id, sort_order, created_at);

ALTER TABLE public.tournament_sponsors ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Tournament sponsors publicly readable"
ON public.tournament_sponsors
FOR SELECT
USING ((active = true) OR public.has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins manage tournament sponsors"
ON public.tournament_sponsors
FOR ALL
TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role));

CREATE TRIGGER update_tournament_sponsors_updated_at
BEFORE UPDATE ON public.tournament_sponsors
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();