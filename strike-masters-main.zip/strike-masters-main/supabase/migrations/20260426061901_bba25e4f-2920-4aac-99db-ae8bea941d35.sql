ALTER TABLE public.registrations
  ADD COLUMN IF NOT EXISTS razorpay_order_id text,
  ADD COLUMN IF NOT EXISTS razorpay_payment_id text,
  ADD COLUMN IF NOT EXISTS razorpay_signature text,
  ADD COLUMN IF NOT EXISTS amount_paid integer;

CREATE INDEX IF NOT EXISTS idx_registrations_razorpay_order ON public.registrations(razorpay_order_id);
CREATE INDEX IF NOT EXISTS idx_registrations_razorpay_payment ON public.registrations(razorpay_payment_id);

ALTER TABLE public.tournament_settings
  ADD COLUMN IF NOT EXISTS registration_fee integer NOT NULL DEFAULT 3000;

UPDATE public.tournament_settings SET registration_fee = 3000 WHERE id = 1;