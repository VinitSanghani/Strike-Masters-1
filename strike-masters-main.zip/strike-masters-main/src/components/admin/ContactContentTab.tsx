import { useEffect, useState } from "react";
import { Loader2, Save } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface ContactContent {
  id: number;
  eyebrow: string;
  title: string;
  description: string;
  organizers_label: string;
  organizers_value: string;
  email_label: string;
  email_value: string;
  phone_label: string;
  phone_value: string;
  whatsapp_number: string;
  whatsapp_message: string;
  venue_label: string;
  venue_value: string;
  map_query: string;
}

const inputCls = "w-full px-3 py-2 rounded-md bg-input/60 border border-border text-sm focus:border-neon focus:outline-none";
const labelCls = "block text-[10px] uppercase tracking-widest text-muted-foreground mb-1";

export function ContactContentTab() {
  const [data, setData] = useState<ContactContent | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const refresh = async () => {
    const { data: row } = await (supabase as any)
      .from("contact_content")
      .select("*")
      .eq("id", 1)
      .maybeSingle();
    setData(row as ContactContent | null);
    setLoading(false);
  };

  useEffect(() => { refresh(); }, []);

  if (loading || !data) {
    return <div className="text-center py-12"><Loader2 className="w-6 h-6 mx-auto animate-spin text-neon" /></div>;
  }

  const set = <K extends keyof ContactContent>(k: K, v: ContactContent[K]) => setData({ ...data, [k]: v });

  const save = async () => {
    setSaving(true);
    const { id, ...payload } = data;
    void id;
    const { error } = await (supabase as any).from("contact_content").update(payload).eq("id", 1);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Contact page updated");
  };

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-border bg-card/40 p-6 space-y-4">
        <h3 className="font-display text-lg text-neon">Page Header</h3>
        <div className="grid sm:grid-cols-2 gap-3">
          <div>
            <label className={labelCls}>Eyebrow</label>
            <input className={inputCls} value={data.eyebrow} onChange={(e) => set("eyebrow", e.target.value)} />
          </div>
          <div>
            <label className={labelCls}>Title</label>
            <input className={inputCls} value={data.title} onChange={(e) => set("title", e.target.value)} />
          </div>
        </div>
        <div>
          <label className={labelCls}>Description</label>
          <textarea rows={3} className={inputCls} value={data.description} onChange={(e) => set("description", e.target.value)} />
        </div>
      </div>

      <div className="rounded-2xl border border-border bg-card/40 p-6 space-y-4">
        <h3 className="font-display text-lg text-neon">Contact Details</h3>
        <div className="grid sm:grid-cols-2 gap-3">
          <div>
            <label className={labelCls}>Organizers Label</label>
            <input className={inputCls} value={data.organizers_label} onChange={(e) => set("organizers_label", e.target.value)} />
          </div>
          <div>
            <label className={labelCls}>Organizers</label>
            <input className={inputCls} value={data.organizers_value} onChange={(e) => set("organizers_value", e.target.value)} />
          </div>
          <div>
            <label className={labelCls}>Email Label</label>
            <input className={inputCls} value={data.email_label} onChange={(e) => set("email_label", e.target.value)} />
          </div>
          <div>
            <label className={labelCls}>Email Address</label>
            <input className={inputCls} value={data.email_value} onChange={(e) => set("email_value", e.target.value)} />
          </div>
          <div>
            <label className={labelCls}>Phone Label</label>
            <input className={inputCls} value={data.phone_label} onChange={(e) => set("phone_label", e.target.value)} />
          </div>
          <div>
            <label className={labelCls}>Phone Number (e.g. +91 95869 95356)</label>
            <input className={inputCls} value={data.phone_value} onChange={(e) => set("phone_value", e.target.value)} />
          </div>
          <div>
            <label className={labelCls}>Venue Label</label>
            <input className={inputCls} value={data.venue_label} onChange={(e) => set("venue_label", e.target.value)} />
          </div>
          <div>
            <label className={labelCls}>Venue Address</label>
            <input className={inputCls} value={data.venue_value} onChange={(e) => set("venue_value", e.target.value)} />
          </div>
        </div>
      </div>

      <div className="rounded-2xl border border-border bg-card/40 p-6 space-y-4">
        <h3 className="font-display text-lg text-neon">WhatsApp & Map</h3>
        <div className="grid sm:grid-cols-2 gap-3">
          <div>
            <label className={labelCls}>WhatsApp Number (digits only, with country code — e.g. 919586995356)</label>
            <input className={inputCls} value={data.whatsapp_number} onChange={(e) => set("whatsapp_number", e.target.value.replace(/[^\d]/g, ""))} />
          </div>
          <div>
            <label className={labelCls}>Map Query (e.g. "AR Mall Surat")</label>
            <input className={inputCls} value={data.map_query} onChange={(e) => set("map_query", e.target.value)} />
          </div>
        </div>
        <div>
          <label className={labelCls}>WhatsApp Pre-filled Message</label>
          <textarea rows={2} className={inputCls} value={data.whatsapp_message} onChange={(e) => set("whatsapp_message", e.target.value)} />
        </div>
      </div>

      <div className="flex justify-end">
        <button
          onClick={save}
          disabled={saving}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground text-xs uppercase tracking-wider font-bold shadow-neon disabled:opacity-50"
        >
          {saving ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />}
          Save Contact Page
        </button>
      </div>
    </div>
  );
}
