import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Trophy, Calendar, User, CheckCircle2, Clock, XCircle, Megaphone, FileText, Loader2, Edit3, Download, Save, X, Award, Lock, Upload, Smartphone, Banknote, AlertTriangle, Crown } from "lucide-react";
import { SectionHeader } from "@/components/SectionHeader";
import { useAuth } from "@/hooks/use-auth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { resubmitPaymentProof } from "@/server/razorpay.functions";
import { formatDateDMY, formatDateTimeDMY } from "@/lib/format-date";

export const Route = createFileRoute("/dashboard")({
  head: () => ({
    meta: [
      { title: "Dashboard — Strike Masters" },
      { name: "description", content: "Your Strike Masters team dashboard." },
    ],
  }),
  component: DashboardPage,
});

interface Registration {
  id: string;
  tournament_id: string | null;
  team_name: string;
  captain_name: string;
  captain_email: string;
  captain_phone: string;
  player2_name: string;
  player2_phone: string | null;
  player3_name: string;
  player3_phone: string | null;
  substitute_name: string | null;
  substitute_phone: string | null;
  skill_level: string;
  payment_transaction_id: string | null;
  payment_verified: boolean;
  payment_method: string;
  payment_status: string;
  payment_proof_url: string | null;
  upi_transaction_ref: string | null;
  verification_notes: string | null;
  razorpay_order_id: string | null;
  razorpay_payment_id: string | null;
  amount_paid: number | null;
  status: "pending" | "approved" | "rejected";
  qualification_status: string | null;
  admin_notes: string | null;
  created_at: string;
}

interface TournamentInfo {
  id: string;
  name: string;
  slug: string;
  cash_payment_deadline: string | null;
  upi_qr_url: string | null;
  upi_id: string | null;
  payment_instructions: string | null;
  qualification_date: string | null;
  finals_date: string | null;
  venue: string | null;
  tournament_type: string;
  team_size: number;
}

interface Announcement { id: string; title: string; body: string; pinned: boolean; created_at: string; }
interface Winner { id: string; registration_id: string | null; tournament_id: string; place: number; place_label: string; prize_title: string | null; prize_amount: number | null; }

function DashboardPage() {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [registrations, setRegistrations] = useState<Registration[]>([]);
  const [tournaments, setTournaments] = useState<Record<string, TournamentInfo>>({});
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [winnersByReg, setWinnersByReg] = useState<Record<string, Winner>>({});
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<Registration | null>(null);
  const [resubmitting, setResubmitting] = useState<Registration | null>(null);

  useEffect(() => {
    if (!authLoading && !user) navigate({ to: "/login" });
  }, [user, authLoading, navigate]);

  const refresh = async () => {
    if (!user) return;
    const [regRes, annRes] = await Promise.all([
      supabase.from("registrations").select("*").eq("user_id", user.id).order("created_at", { ascending: false }),
      supabase.from("announcements").select("*").order("pinned", { ascending: false }).order("created_at", { ascending: false }).limit(20),
    ]);
    const regs = (regRes.data ?? []) as Registration[];
    setRegistrations(regs);
    setAnnouncements((annRes.data ?? []) as Announcement[]);
    const tournamentIds = [...new Set(regs.map((r) => r.tournament_id).filter(Boolean))] as string[];
    if (tournamentIds.length) {
      const { data: tns } = await supabase
        .from("tournaments")
        .select("id, name, slug, cash_payment_deadline, upi_qr_url, upi_id, payment_instructions, qualification_date, finals_date, venue, tournament_type, team_size")
        .in("id", tournamentIds);
      const map: Record<string, TournamentInfo> = {};
      for (const t of (tns ?? []) as TournamentInfo[]) map[t.id] = t;
      setTournaments(map);
    }
    const regIds = regs.map((r) => r.id);
    if (regIds.length) {
      const { data: wins } = await supabase
        .from("tournament_winners")
        .select("id, registration_id, tournament_id, place, place_label, prize_title, prize_amount")
        .in("registration_id", regIds);
      const wmap: Record<string, Winner> = {};
      for (const w of (wins ?? []) as Winner[]) if (w.registration_id) wmap[w.registration_id] = w;
      setWinnersByReg(wmap);
    }
    setLoading(false);
  };


  useEffect(() => { refresh(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [user]);

  if (authLoading || loading) {
    return (
      <div className="container mx-auto px-4 py-32 text-center">
        <Loader2 className="w-8 h-8 mx-auto animate-spin text-neon" />
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 sm:px-6 py-14 sm:py-20">
      <SectionHeader
        eyebrow="Participant Dashboard"
        title={`Welcome${registrations[0] ? `, ${registrations[0].captain_name.split(" ")[0]}` : ""}`}
        description="Track your team registrations, payment status, and tournament announcements."
      />

      {registrations.length === 0 ? (
        <div className="max-w-xl mx-auto rounded-2xl border border-border bg-card/60 p-8 text-center shadow-glow">
          <FileText className="w-12 h-12 mx-auto text-neon mb-3" />
          <h3 className="font-display text-2xl mb-2">No registrations yet</h3>
          <p className="text-sm text-muted-foreground mb-5">Browse tournaments and register your team.</p>
          <Link to="/tournaments" className="inline-block px-6 py-3 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground font-bold text-sm uppercase tracking-wider shadow-neon">
            Browse Tournaments
          </Link>
        </div>
      ) : (
        <div className="max-w-5xl mx-auto space-y-8">
          {registrations.map((reg) => (
            <RegistrationCard
              key={reg.id}
              reg={reg}
              tournament={reg.tournament_id ? tournaments[reg.tournament_id] : undefined}
              winner={winnersByReg[reg.id]}
              onEdit={() => setEditing(reg)}
              onResubmit={() => setResubmitting(reg)}
            />
          ))}

          {/* Announcements */}
          <div className="rounded-2xl border border-border bg-card/60 p-6 sm:p-8 shadow-glow">
            <h3 className="font-display text-xl text-neon mb-4 flex items-center gap-2">
              <Megaphone size={18} /> Tournament Announcements
            </h3>
            {announcements.length === 0 ? (
              <p className="text-sm text-muted-foreground">No announcements yet. Check back soon.</p>
            ) : (
              <ul className="divide-y divide-border">
                {announcements.map((a) => (
                  <li key={a.id} className="py-4 first:pt-0 last:pb-0">
                    <div className="flex items-center gap-2 mb-1">
                      {a.pinned && <span className="text-[10px] uppercase tracking-widest text-neon font-bold px-2 py-0.5 rounded border border-neon/40">Pinned</span>}
                      <h4 className="font-display text-base">{a.title}</h4>
                    </div>
                    <p className="text-sm text-muted-foreground whitespace-pre-line">{a.body}</p>
                    <div className="mt-1 text-xs text-muted-foreground">{formatDateTimeDMY(a.created_at)}</div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      )}

      {editing && (
        <EditTeamModal reg={editing} tournament={editing.tournament_id ? tournaments[editing.tournament_id] : undefined} onClose={() => setEditing(null)} onSaved={async () => { setEditing(null); await refresh(); }} />
      )}
      {resubmitting && (
        <ResubmitProofModal reg={resubmitting} onClose={() => setResubmitting(null)} onSaved={async () => { setResubmitting(null); await refresh(); }} />
      )}
    </div>
  );
}

function PaymentBadge({ reg }: { reg: Registration }) {
  const { payment_status, payment_method } = reg;
  const config = {
    verified: { label: "Verified", icon: CheckCircle2, cls: "border-success/40 text-success" },
    awaiting_verification: { label: "Awaiting Verification", icon: Clock, cls: "border-amber-400/40 text-amber-400" },
    pending: { label: payment_method === "cash" ? "Cash Pending" : "Pending", icon: Clock, cls: "border-amber-400/40 text-amber-400" },
    rejected: { label: "Rejected", icon: XCircle, cls: "border-destructive/40 text-destructive" },
  }[payment_status] ?? { label: payment_status, icon: Clock, cls: "border-border text-muted-foreground" };
  const Icon = config.icon;
  return (
    <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] uppercase tracking-wider font-bold border ${config.cls}`}>
      <Icon size={12} /> {config.label}
    </span>
  );
}

function MethodBadge({ method }: { method: string }) {
  if (method === "cash") return <span className="inline-flex items-center gap-1 text-[11px] text-amber-400"><Banknote size={12} /> Cash</span>;
  if (method === "upi_qr") return <span className="inline-flex items-center gap-1 text-[11px] text-neon"><Smartphone size={12} /> UPI / QR</span>;
  return <span className="text-[11px] text-muted-foreground">Online</span>;
}

function RegistrationCard({
  reg, tournament, winner, onEdit, onResubmit,
}: { reg: Registration; tournament?: TournamentInfo; winner?: Winner; onEdit: () => void; onResubmit: () => void; }) {
  const canEdit = reg.status !== "approved" && reg.payment_status !== "verified";
  const cashDeadline = tournament?.cash_payment_deadline ? new Date(tournament.cash_payment_deadline) : null;
  const cashOverdue = cashDeadline && cashDeadline.getTime() < Date.now() && reg.payment_status !== "verified" && reg.payment_method === "cash";
  const isSolo = tournament?.tournament_type === "solo" || (tournament?.team_size ?? 3) <= 1;

  return (
    <div className="rounded-2xl border border-border bg-card/60 p-6 sm:p-8 shadow-glow space-y-5">
      {/* Winner banner — show prominently when team has placed */}
      {winner && <WinnerBanner winner={winner} />}

      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="text-[10px] uppercase tracking-widest text-muted-foreground mb-1">
            {tournament?.name ?? "Tournament"}
          </div>
          <h3 className="font-display text-2xl text-neon flex items-center gap-2">
            <Trophy size={18} /> {reg.team_name}
          </h3>
          <div className="mt-2 flex flex-wrap items-center gap-2 text-xs">
            <PaymentBadge reg={reg} />
            <MethodBadge method={reg.payment_method} />
            {reg.qualification_status && (
              <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full text-[11px] uppercase tracking-wider font-bold border border-gold/40 text-gold">
                <Award size={12} /> {reg.qualification_status}
              </span>
            )}
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          {tournament && (
            <Link
              to="/tournaments/$slug"
              params={{ slug: tournament.slug }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-md border border-border hover:border-neon text-xs uppercase tracking-wider font-bold"
            >
              <Trophy size={14} /> Tournament
            </Link>
          )}
          {canEdit ? (
            <button onClick={onEdit} className="inline-flex items-center gap-2 px-4 py-2 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground text-xs uppercase tracking-wider font-bold shadow-neon">
              <Edit3 size={14} /> Edit Team
            </button>
          ) : (
            <span className="inline-flex items-center gap-2 px-4 py-2 rounded-md border border-border text-xs uppercase tracking-wider font-bold text-muted-foreground">
              <Lock size={14} /> Locked
            </span>
          )}
        </div>
      </div>

      {/* Qualification + Finals — prominent date cards */}
      {tournament && (tournament.qualification_date || tournament.finals_date) && (
        <div className="grid sm:grid-cols-2 gap-3">
          {tournament.qualification_date && (
            <DateCard
              kind="qualification"
              label="Qualification"
              date={tournament.qualification_date}
              venue={tournament.venue}
            />
          )}
          {tournament.finals_date && (
            <DateCard
              kind="finals"
              label="Finals"
              date={tournament.finals_date}
              venue={tournament.venue}
            />
          )}
        </div>
      )}

      {/* Payment alerts */}
      {reg.payment_status === "rejected" && (
        <div className="rounded-xl border border-destructive/40 bg-destructive/10 p-4">
          <div className="flex items-start gap-3">
            <AlertTriangle className="text-destructive shrink-0 mt-0.5" size={16} />
            <div className="flex-1 min-w-0">
              <div className="text-xs font-bold text-destructive uppercase tracking-widest mb-1">Payment Rejected</div>
              <p className="text-sm text-muted-foreground">{reg.verification_notes || "Your payment proof was rejected. Please re-submit a clear screenshot."}</p>
              {reg.payment_method === "upi_qr" && (
                <button onClick={onResubmit} className="mt-3 inline-flex items-center gap-2 px-4 py-2 rounded-md bg-destructive text-destructive-foreground text-xs uppercase tracking-wider font-bold">
                  <Upload size={14} /> Re-upload Proof
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {reg.payment_status === "pending" && reg.payment_method === "cash" && (
        <div className={`rounded-xl border p-4 ${cashOverdue ? "border-destructive/40 bg-destructive/10" : "border-amber-400/40 bg-amber-400/5"}`}>
          <div className="flex items-start gap-3">
            <Banknote className={cashOverdue ? "text-destructive shrink-0 mt-0.5" : "text-amber-400 shrink-0 mt-0.5"} size={16} />
            <div className="flex-1">
              <div className={`text-xs font-bold uppercase tracking-widest mb-1 ${cashOverdue ? "text-destructive" : "text-amber-400"}`}>
                {cashOverdue ? "Cash Payment Overdue" : "Cash Payment Due"}
              </div>
              <p className="text-sm text-muted-foreground">
                Pay <span className="text-foreground font-bold">₹{reg.amount_paid != null ? (reg.amount_paid / 100).toLocaleString("en-IN") : "—"}</span> in cash at the venue
                {cashDeadline ? <> by <span className="text-foreground font-bold">{formatDateDMY(cashDeadline)}</span></> : null}.
                Your registration will be confirmed once the organizers verify the payment.
              </p>
            </div>
          </div>
        </div>
      )}

      {reg.payment_status === "awaiting_verification" && reg.payment_method === "upi_qr" && (
        <div className="rounded-xl border border-neon/30 bg-neon/5 p-4">
          <div className="flex items-start gap-3">
            <Clock className="text-neon shrink-0 mt-0.5" size={16} />
            <div className="flex-1">
              <div className="text-xs font-bold uppercase tracking-widest mb-1 text-neon">Awaiting Verification</div>
              <p className="text-sm text-muted-foreground">
                We've received your UPI payment screenshot{reg.upi_transaction_ref ? <> (UTR: <span className="font-mono text-foreground">{reg.upi_transaction_ref}</span>)</> : ""}.
                Organizers will verify within 24 hours.
              </p>
              <button onClick={onResubmit} className="mt-3 inline-flex items-center gap-2 px-3 py-1.5 rounded-md border border-neon/40 text-neon text-[11px] uppercase tracking-wider font-bold">
                <Upload size={12} /> Re-upload (optional)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Team detail */}
      <div className="grid sm:grid-cols-2 gap-4 text-sm pt-3 border-t border-border">
        <Field label={isSolo ? "Player" : "Captain"} value={reg.captain_name} />
        <Field label="Phone" value={reg.captain_phone} />
        <Field label="Email" value={reg.captain_email} />
        {!isSolo && <Field label="Player 2" value={`${reg.player2_name}${reg.player2_phone ? ` · ${reg.player2_phone}` : ""}`} />}
        {!isSolo && <Field label="Player 3" value={`${reg.player3_name}${reg.player3_phone ? ` · ${reg.player3_phone}` : ""}`} />}
        
        <Field label="Amount" value={reg.amount_paid != null ? `₹${(reg.amount_paid / 100).toLocaleString("en-IN")}` : "—"} />
        {reg.razorpay_payment_id && <Field label="Payment Ref" value={reg.razorpay_payment_id} />}
        <Field label="Submitted" value={formatDateTimeDMY(reg.created_at)} />
      </div>

      {tournament?.venue && (
        <div className="text-xs text-muted-foreground inline-flex items-center gap-1 pt-1">
          <User size={12} className="text-neon" /> Venue: <span className="text-foreground">{tournament.venue}</span>
        </div>
      )}

      {reg.admin_notes && (
        <div className="p-4 rounded-lg border border-neon/30 bg-neon/5 text-sm">
          <div className="text-xs uppercase tracking-widest text-neon font-bold mb-1">Note from Organizers</div>
          <div>{reg.admin_notes}</div>
        </div>
      )}
    </div>
  );
}

function DateCard({ kind, label, date, venue }: { kind: "qualification" | "finals"; label: string; date: string; venue?: string | null }) {
  const d = new Date(date);
  const now = Date.now();
  const ms = d.getTime() - now;
  const past = ms < 0;
  const days = Math.floor(Math.abs(ms) / 86400000);
  const Icon = kind === "finals" ? Crown : Calendar;
  const accent = kind === "finals" ? "from-gold/20 to-amber-400/5 border-gold/40 text-gold" : "from-neon/20 to-primary/5 border-neon/40 text-neon";
  const dateStr = formatDateDMY(d);
  const timeStr = d.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" });
  return (
    <div className={`rounded-xl border bg-gradient-to-br ${accent} p-4 shadow-glow`}>
      <div className="flex items-center gap-2 mb-2">
        <Icon size={16} />
        <span className="text-[10px] uppercase tracking-widest font-bold">{label}</span>
      </div>
      <div className="font-display text-xl text-foreground">{dateStr}</div>
      <div className="text-xs text-muted-foreground mt-0.5">{timeStr}</div>
      <div className="mt-2 text-[11px] uppercase tracking-wider font-bold">
        {past ? `${days}d ago` : days === 0 ? "Today" : `In ${days} day${days === 1 ? "" : "s"}`}
      </div>
      {venue && <div className="text-[11px] text-muted-foreground mt-1 truncate">@ {venue}</div>}
    </div>
  );
}

function WinnerBanner({ winner }: { winner: Winner }) {
  const isFirst = winner.place === 1;
  const isPodium = winner.place <= 3;
  const medal = winner.place === 1 ? "🥇" : winner.place === 2 ? "🥈" : winner.place === 3 ? "🥉" : "🏆";
  const accent = isFirst
    ? "from-amber-300/30 via-yellow-400/20 to-amber-500/30 border-amber-300"
    : winner.place === 2
    ? "from-slate-200/20 via-slate-300/10 to-slate-400/20 border-slate-300"
    : winner.place === 3
    ? "from-amber-700/20 via-amber-600/10 to-amber-800/20 border-amber-600"
    : "from-neon/20 to-primary/10 border-neon/40";
  return (
    <div className={`relative overflow-hidden rounded-xl border-2 bg-gradient-to-r ${accent} p-5 shadow-neon`}>
      {isPodium && (
        <div className="absolute -top-6 -right-6 text-7xl opacity-20 select-none">{medal}</div>
      )}
      <div className="flex items-center gap-4 relative">
        <div className="text-5xl drop-shadow-lg">{medal}</div>
        <div className="flex-1 min-w-0">
          <div className="text-[10px] uppercase tracking-widest font-bold text-foreground/70">Tournament Result</div>
          <div className="font-display text-2xl sm:text-3xl text-foreground">
            {winner.place_label || `${winner.place}${ordinalSuffix(winner.place)} Place`}
          </div>
          {winner.prize_title && (
            <div className="text-sm text-foreground/80 mt-1">
              <Crown size={12} className="inline mr-1" />
              {winner.prize_title}
              {winner.prize_amount != null && <> · <span className="font-bold">₹{winner.prize_amount.toLocaleString("en-IN")}</span></>}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function ordinalSuffix(n: number) {
  const s = ["th", "st", "nd", "rd"];
  const v = n % 100;
  return s[(v - 20) % 10] || s[v] || s[0];
}

function ResubmitProofModal({ reg, onClose, onSaved }: { reg: Registration; onClose: () => void; onSaved: () => Promise<void> }) {
  const [file, setFile] = useState<File | null>(null);
  const [utr, setUtr] = useState(reg.upi_transaction_ref ?? "");
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (!file) return toast.error("Please choose a screenshot file.");
    setBusy(true);
    try {
      const { data: userData } = await supabase.auth.getUser();
      const uid = userData.user?.id;
      if (!uid) {
        toast.error("Please log in again.");
        return;
      }
      const ext = file.name.split(".").pop() || "png";
      // RLS requires first folder = auth.uid()
      const path = `${uid}/${reg.id}-${Date.now()}.${ext}`;
      const { error: upErr } = await supabase.storage.from("payment-proofs").upload(path, file, { upsert: true, contentType: file.type });
      if (upErr) throw upErr;
      const proofUrl = `payment-proofs/${path}`;
      await resubmitPaymentProof({ data: { registrationId: reg.id, paymentProofUrl: proofUrl, upiTransactionRef: utr || null } });
      toast.success("Proof re-submitted ✓");
      await onSaved();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Upload failed");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur" onClick={onClose}>
      <div className="w-full max-w-md rounded-2xl border border-border bg-card p-6 shadow-glow" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display text-xl text-neon">Re-upload Payment Proof</h3>
          <button onClick={onClose} className="p-2 hover:bg-accent rounded"><X size={16} /></button>
        </div>
        <p className="text-xs text-muted-foreground mb-4">Upload a clear screenshot of your UPI payment confirmation.</p>
        <div className="space-y-3">
          <div>
            <label className="block text-[10px] uppercase tracking-widest text-muted-foreground mb-1">UTR / Transaction ID</label>
            <input value={utr} onChange={(e) => setUtr(e.target.value)} className="w-full px-3 py-2 rounded-md bg-input/60 border border-border text-sm focus:border-neon focus:outline-none" />
          </div>
          <div>
            <label className="block text-[10px] uppercase tracking-widest text-muted-foreground mb-1">Screenshot</label>
            <input type="file" accept="image/*" onChange={(e) => setFile(e.target.files?.[0] ?? null)} className="w-full text-sm" />
          </div>
        </div>
        <div className="mt-5 flex justify-end gap-2">
          <button onClick={onClose} className="px-4 py-2 rounded-md border border-border text-xs uppercase tracking-wider font-bold">Cancel</button>
          <button onClick={submit} disabled={busy} className="inline-flex items-center gap-2 px-4 py-2 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground text-xs uppercase tracking-wider font-bold disabled:opacity-50">
            {busy && <Loader2 size={14} className="animate-spin" />}
            <Upload size={14} /> Submit
          </button>
        </div>
      </div>
    </div>
  );
}

function EditTeamModal({ reg, tournament, onClose, onSaved }: { reg: Registration; tournament?: TournamentInfo; onClose: () => void; onSaved: () => Promise<void> }) {
  const isSolo = tournament?.tournament_type === "solo" || (tournament?.team_size ?? 3) <= 1;
  const [form, setForm] = useState({
    team_name: reg.team_name,
    captain_name: reg.captain_name,
    captain_phone: reg.captain_phone,
    player2_name: reg.player2_name,
    player2_phone: reg.player2_phone ?? "",
    player3_name: reg.player3_name,
    player3_phone: reg.player3_phone ?? "",
  });
  const [saving, setSaving] = useState(false);

  const save = async () => {
    if (!form.team_name.trim() || !form.captain_name.trim()) {
      toast.error((isSolo ? "Player" : "Team") + " name and captain are required.");
      return;
    }
    setSaving(true);
    const payload = isSolo
      ? {
          team_name: form.team_name.trim(),
          captain_name: form.captain_name.trim(),
          captain_phone: form.captain_phone.trim(),
        }
      : {
          team_name: form.team_name.trim(),
          captain_name: form.captain_name.trim(),
          captain_phone: form.captain_phone.trim(),
          player2_name: form.player2_name.trim(),
          player2_phone: form.player2_phone.trim() || null,
          player3_name: form.player3_name.trim(),
          player3_phone: form.player3_phone.trim() || null,
        };
    const { error } = await supabase
      .from("registrations")
      .update(payload)
      .eq("id", reg.id);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success((isSolo ? "Player" : "Team") + " details updated");
    await onSaved();
  };

  const inputCls = "w-full px-3 py-2 rounded-md bg-input/60 border border-border text-sm focus:border-neon focus:outline-none";
  const labelCls = "block text-[10px] uppercase tracking-widest text-muted-foreground mb-1";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur" onClick={onClose}>
      <div className="w-full max-w-2xl rounded-2xl border border-border bg-card p-6 shadow-glow max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display text-xl text-neon">Edit {isSolo ? "Player" : "Team"} Details</h3>
          <button onClick={onClose} className="p-2 hover:bg-accent rounded"><X size={16} /></button>
        </div>
        <p className="text-xs text-muted-foreground mb-4">Email and payment details are locked. Changes are allowed until your payment is verified.</p>
        <div className="grid sm:grid-cols-2 gap-3">
          <div><label className={labelCls}>{isSolo ? "Entry Name" : "Team Name"}</label><input className={inputCls} value={form.team_name} onChange={(e) => setForm({ ...form, team_name: e.target.value })} /></div>
          <div></div>
          <div><label className={labelCls}>{isSolo ? "Player Name" : "Captain"}</label><input className={inputCls} value={form.captain_name} onChange={(e) => setForm({ ...form, captain_name: e.target.value })} /></div>
          <div><label className={labelCls}>Phone</label><input className={inputCls} value={form.captain_phone} onChange={(e) => setForm({ ...form, captain_phone: e.target.value })} /></div>
          {!isSolo && (
            <>
              <div><label className={labelCls}>Player 2 Name</label><input className={inputCls} value={form.player2_name} onChange={(e) => setForm({ ...form, player2_name: e.target.value })} /></div>
              <div><label className={labelCls}>Player 2 Phone</label><input className={inputCls} value={form.player2_phone} onChange={(e) => setForm({ ...form, player2_phone: e.target.value })} /></div>
              <div><label className={labelCls}>Player 3 Name</label><input className={inputCls} value={form.player3_name} onChange={(e) => setForm({ ...form, player3_name: e.target.value })} /></div>
              <div><label className={labelCls}>Player 3 Phone</label><input className={inputCls} value={form.player3_phone} onChange={(e) => setForm({ ...form, player3_phone: e.target.value })} /></div>
            </>
          )}
        </div>
        <div className="mt-5 flex justify-end gap-2">
          <button onClick={onClose} className="px-4 py-2 rounded-md border border-border text-xs uppercase tracking-wider font-bold">Cancel</button>
          <button onClick={save} disabled={saving} className="inline-flex items-center gap-2 px-4 py-2 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground text-xs uppercase tracking-wider font-bold disabled:opacity-50">
            {saving && <Loader2 size={14} className="animate-spin" />}
            <Save size={14} /> Save Changes
          </button>
        </div>
      </div>
    </div>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-[10px] uppercase tracking-widest text-muted-foreground mb-1">{label}</div>
      <div className="font-medium break-words">{value}</div>
    </div>
  );
}
