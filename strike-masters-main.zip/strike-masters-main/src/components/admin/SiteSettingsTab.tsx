import { useEffect, useState } from "react";
import { Loader2, Save } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface SiteSettings {
  id: number;
  copyright_text: string;
  instagram_url: string;
}

const inputCls = "w-full px-3 py-2 rounded-md bg-input/60 border border-border text-sm focus:border-neon focus:outline-none";
const labelCls = "block text-[10px] uppercase tracking-widest text-muted-foreground mb-1";

export function SiteSettingsTab() {
  const [data, setData] = useState<SiteSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (async () => {
      const { data: row } = await (supabase as any).from("site_settings").select("*").eq("id", 1).maybeSingle();
      setData(row as SiteSettings | null);
      setLoading(false);
    })();
  }, []);

  if (loading || !data) {
    return <div className="text-center py-12"><Loader2 className="w-6 h-6 mx-auto animate-spin text-neon" /></div>;
  }

  const save = async () => {
    setSaving(true);
    const { error } = await (supabase as any)
      .from("site_settings")
      .update({ copyright_text: data.copyright_text, instagram_url: data.instagram_url })
      .eq("id", 1);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Footer updated");
  };

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-border bg-card/40 p-6 space-y-4">
        <h3 className="font-display text-lg text-neon">Footer Settings</h3>
        <div>
          <label className={labelCls}>Instagram URL</label>
          <input
            className={inputCls}
            value={data.instagram_url}
            onChange={(e) => setData({ ...data, instagram_url: e.target.value })}
            placeholder="https://instagram.com/yourhandle"
          />
        </div>
        <div>
          <label className={labelCls}>Copyright Text</label>
          <textarea
            rows={2}
            className={inputCls}
            value={data.copyright_text}
            onChange={(e) => setData({ ...data, copyright_text: e.target.value })}
          />
        </div>
      </div>

      <div className="flex justify-end">
        <button
          onClick={save}
          disabled={saving}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground text-xs uppercase tracking-wider font-bold shadow-neon disabled:opacity-50"
        >
          {saving ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />}
          Save Footer
        </button>
      </div>
    </div>
  );
}
