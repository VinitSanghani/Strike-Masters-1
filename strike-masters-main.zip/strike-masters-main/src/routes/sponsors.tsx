import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Star, MapPin, Phone, Trophy, Handshake, ExternalLink, Loader2 } from "lucide-react";
import { SectionHeader } from "@/components/SectionHeader";
import { supabase } from "@/integrations/supabase/client";
import lanex from "@/assets/lanex-logo.png";

export const Route = createFileRoute("/sponsors")({
  head: () => ({
    meta: [
      { title: "Sponsors & Partners — Strike Masters Tournament 2026" },
      { name: "description", content: "Meet the official sponsors and partners powering Strike Masters 2026." },
      { property: "og:title", content: "Strike Masters 2026 — Sponsors & Partners" },
      { property: "og:description", content: "Our official sponsors and partners for Strike Masters 2026." },
    ],
  }),
  component: SponsorsPage,
});

interface Sponsor {
  id: string;
  name: string;
  category: string;
  description: string | null;
  website_url: string | null;
  logo_url: string | null;
  sort_order: number;
}

interface PageContent {
  eyebrow: string;
  title: string;
  description: string;
  featured_enabled: boolean;
  featured_badge: string;
  featured_name: string;
  featured_description: string;
  featured_logo_url: string | null;
  feature_1_label: string;
  feature_2_label: string;
  feature_3_label: string;
  cta_title: string;
  cta_description: string;
  cta_button_label: string;
  cta_button_email: string;
}

function SponsorsPage() {
  const [sponsors, setSponsors] = useState<Sponsor[]>([]);
  const [content, setContent] = useState<PageContent | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const [{ data: sList }, { data: page }] = await Promise.all([
        supabase
          .from("sponsors")
          .select("id, name, category, description, website_url, logo_url, sort_order")
          .eq("active", true)
          .order("sort_order", { ascending: true })
          .order("created_at", { ascending: true }),
        supabase.from("sponsors_page").select("*").eq("id", 1).maybeSingle(),
      ]);
      setSponsors((sList ?? []) as Sponsor[]);
      setContent(page as PageContent | null);
      setLoading(false);
    })();
  }, []);

  const others = sponsors;

  return (
    <div className="container mx-auto px-4 sm:px-6 py-14 sm:py-20">
      <SectionHeader
        eyebrow={content?.eyebrow ?? "Our Partners"}
        title={content?.title ?? "Powering The Tournament"}
        description={content?.description ?? "Strike Masters 2026 is brought to life with our official partners. Meet the team making the event possible."}
      />

      {loading ? (
        <div className="text-center py-12"><Loader2 className="w-6 h-6 mx-auto animate-spin text-neon" /></div>
      ) : (
        <>
          {/* Featured Venue Partner — editable via admin */}
          {content?.featured_enabled !== false && (
            <div className="max-w-5xl mx-auto mb-16">
              <div className="relative rounded-2xl border border-gold/40 bg-gradient-to-br from-card via-card/60 to-gold/10 p-8 sm:p-12 shadow-glow overflow-hidden">
                <div className="absolute -top-20 -right-20 w-64 h-64 rounded-full bg-gold/10 blur-3xl" />
                <div className="relative grid md:grid-cols-[auto,1fr] gap-8 items-center">
                  <div className="rounded-xl bg-background/60 border border-border p-6 flex items-center justify-center">
                    <img
                      src={content?.featured_logo_url || lanex}
                      alt={content?.featured_name ?? "Venue Partner"}
                      className="h-32 sm:h-40 w-auto object-contain"
                    />
                  </div>
                  <div>
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-gold/50 bg-gold/10 text-gold text-xs font-bold uppercase tracking-widest mb-4">
                      <Star size={12} /> {content?.featured_badge ?? "Official Venue Partner"}
                    </div>
                    <h3 className="font-display text-3xl sm:text-4xl mb-3">{content?.featured_name ?? "LaneX Bowling Alley"}</h3>
                    <p className="text-muted-foreground mb-5">
                      {content?.featured_description ?? "LaneX Bowling Alley is the official home of Strike Masters 2026."}
                    </p>
                    <div className="grid sm:grid-cols-3 gap-3 text-sm">
                      {content?.feature_1_label && (
                        <div className="flex items-center gap-2 text-muted-foreground"><Trophy size={14} className="text-gold" /> {content.feature_1_label}</div>
                      )}
                      {content?.feature_2_label && (
                        <div className="flex items-center gap-2 text-muted-foreground"><MapPin size={14} className="text-gold" /> {content.feature_2_label}</div>
                      )}
                      {content?.feature_3_label && (
                        <div className="flex items-center gap-2 text-muted-foreground"><Phone size={14} className="text-gold" /> {content.feature_3_label}</div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Other sponsors grid */}
          {others.length > 0 && (
            <div className="max-w-6xl mx-auto mb-16">
              <h3 className="font-display text-xl text-neon mb-5 text-center">Our Sponsors &amp; Partners</h3>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
                {others.map((s) => (
                  <div key={s.id} className="rounded-2xl border border-border bg-card/60 shadow-glow overflow-hidden flex flex-col">
                    <div className="aspect-[16/9] bg-background/60 border-b border-border flex items-center justify-center p-6">
                      {s.logo_url ? (
                        <img src={s.logo_url} alt={s.name} className="max-h-full max-w-full object-contain" loading="lazy" />
                      ) : (
                        <div className="font-display text-xl text-muted-foreground">{s.name}</div>
                      )}
                    </div>
                    <div className="p-5 flex-1 flex flex-col">
                      <div className="text-[10px] uppercase tracking-widest text-neon font-bold mb-1">{s.category}</div>
                      <h4 className="font-display text-lg mb-2">{s.name}</h4>
                      {s.description && <p className="text-xs text-muted-foreground line-clamp-3 mb-3 flex-1">{s.description}</p>}
                      {s.website_url && (
                        <a
                          href={s.website_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-xs text-neon hover:underline inline-flex items-center gap-1 mt-auto"
                        >
                          Visit <ExternalLink size={11} />
                        </a>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      )}

      {/* Become a partner CTA — editable */}
      <div className="max-w-3xl mx-auto rounded-2xl border border-neon/30 bg-card/50 p-8 sm:p-10 text-center shadow-glow">
        <div className="w-14 h-14 mx-auto mb-4 rounded-full bg-gradient-to-br from-neon to-primary flex items-center justify-center">
          <Handshake className="text-neon-foreground" size={26} />
        </div>
        <h3 className="font-display text-2xl sm:text-3xl mb-3">{content?.cta_title ?? "Partner With Strike Masters"}</h3>
        <p className="text-sm text-muted-foreground mb-6 max-w-xl mx-auto">
          {content?.cta_description ?? "Sponsorship opportunities are open."}
        </p>
        <a
          href={`mailto:${content?.cta_button_email ?? "strikemasters.in@gmail.com"}?subject=Sponsorship%20Enquiry%20—%20Strike%20Masters%202026`}
          className="inline-flex items-center gap-2 px-6 py-3 rounded-md border border-neon text-neon font-bold uppercase tracking-wider text-sm hover:bg-neon/10 transition-colors"
        >
          {content?.cta_button_label ?? "Become a Sponsor"}
        </a>
      </div>
    </div>
  );
}
