import { Outlet, createRootRoute, HeadContent, Scripts, Link } from "@tanstack/react-router";
import { Header } from "../components/Header";
import { Footer } from "../components/Footer";
import { AuthProvider } from "@/hooks/use-auth";
import { Toaster } from "@/components/ui/sonner";

import appCss from "../styles.css?url";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-display text-gradient-neon">404</h1>
        <h2 className="mt-4 text-xl font-display tracking-wider">Lane Not Found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          Looks like this lane is closed. Let's get you back to the action.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-gradient-to-r from-neon to-primary px-6 py-3 text-sm font-bold uppercase tracking-wider text-neon-foreground shadow-neon"
          >
            Back to Home
          </Link>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Strike Masters - Bowling Tournament Organizers in Surat" },
      {
        name: "description",
        content:
          "Join Strike Masters 2026 — the most electrifying bowling tournament. Register your team, compete for cash prizes, and become a champion.",
      },
      { name: "author", content: "Strike Masters" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:title", content: "Strike Masters - Bowling Tournament Organizers in Surat" },
      { name: "twitter:title", content: "Strike Masters - Bowling Tournament Organizers in Surat" },
      { name: "description", content: "A high-energy bowling championship where every player can compete, improve, and chase victory." },
      { property: "og:description", content: "A high-energy bowling championship where every player can compete, improve, and chase victory." },
      { name: "twitter:description", content: "A high-energy bowling championship where every player can compete, improve, and chase victory." },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/61e7c5a4-a758-4988-be88-1f8e3b6a2eb2/id-preview-12b590b3--9c1cd5b5-1330-4ce3-9045-b5397cd8d054.lovable.app-1777459044166.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/61e7c5a4-a758-4988-be88-1f8e3b6a2eb2/id-preview-12b590b3--9c1cd5b5-1330-4ce3-9045-b5397cd8d054.lovable.app-1777459044166.png" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Oswald:wght@500;600;700&family=Inter:wght@400;500;600;700&display=swap",
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  return (
    <AuthProvider>
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 pt-16">
          <Outlet />
        </main>
        <Footer />
        <Toaster richColors position="top-center" />
      </div>
    </AuthProvider>
  );
}
