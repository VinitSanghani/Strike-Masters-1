import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SectionHeader } from "@/components/SectionHeader";
import { CheckCircle2, AlertTriangle, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/rules")({
  head: () => ({
    meta: [
      { title: "Rules & Regulations — Strike Masters Bowling Tournament 2026" },
      { name: "description", content: "Official rules, code of conduct, and regulations for the Strike Masters 2026 bowling tournament." },
      { property: "og:title", content: "Rules & Regulations — Strike Masters 2026" },
      { property: "og:description", content: "Everything you need to know before stepping onto the lane." },
    ],
  }),
  component: RulesPage,
});

interface LegalPage {
  eyebrow: string;
  title: string;
  description: string;
  primary_title: string | null;
  primary_items: string[];
  extra_title: string | null;
  extra_items: string[];
  footer_title: string | null;
  footer_body: string | null;
}

function RulesPage() {
  const [c, setC] = useState<LegalPage | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const { data } = await (supabase as any)
        .from("legal_pages")
        .select("eyebrow,title,description,primary_title,primary_items,extra_title,extra_items,footer_title,footer_body")
        .eq("page_key", "rules")
        .maybeSingle();
      if (cancelled) return;
      if (data) {
        setC({
          ...data,
          primary_items: Array.isArray(data.primary_items) ? data.primary_items : [],
          extra_items: Array.isArray(data.extra_items) ? data.extra_items : [],
        } as LegalPage);
      }
      setLoading(false);
    })();
    return () => { cancelled = true; };
  }, []);

  if (loading) {
    return <div className="container mx-auto px-4 py-32 text-center"><Loader2 className="w-8 h-8 mx-auto animate-spin text-neon" /></div>;
  }
  if (!c) {
    return <div className="container mx-auto px-4 py-32 text-center text-sm text-muted-foreground">Rules content not available.</div>;
  }

  return (
    <div className="container mx-auto px-4 sm:px-6 py-14 sm:py-20">
      <SectionHeader eyebrow={c.eyebrow} title={c.title} description={c.description} />

      <div className="grid lg:grid-cols-2 gap-8 max-w-5xl mx-auto">
        {c.primary_items.length > 0 && (
          <div className="rounded-2xl border border-border bg-card/50 p-6 sm:p-8">
            <h3 className="font-display text-2xl mb-5 text-neon">{c.primary_title || "Game Rules"}</h3>
            <ul className="space-y-3">
              {c.primary_items.map((r, i) => (
                <li key={i} className="flex gap-3 text-sm">
                  <CheckCircle2 className="text-neon shrink-0 mt-0.5" size={18} />
                  <span className="text-muted-foreground">{r}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {c.extra_items.length > 0 && (
          <div className="rounded-2xl border border-border bg-card/50 p-6 sm:p-8">
            <h3 className="font-display text-2xl mb-5 text-neon">{c.extra_title || "Code of Conduct"}</h3>
            <ul className="space-y-3">
              {c.extra_items.map((x, i) => (
                <li key={i} className="flex gap-3 text-sm">
                  <AlertTriangle className="text-primary shrink-0 mt-0.5" size={18} />
                  <span className="text-muted-foreground">{x}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {(c.footer_title || c.footer_body) && (
        <div className="mt-12 max-w-3xl mx-auto rounded-xl border border-neon/30 bg-gradient-to-br from-card to-primary/10 p-6 sm:p-8 text-center">
          {c.footer_title && <h3 className="font-display text-xl mb-2 text-gradient-neon">{c.footer_title}</h3>}
          {c.footer_body && <p className="text-sm text-muted-foreground whitespace-pre-line">{c.footer_body}</p>}
        </div>
      )}
    </div>
  );
}
