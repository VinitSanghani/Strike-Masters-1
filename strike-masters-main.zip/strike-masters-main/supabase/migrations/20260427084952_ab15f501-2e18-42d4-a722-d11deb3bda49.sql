-- TOURNAMENTS TABLE
CREATE TABLE public.tournaments (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  subtitle TEXT,
  description TEXT,
  rules TEXT,
  banner_url TEXT,
  venue TEXT,
  qualification_date TIMESTAMPTZ,
  finals_date TIMESTAMPTZ,
  registration_open_date TIMESTAMPTZ,
  registration_close_date TIMESTAMPTZ,
  registration_deadline DATE,
  registration_open BOOLEAN NOT NULL DEFAULT true,
  payment_required BOOLEAN NOT NULL DEFAULT true,
  registration_fee INTEGER NOT NULL DEFAULT 3000,
  early_bird_fee INTEGER,
  early_bird_until DATE,
  prize_pool TEXT NOT NULL DEFAULT 'Prize Pool Scales With Registrations',
  prize_pool_amount INTEGER,
  max_teams INTEGER,
  team_size INTEGER NOT NULL DEFAULT 3,
  finalist_count INTEGER NOT NULL DEFAULT 5,
  lane_batch_size INTEGER DEFAULT 4,
  qualification_format TEXT,
  status TEXT NOT NULL DEFAULT 'draft',
  featured BOOLEAN NOT NULL DEFAULT false,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT tournaments_status_check CHECK (status IN ('draft','upcoming','active','completed','archived'))
);

ALTER TABLE public.tournaments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Tournaments publicly readable"
ON public.tournaments FOR SELECT
USING (status <> 'draft' OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins manage tournaments"
ON public.tournaments FOR ALL
TO authenticated
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER trg_tournaments_updated_at
BEFORE UPDATE ON public.tournaments
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE INDEX idx_tournaments_status ON public.tournaments(status);
CREATE INDEX idx_tournaments_featured ON public.tournaments(featured) WHERE featured = true;

-- Ensure only one featured tournament at a time
CREATE UNIQUE INDEX idx_tournaments_one_featured
ON public.tournaments((TRUE)) WHERE featured = true;

-- TOURNAMENT PRIZES
CREATE TABLE public.tournament_prizes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tournament_id UUID NOT NULL REFERENCES public.tournaments(id) ON DELETE CASCADE,
  rank_label TEXT NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  value TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.tournament_prizes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Prizes publicly readable"
ON public.tournament_prizes FOR SELECT USING (true);

CREATE POLICY "Admins manage prizes"
ON public.tournament_prizes FOR ALL
TO authenticated
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER trg_prizes_updated_at
BEFORE UPDATE ON public.tournament_prizes
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE INDEX idx_prizes_tournament ON public.tournament_prizes(tournament_id);

-- TOURNAMENT SCHEDULE
CREATE TABLE public.tournament_schedule (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tournament_id UUID NOT NULL REFERENCES public.tournaments(id) ON DELETE CASCADE,
  day_label TEXT NOT NULL,
  time_label TEXT,
  title TEXT NOT NULL,
  description TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.tournament_schedule ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Schedule publicly readable"
ON public.tournament_schedule FOR SELECT USING (true);

CREATE POLICY "Admins manage schedule"
ON public.tournament_schedule FOR ALL
TO authenticated
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER trg_schedule_updated_at
BEFORE UPDATE ON public.tournament_schedule
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE INDEX idx_schedule_tournament ON public.tournament_schedule(tournament_id);

-- TOURNAMENT FAQS
CREATE TABLE public.tournament_faqs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tournament_id UUID REFERENCES public.tournaments(id) ON DELETE CASCADE,
  question TEXT NOT NULL,
  answer TEXT NOT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.tournament_faqs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "FAQs publicly readable"
ON public.tournament_faqs FOR SELECT USING (true);

CREATE POLICY "Admins manage faqs"
ON public.tournament_faqs FOR ALL
TO authenticated
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER trg_faqs_updated_at
BEFORE UPDATE ON public.tournament_faqs
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- GALLERY IMAGES
CREATE TABLE public.gallery_images (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tournament_id UUID REFERENCES public.tournaments(id) ON DELETE SET NULL,
  image_url TEXT NOT NULL,
  caption TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0,
  active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.gallery_images ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Gallery publicly readable"
ON public.gallery_images FOR SELECT
USING (active = true OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins manage gallery"
ON public.gallery_images FOR ALL
TO authenticated
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER trg_gallery_updated_at
BEFORE UPDATE ON public.gallery_images
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- LINK REGISTRATIONS TO TOURNAMENTS (nullable for legacy)
ALTER TABLE public.registrations
ADD COLUMN tournament_id UUID REFERENCES public.tournaments(id) ON DELETE SET NULL;

CREATE INDEX idx_registrations_tournament ON public.registrations(tournament_id);

-- STORAGE BUCKETS for tournament banners and gallery
INSERT INTO storage.buckets (id, name, public)
VALUES ('tournament-banners', 'tournament-banners', true)
ON CONFLICT (id) DO NOTHING;

INSERT INTO storage.buckets (id, name, public)
VALUES ('gallery', 'gallery', true)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "Tournament banners public read"
ON storage.objects FOR SELECT
USING (bucket_id = 'tournament-banners');

CREATE POLICY "Admins upload tournament banners"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'tournament-banners' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins update tournament banners"
ON storage.objects FOR UPDATE
TO authenticated
USING (bucket_id = 'tournament-banners' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins delete tournament banners"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'tournament-banners' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Gallery public read"
ON storage.objects FOR SELECT
USING (bucket_id = 'gallery');

CREATE POLICY "Admins upload gallery"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'gallery' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins update gallery"
ON storage.objects FOR UPDATE
TO authenticated
USING (bucket_id = 'gallery' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins delete gallery"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'gallery' AND public.has_role(auth.uid(), 'admin'));