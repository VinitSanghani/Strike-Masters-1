CREATE TABLE public.tournament_individual_awards (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tournament_id UUID NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  amount INTEGER,
  sort_order INTEGER NOT NULL DEFAULT 0,
  active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.tournament_individual_awards ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Individual awards publicly readable"
ON public.tournament_individual_awards
FOR SELECT
TO public
USING (true);

CREATE POLICY "Admins manage individual awards"
ON public.tournament_individual_awards
FOR ALL
TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role));

CREATE TRIGGER update_tournament_individual_awards_updated_at
BEFORE UPDATE ON public.tournament_individual_awards
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE INDEX idx_tournament_individual_awards_tournament ON public.tournament_individual_awards(tournament_id);