import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

interface SponsorRow {
  id: string;
  name: string;
  logo_url: string | null;
  website_url: string | null;
}

/**
 * Auto-scrolling, drag/swipe-able marquee of all active global sponsors.
 * - Auto-scrolls slowly to the left.
 * - User can grab with mouse or swipe with finger to scroll manually.
 * - Auto-scroll pauses while the user is interacting / hovering.
 * - Loops seamlessly by duplicating items and resetting scroll on wrap.
 */
export function SponsorsMarquee({ eyebrow = "Our Sponsors" }: { eyebrow?: string }) {
  const [items, setItems] = useState<SponsorRow[]>([]);
  const [loaded, setLoaded] = useState(false);

  const scrollerRef = useRef<HTMLDivElement>(null);
  const isInteractingRef = useRef(false);
  const dragStateRef = useRef<{ startX: number; startScroll: number; dragging: boolean; moved: boolean }>({
    startX: 0,
    startScroll: 0,
    dragging: false,
    moved: false,
  });

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const { data } = await supabase
        .from("sponsors")
        .select("id, name, logo_url, website_url")
        .eq("active", true)
        .order("sort_order", { ascending: true })
        .order("created_at", { ascending: true });
      if (cancelled) return;
      setItems((data ?? []) as SponsorRow[]);
      setLoaded(true);
    })();
    return () => { cancelled = true; };
  }, []);

  // Auto-scroll loop using requestAnimationFrame.
  useEffect(() => {
    if (!loaded || items.length === 0) return;
    const el = scrollerRef.current;
    if (!el) return;

    let raf = 0;
    let last = performance.now();
    const SPEED = 40; // px per second

    const tick = (now: number) => {
      const dt = (now - last) / 1000;
      last = now;
      if (!isInteractingRef.current && el.scrollWidth > el.clientWidth) {
        el.scrollLeft += SPEED * dt;
        // Loop: items are duplicated, so the first half == second half.
        const half = el.scrollWidth / 2;
        if (el.scrollLeft >= half) el.scrollLeft -= half;
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [loaded, items.length]);

  if (!loaded || items.length === 0) return null;

  // Duplicate so the marquee animates seamlessly.
  const loop = [...items, ...items];

  const onPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    const el = scrollerRef.current;
    if (!el) return;
    isInteractingRef.current = true;
    dragStateRef.current = {
      startX: e.clientX,
      startScroll: el.scrollLeft,
      dragging: true,
      moved: false,
    };
    el.setPointerCapture(e.pointerId);
  };

  const onPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    const st = dragStateRef.current;
    const el = scrollerRef.current;
    if (!st.dragging || !el) return;
    const dx = e.clientX - st.startX;
    if (Math.abs(dx) > 3) st.moved = true;
    el.scrollLeft = st.startScroll - dx;
    // Keep the seamless loop while dragging too.
    const half = el.scrollWidth / 2;
    if (el.scrollLeft >= half) el.scrollLeft -= half;
    if (el.scrollLeft < 0) el.scrollLeft += half;
  };

  const endDrag = (e: React.PointerEvent<HTMLDivElement>) => {
    const st = dragStateRef.current;
    const el = scrollerRef.current;
    st.dragging = false;
    if (el && el.hasPointerCapture(e.pointerId)) el.releasePointerCapture(e.pointerId);
    // Resume auto-scroll shortly after release.
    setTimeout(() => { isInteractingRef.current = false; }, 600);
  };

  // Suppress link clicks if the user actually dragged.
  const onClickCapture = (e: React.MouseEvent) => {
    if (dragStateRef.current.moved) {
      e.preventDefault();
      e.stopPropagation();
      dragStateRef.current.moved = false;
    }
  };

  return (
    <section className="container mx-auto px-4 sm:px-6 py-10">
      <div className="text-center text-[10px] uppercase tracking-[0.3em] text-muted-foreground mb-4">
        {eyebrow}
      </div>
      <div
        className="relative overflow-hidden rounded-2xl border border-border bg-card/40"
        style={{
          maskImage:
            "linear-gradient(to right, transparent 0, black 6%, black 94%, transparent 100%)",
          WebkitMaskImage:
            "linear-gradient(to right, transparent 0, black 6%, black 94%, transparent 100%)",
        }}
        onMouseEnter={() => { isInteractingRef.current = true; }}
        onMouseLeave={() => { if (!dragStateRef.current.dragging) isInteractingRef.current = false; }}
      >
        <div
          ref={scrollerRef}
          onPointerDown={onPointerDown}
          onPointerMove={onPointerMove}
          onPointerUp={endDrag}
          onPointerCancel={endDrag}
          onClickCapture={onClickCapture}
          className="flex gap-4 sm:gap-6 py-4 sm:py-5 overflow-x-auto cursor-grab active:cursor-grabbing select-none touch-pan-x"
          style={{
            scrollbarWidth: "none",
            msOverflowStyle: "none",
            WebkitOverflowScrolling: "touch",
            overscrollBehaviorX: "contain",
          }}
        >
          {loop.map((s, i) => {
            const inner = (
              <div className="flex items-center justify-center h-full w-full p-3 sm:p-5 bg-background/60">
                {s.logo_url ? (
                  <img
                    src={s.logo_url}
                    alt={s.name}
                    loading="lazy"
                    draggable={false}
                    className="max-h-full max-w-full object-contain pointer-events-none"
                  />
                ) : (
                  <div className="font-display text-sm sm:text-lg text-muted-foreground text-center">
                    {s.name}
                  </div>
                )}
              </div>
            );
            return (
              <div
                key={`${s.id}-${i}`}
                className="shrink-0 rounded-xl border border-border overflow-hidden
                  w-[160px] h-[120px]
                  sm:w-[220px] sm:h-[170px]
                  md:w-[280px] md:h-[220px]"
              >
                {s.website_url ? (
                  <a
                    href={s.website_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block h-full w-full"
                    aria-label={s.name}
                    draggable={false}
                  >
                    {inner}
                  </a>
                ) : (
                  inner
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
