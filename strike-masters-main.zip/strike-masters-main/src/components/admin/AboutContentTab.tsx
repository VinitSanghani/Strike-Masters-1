import { useEffect, useState } from "react";
import { Loader2, Save } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface AboutContent {
  id: number;
  eyebrow: string;
  hero_title: string;
  hero_description: string;
  format_title: string;
  format_intro: string;
  format_bullets: string[];
  scoring_title: string;
  scoring_intro: string;
  scoring_bullets: string[];
  who_title: string;
  eligibility_label: string;
  eligibility_text: string;
  team_label: string;
  team_text: string;
  equipment_label: string;
  equipment_text: string;
}

const inputCls = "w-full px-3 py-2 rounded-md bg-input/60 border border-border text-sm focus:border-neon focus:outline-none";
const labelCls = "block text-[10px] uppercase tracking-widest text-muted-foreground mb-1";

export function AboutContentTab() {
  const [data, setData] = useState<AboutContent | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const refresh = async () => {
    const { data: row } = await (supabase as any).from("about_content").select("*").eq("id", 1).maybeSingle();
    setData(row as AboutContent | null);
    setLoading(false);
  };
  useEffect(() => { refresh(); }, []);

  if (loading || !data) {
    return <div className="text-center py-12"><Loader2 className="w-6 h-6 mx-auto animate-spin text-neon" /></div>;
  }

  const save = async () => {
    setSaving(true);
    const { id, ...payload } = data;
    void id;
    const { error } = await (supabase as any).from("about_content").update(payload).eq("id", 1);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("About page updated");
  };

  const set = <K extends keyof AboutContent>(k: K, v: AboutContent[K]) => setData({ ...data, [k]: v });
  const setBullets = (k: "format_bullets" | "scoring_bullets", text: string) =>
    set(k, text.split("\n").map((s) => s.trim()).filter(Boolean));

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-border bg-card/40 p-6 space-y-4">
        <h3 className="font-display text-lg text-neon">Hero Section</h3>
        <div className="grid sm:grid-cols-2 gap-3">
          <div>
            <label className={labelCls}>Eyebrow (small label above title)</label>
            <input className={inputCls} value={data.eyebrow} onChange={(e) => set("eyebrow", e.target.value)} />
          </div>
          <div>
            <label className={labelCls}>Hero Title (big heading)</label>
            <input className={inputCls} value={data.hero_title} onChange={(e) => set("hero_title", e.target.value)} />
          </div>
        </div>
        <div>
          <label className={labelCls}>Hero Description</label>
          <textarea rows={3} className={inputCls} value={data.hero_description} onChange={(e) => set("hero_description", e.target.value)} />
        </div>
      </div>

      <div className="rounded-2xl border border-border bg-card/40 p-6 space-y-4">
        <h3 className="font-display text-lg text-neon">The Format Card</h3>
        <div>
          <label className={labelCls}>Title</label>
          <input className={inputCls} value={data.format_title} onChange={(e) => set("format_title", e.target.value)} />
        </div>
        <div>
          <label className={labelCls}>Intro paragraph</label>
          <textarea rows={3} className={inputCls} value={data.format_intro} onChange={(e) => set("format_intro", e.target.value)} />
        </div>
        <div>
          <label className={labelCls}>Bullet points (one per line)</label>
          <textarea rows={6} className={inputCls} value={data.format_bullets.join("\n")} onChange={(e) => setBullets("format_bullets", e.target.value)} />
        </div>
      </div>

      <div className="rounded-2xl border border-border bg-card/40 p-6 space-y-4">
        <h3 className="font-display text-lg text-neon">Scoring System Card</h3>
        <div>
          <label className={labelCls}>Title</label>
          <input className={inputCls} value={data.scoring_title} onChange={(e) => set("scoring_title", e.target.value)} />
        </div>
        <div>
          <label className={labelCls}>Intro paragraph</label>
          <textarea rows={3} className={inputCls} value={data.scoring_intro} onChange={(e) => set("scoring_intro", e.target.value)} />
        </div>
        <div>
          <label className={labelCls}>Bullet points (one per line)</label>
          <textarea rows={6} className={inputCls} value={data.scoring_bullets.join("\n")} onChange={(e) => setBullets("scoring_bullets", e.target.value)} />
        </div>
      </div>

      <div className="rounded-2xl border border-border bg-card/40 p-6 space-y-4">
        <h3 className="font-display text-lg text-neon">Who Can Compete Section</h3>
        <div>
          <label className={labelCls}>Section Title</label>
          <input className={inputCls} value={data.who_title} onChange={(e) => set("who_title", e.target.value)} />
        </div>
        <div className="grid sm:grid-cols-3 gap-4 pt-2">
          <div className="space-y-2">
            <label className={labelCls}>Eligibility Label</label>
            <input className={inputCls} value={data.eligibility_label} onChange={(e) => set("eligibility_label", e.target.value)} />
            <label className={labelCls}>Eligibility Text</label>
            <textarea rows={5} className={inputCls} value={data.eligibility_text} onChange={(e) => set("eligibility_text", e.target.value)} />
          </div>
          <div className="space-y-2">
            <label className={labelCls}>Team Label</label>
            <input className={inputCls} value={data.team_label} onChange={(e) => set("team_label", e.target.value)} />
            <label className={labelCls}>Team Text</label>
            <textarea rows={5} className={inputCls} value={data.team_text} onChange={(e) => set("team_text", e.target.value)} />
          </div>
          <div className="space-y-2">
            <label className={labelCls}>Equipment Label</label>
            <input className={inputCls} value={data.equipment_label} onChange={(e) => set("equipment_label", e.target.value)} />
            <label className={labelCls}>Equipment Text</label>
            <textarea rows={5} className={inputCls} value={data.equipment_text} onChange={(e) => set("equipment_text", e.target.value)} />
          </div>
        </div>
      </div>

      <div className="flex justify-end">
        <button
          onClick={save}
          disabled={saving}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground text-xs uppercase tracking-wider font-bold shadow-neon disabled:opacity-50"
        >
          {saving ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />}
          Save About Page
        </button>
      </div>
    </div>
  );
}
