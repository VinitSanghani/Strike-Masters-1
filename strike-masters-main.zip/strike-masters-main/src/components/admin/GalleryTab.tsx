import { useEffect, useState } from "react";
import { Loader2, Plus, Trash2, Edit3, Save, X, Image as ImageIcon, ArrowUp, ArrowDown, Eye, EyeOff, Upload } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface GalleryImage {
  id: string;
  image_url: string;
  caption: string | null;
  tournament_id: string | null;
  sort_order: number;
  active: boolean;
  created_at: string;
}

interface TournamentLite {
  id: string;
  name: string;
}

export function GalleryTab() {
  const [images, setImages] = useState<GalleryImage[]>([]);
  const [tournaments, setTournaments] = useState<TournamentLite[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<GalleryImage | null>(null);
  const [creating, setCreating] = useState(false);
  const [filterTournament, setFilterTournament] = useState<string>("all");

  const refresh = async () => {
    const [imgRes, tRes] = await Promise.all([
      supabase.from("gallery_images").select("*").order("sort_order", { ascending: true }).order("created_at", { ascending: false }),
      supabase.from("tournaments").select("id, name").order("created_at", { ascending: false }),
    ]);
    if (imgRes.error) toast.error(imgRes.error.message);
    setImages((imgRes.data ?? []) as GalleryImage[]);
    setTournaments((tRes.data ?? []) as TournamentLite[]);
    setLoading(false);
  };

  useEffect(() => { refresh(); }, []);

  const tournamentName = (id: string | null) => {
    if (!id) return "General";
    return tournaments.find((t) => t.id === id)?.name ?? "Unknown";
  };

  const remove = async (img: GalleryImage) => {
    if (!confirm("Delete this image permanently?")) return;
    const path = extractStoragePath(img.image_url);
    if (path) await supabase.storage.from("gallery").remove([path]);
    const { error } = await supabase.from("gallery_images").delete().eq("id", img.id);
    if (error) return toast.error(error.message);
    toast.success("Image deleted");
    await refresh();
  };

  const toggleActive = async (img: GalleryImage) => {
    const { error } = await supabase.from("gallery_images").update({ active: !img.active }).eq("id", img.id);
    if (error) return toast.error(error.message);
    await refresh();
  };

  const move = async (img: GalleryImage, dir: -1 | 1) => {
    const list = filtered;
    const idx = list.findIndex((x) => x.id === img.id);
    const swap = list[idx + dir];
    if (!swap) return;
    if (img.sort_order === swap.sort_order) {
      for (let i = 0; i < list.length; i++) {
        await supabase.from("gallery_images").update({ sort_order: i * 10 }).eq("id", list[i].id);
      }
      await refresh();
      return;
    }
    await Promise.all([
      supabase.from("gallery_images").update({ sort_order: swap.sort_order }).eq("id", img.id),
      supabase.from("gallery_images").update({ sort_order: img.sort_order }).eq("id", swap.id),
    ]);
    await refresh();
  };

  const filtered = images.filter((i) => {
    if (filterTournament === "all") return true;
    if (filterTournament === "general") return !i.tournament_id;
    return i.tournament_id === filterTournament;
  });

  if (loading) {
    return <div className="text-center py-12"><Loader2 className="w-6 h-6 mx-auto animate-spin text-neon" /></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h3 className="font-display text-xl text-neon">Gallery</h3>
          <p className="text-xs text-muted-foreground mt-1">Upload tournament photos. Tag images to a tournament or leave as general gallery.</p>
        </div>
        <div className="flex gap-2 items-center">
          <select
            value={filterTournament}
            onChange={(e) => setFilterTournament(e.target.value)}
            className="px-3 py-2 rounded-md bg-input/60 border border-border text-xs focus:border-neon focus:outline-none"
          >
            <option value="all">All images</option>
            <option value="general">General (untagged)</option>
            {tournaments.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
          </select>
          <button
            onClick={() => setCreating(true)}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground text-xs uppercase tracking-wider font-bold shadow-neon"
          >
            <Plus size={14} /> Upload Image
          </button>
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border bg-card/40 p-10 text-center">
          <ImageIcon className="w-10 h-10 mx-auto text-muted-foreground mb-2" />
          <p className="text-sm text-muted-foreground">No images yet. Click "Upload Image" to add the first one.</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((img, i) => (
            <div key={img.id} className={`rounded-xl border bg-card/60 shadow-glow overflow-hidden ${img.active ? "border-border" : "border-border/40 opacity-60"}`}>
              <div className="aspect-[4/3] bg-background/60 overflow-hidden">
                <img src={img.image_url} alt={img.caption ?? "Gallery image"} className="w-full h-full object-cover" loading="lazy" />
              </div>
              <div className="p-3">
                <div className="flex items-start justify-between gap-2 mb-1">
                  <p className="text-sm font-medium line-clamp-2 flex-1">{img.caption || <span className="text-muted-foreground italic">No caption</span>}</p>
                </div>
                <span className="text-[10px] uppercase tracking-widest text-neon font-bold border border-neon/40 rounded px-2 py-0.5 inline-block">
                  {tournamentName(img.tournament_id)}
                </span>
                <div className="mt-3 pt-3 border-t border-border flex items-center justify-between gap-2">
                  <div className="flex gap-1">
                    <button onClick={() => move(img, -1)} disabled={i === 0} className="p-1.5 rounded text-muted-foreground hover:text-neon hover:bg-neon/10 disabled:opacity-30" title="Move up">
                      <ArrowUp size={14} />
                    </button>
                    <button onClick={() => move(img, 1)} disabled={i === filtered.length - 1} className="p-1.5 rounded text-muted-foreground hover:text-neon hover:bg-neon/10 disabled:opacity-30" title="Move down">
                      <ArrowDown size={14} />
                    </button>
                  </div>
                  <div className="flex gap-1">
                    <button onClick={() => toggleActive(img)} className="p-1.5 rounded text-muted-foreground hover:text-neon hover:bg-neon/10" title={img.active ? "Hide" : "Show"}>
                      {img.active ? <Eye size={14} /> : <EyeOff size={14} />}
                    </button>
                    <button onClick={() => setEditing(img)} className="p-1.5 rounded text-neon hover:bg-neon/10" title="Edit">
                      <Edit3 size={14} />
                    </button>
                    <button onClick={() => remove(img)} className="p-1.5 rounded text-destructive hover:bg-destructive/10" title="Delete">
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {(creating || editing) && (
        <GalleryModal
          image={editing}
          tournaments={tournaments}
          nextSortOrder={images.length * 10}
          onClose={() => { setCreating(false); setEditing(null); }}
          onSaved={async () => { setCreating(false); setEditing(null); await refresh(); }}
        />
      )}
    </div>
  );
}

function extractStoragePath(publicUrl: string): string | null {
  const m = publicUrl.match(/\/object\/public\/gallery\/(.+)$/);
  return m ? decodeURIComponent(m[1]) : null;
}

function GalleryModal({
  image,
  tournaments,
  nextSortOrder,
  onClose,
  onSaved,
}: {
  image: GalleryImage | null;
  tournaments: TournamentLite[];
  nextSortOrder: number;
  onClose: () => void;
  onSaved: () => Promise<void>;
}) {
  const [form, setForm] = useState({
    caption: image?.caption ?? "",
    tournament_id: image?.tournament_id ?? "",
    active: image?.active ?? true,
    sort_order: image?.sort_order ?? nextSortOrder,
  });
  const [imageUrl, setImageUrl] = useState<string | null>(image?.image_url ?? null);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);

  const onFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 8_000_000) {
      toast.error("Image must be smaller than 8 MB");
      return;
    }
    setUploading(true);
    const ext = file.name.split(".").pop()?.toLowerCase() || "jpg";
    const path = `${crypto.randomUUID()}.${ext}`;
    const { error: upErr } = await supabase.storage.from("gallery").upload(path, file, {
      cacheControl: "3600",
      upsert: false,
      contentType: file.type,
    });
    setUploading(false);
    if (upErr) {
      toast.error(upErr.message);
      return;
    }
    const { data } = supabase.storage.from("gallery").getPublicUrl(path);
    setImageUrl(data.publicUrl);
    toast.success("Image uploaded");
  };

  const save = async () => {
    if (!imageUrl) {
      toast.error("Please upload an image first");
      return;
    }
    setSaving(true);
    const payload = {
      image_url: imageUrl,
      caption: form.caption.trim() || null,
      tournament_id: form.tournament_id || null,
      active: form.active,
      sort_order: form.sort_order,
    };
    const { error } = image
      ? await supabase.from("gallery_images").update(payload).eq("id", image.id)
      : await supabase.from("gallery_images").insert(payload);
    setSaving(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(image ? "Image updated" : "Image added");
    await onSaved();
  };

  const inputCls = "w-full px-3 py-2 rounded-md bg-input/60 border border-border text-sm focus:border-neon focus:outline-none";
  const labelCls = "block text-[10px] uppercase tracking-widest text-muted-foreground mb-1";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur" onClick={onClose}>
      <div className="w-full max-w-2xl rounded-2xl border border-border bg-card p-6 shadow-glow max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display text-xl text-neon">{image ? "Edit Image" : "Upload Image"}</h3>
          <button onClick={onClose} className="p-2 hover:bg-accent rounded"><X size={16} /></button>
        </div>

        <div className="mb-4">
          <label className={labelCls}>Image *</label>
          <div className="flex items-start gap-4">
            <div className="w-40 h-40 rounded-md border border-border bg-background/60 flex items-center justify-center overflow-hidden shrink-0">
              {imageUrl ? (
                <img src={imageUrl} alt="Preview" className="w-full h-full object-cover" />
              ) : (
                <Upload className="w-8 h-8 text-muted-foreground" />
              )}
            </div>
            <div className="flex-1">
              <input
                type="file"
                accept="image/png,image/jpeg,image/webp"
                onChange={onFileChange}
                disabled={uploading}
                className="block w-full text-xs file:mr-3 file:py-2 file:px-4 file:rounded-md file:border-0 file:bg-neon file:text-neon-foreground file:font-bold file:text-xs file:uppercase file:tracking-wider file:cursor-pointer"
              />
              <p className="text-[11px] text-muted-foreground mt-2">PNG, JPG, or WEBP. Max 8 MB.</p>
              {uploading && <p className="text-xs text-neon mt-1 inline-flex items-center gap-1"><Loader2 size={12} className="animate-spin" /> Uploading…</p>}
            </div>
          </div>
        </div>

        <div className="grid sm:grid-cols-2 gap-3">
          <div className="sm:col-span-2">
            <label className={labelCls}>Caption</label>
            <input className={inputCls} value={form.caption} onChange={(e) => setForm({ ...form, caption: e.target.value })} placeholder="e.g. Finals night strike" />
          </div>
          <div>
            <label className={labelCls}>Tournament</label>
            <select className={inputCls} value={form.tournament_id} onChange={(e) => setForm({ ...form, tournament_id: e.target.value })}>
              <option value="">General (no tournament)</option>
              {tournaments.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
            </select>
          </div>
          <div>
            <label className={labelCls}>Sort Order</label>
            <input type="number" className={inputCls} value={form.sort_order} onChange={(e) => setForm({ ...form, sort_order: parseInt(e.target.value) || 0 })} />
          </div>
          <label className="flex items-center gap-2 text-sm mt-2 sm:col-span-2">
            <input type="checkbox" checked={form.active} onChange={(e) => setForm({ ...form, active: e.target.checked })} />
            Active (visible on public gallery)
          </label>
        </div>

        <div className="mt-5 flex justify-end gap-2">
          <button onClick={onClose} className="px-4 py-2 rounded-md border border-border text-xs uppercase tracking-wider font-bold">Cancel</button>
          <button onClick={save} disabled={saving || uploading} className="inline-flex items-center gap-2 px-4 py-2 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground text-xs uppercase tracking-wider font-bold disabled:opacity-50">
            {saving && <Loader2 size={14} className="animate-spin" />}
            <Save size={14} /> {image ? "Save Changes" : "Add Image"}
          </button>
        </div>
      </div>
    </div>
  );
}
