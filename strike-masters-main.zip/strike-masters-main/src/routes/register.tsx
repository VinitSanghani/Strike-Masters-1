import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { z } from "zod";
import {
  CheckCircle2, AlertCircle, Users, Calendar, Loader2, Lock, Trophy,
  Banknote, Smartphone, Upload, Image as ImageIcon, X,
} from "lucide-react";
import { SectionHeader } from "@/components/SectionHeader";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { toast } from "sonner";
import { formatDateDMY } from "@/lib/format-date";
import { getRegistrationWindowState, registrationWindowMessage } from "@/lib/registration-window";
import {
  createManualRegistration,
  checkRegistrationEligibility,
} from "@/server/razorpay.functions";

interface RegisterSearch {
  t?: string;
}

export const Route = createFileRoute("/register")({
  validateSearch: (search: Record<string, unknown>): RegisterSearch => ({
    t: typeof search.t === "string" ? search.t : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Register — Strike Masters Bowling Tournament" },
      { name: "description", content: "Register your team for Strike Masters bowling tournaments. Pay via UPI or cash at the venue." },
      { property: "og:title", content: "Register for Strike Masters" },
      { property: "og:description", content: "Lock in your team. UPI / QR or Cash payment supported." },
    ],
  }),
  component: RegisterPage,
});

interface ResolvedTournament {
  id: string;
  slug: string;
  name: string;
  registration_open: boolean;
  registration_open_date: string | null;
  registration_close_date: string | null;
  registration_fee: number;
  status: string;
  qualification_date: string | null;
  finals_date: string | null;
  max_teams: number | null;
  team_size: number;
  tournament_type: "solo" | "team";
  payment_methods: string[];
  upi_qr_url: string | null;
  upi_id: string | null;
  payment_instructions: string | null;
  cash_payment_deadline: string | null;
}

type PaymentMethod = "cash" | "upi_qr";

function buildSchema(teamSize: number, requirePassword: boolean) {
  // Captain (player 1) always required. Other players required up to teamSize.
  const playerName = (i: number) =>
    i + 1 <= teamSize
      ? z.string().trim().min(2, `Player ${i + 1} name is required`).max(80)
      : z.string().trim().max(80).optional().or(z.literal(""));
  const playerPhone = z.string().trim().max(20).optional().or(z.literal(""));

  return z.object({
    teamName: z.string().trim().min(2, "Team / entry name is required").max(80),
    captainName: z.string().trim().min(2, "Captain name is required").max(80),
    email: z.string().trim().email("Invalid email address").max(255),
    password: requirePassword
      ? z.string().min(6, "Password must be at least 6 characters").max(100)
      : z.string().max(100).optional().or(z.literal("")),
    captainPhone: z.string().trim().min(7, "Enter a valid phone number").max(20),
    player2Name: playerName(1),
    player2Phone: playerPhone,
    player3Name: playerName(2),
    player3Phone: playerPhone,
    player4Name: playerName(3),
    player4Phone: playerPhone,
    player5Name: playerName(4),
    player5Phone: playerPhone,
    paymentMethod: z.enum(["cash", "upi_qr"]),
    upiTransactionRef: z.string().trim().max(80).optional().or(z.literal("")),
  });
}

interface PickerTournament {
  id: string;
  slug: string;
  name: string;
  subtitle: string | null;
  banner_url: string | null;
  qualification_date: string | null;
  finals_date: string | null;
  registration_fee: number;
  team_size: number;
  tournament_type: string;
  registration_open: boolean;
  registration_open_date: string | null;
  registration_close_date: string | null;
  status: string;
}

function RegisterPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { t: slug } = Route.useSearch();
  const [tournament, setTournament] = useState<ResolvedTournament | null>(null);
  const [tLoading, setTLoading] = useState(true);
  const [pickerList, setPickerList] = useState<PickerTournament[]>([]);
  const [submitted, setSubmitted] = useState<{ registrationId: string; method: PaymentMethod } | null>(null);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [proofFile, setProofFile] = useState<File | null>(null);
  const [proofPreview, setProofPreview] = useState<string | null>(null);
  const [uploadingProof, setUploadingProof] = useState(false);

  const [form, setForm] = useState({
    teamName: "", captainName: "", email: "", password: "", captainPhone: "",
    player2Name: "", player2Phone: "",
    player3Name: "", player3Phone: "",
    player4Name: "", player4Phone: "",
    player5Name: "", player5Phone: "",
    paymentMethod: "upi_qr" as PaymentMethod,
    upiTransactionRef: "",
  });

  useEffect(() => {
    const load = async () => {
      setTLoading(true);
      const cols =
        "id, slug, name, registration_open, registration_open_date, registration_close_date, registration_fee, status, qualification_date, finals_date, max_teams, team_size, tournament_type, payment_methods, upi_qr_url, upi_id, payment_instructions, cash_payment_deadline";

      // Only auto-resolve if a specific slug is provided. Otherwise show picker.
      let resolved: ResolvedTournament | null = null;
      if (slug) {
        const { data } = await supabase.from("tournaments").select(cols).eq("slug", slug).maybeSingle();
        resolved = (data as ResolvedTournament) ?? null;
      }

      if (!resolved) {
        // Load picker options (registration-open tournaments only — filter the
        // window client-side so admin-set open/close dates are honored).
        const { data } = await supabase
          .from("tournaments")
          .select("id, slug, name, subtitle, banner_url, qualification_date, finals_date, registration_fee, team_size, tournament_type, registration_open, registration_open_date, registration_close_date, status")
          .in("status", ["upcoming", "active"])
          .eq("registration_open", true)
          .order("qualification_date", { ascending: true, nullsFirst: false });
        const filtered = ((data ?? []) as PickerTournament[]).filter(
          (t) => getRegistrationWindowState(t) === "open",
        );
        setPickerList(filtered);
      }

      setTournament(resolved);
      // Default selected payment method to first enabled
      if (resolved?.payment_methods?.length) {
        const first = resolved.payment_methods.find((m) => m === "upi_qr" || m === "cash") as PaymentMethod | undefined;
        if (first) setForm((f) => ({ ...f, paymentMethod: first }));
      }
      setTLoading(false);
    };
    load();
  }, [slug]);

  // Pre-fill email when logged in, but allow registering for additional tournaments
  useEffect(() => {
    if (user?.email) {
      setForm((f) => ({
        ...f,
        email: f.email || user.email!,
        captainName: f.captainName || (user.user_metadata?.captain_name as string) || "",
      }));
    }
  }, [user]);

  const teamSize = tournament?.team_size ?? 3;
  const isSolo = tournament?.tournament_type === "solo" || teamSize <= 1;
  const fee = tournament?.registration_fee ?? 0;
  const regWindowState = tournament ? getRegistrationWindowState(tournament) : "closed";
  const regOpen = regWindowState === "open";
  const regClosedReason = tournament ? registrationWindowMessage(regWindowState) : "Registration Closed";
  const enabledMethods = useMemo(
    () => (tournament?.payment_methods ?? []).filter((m): m is PaymentMethod => m === "cash" || m === "upi_qr"),
    [tournament],
  );
  const schema = useMemo(() => buildSchema(isSolo ? 1 : teamSize, !user), [isSolo, teamSize, user]);

  const update = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setForm((f) => ({ ...f, [k]: e.target.value }));
  };

  const onProofChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5_000_000) {
      toast.error("Screenshot must be under 5 MB.");
      return;
    }
    if (!/^image\//.test(file.type)) {
      toast.error("Please upload an image (PNG / JPG).");
      return;
    }
    setProofFile(file);
    const reader = new FileReader();
    reader.onload = () => setProofPreview(typeof reader.result === "string" ? reader.result : null);
    reader.readAsDataURL(file);
  };

  const uploadProofIfNeeded = async (): Promise<string | null> => {
    if (form.paymentMethod !== "upi_qr") return null;
    if (!proofFile) {
      toast.error("Please upload a screenshot of your UPI payment.");
      return null;
    }
    setUploadingProof(true);
    const ext = proofFile.name.split(".").pop()?.toLowerCase() || "png";
    // RLS on payment-proofs requires the first folder to be either auth.uid() (logged-in) or "anon" (guest)
    const folder = user?.id ?? "anon";
    const path = `${folder}/${tournament!.slug}-${Date.now()}-${crypto.randomUUID()}.${ext}`;
    const { error: upErr } = await supabase.storage
      .from("payment-proofs")
      .upload(path, proofFile, { cacheControl: "3600", upsert: false, contentType: proofFile.type });
    setUploadingProof(false);
    if (upErr) {
      toast.error("Could not upload screenshot: " + upErr.message);
      return null;
    }
    // We store the storage path with the bucket prefix to make signed-URL extraction easy
    return `payment-proofs/${path}`;
  };

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!tournament) {
      toast.error("No tournament available for registration.");
      return;
    }
    if (!regOpen) {
      toast.error(
        regWindowState === "not_yet_open" && tournament?.registration_open_date
          ? `Registration opens on ${formatDateDMY(tournament.registration_open_date)}.`
          : "Registration is currently closed.",
      );
      return;
    }
    if (enabledMethods.length === 0) {
      toast.error("This tournament has no payment methods configured. Please contact organizers.");
      return;
    }
    if (!enabledMethods.includes(form.paymentMethod)) {
      toast.error(`${form.paymentMethod === "cash" ? "Cash" : "UPI"} payment is not enabled for this tournament.`);
      return;
    }

    const result = schema.safeParse(form);
    if (!result.success) {
      const errs: Record<string, string> = {};
      result.error.issues.forEach((i) => { errs[i.path[0] as string] = i.message; });
      setErrors(errs);
      toast.error("Please fix the errors below.");
      return;
    }
    setErrors({});
    setLoading(true);

    try {
      // Pre-flight duplicate check
      const eligibility = await checkRegistrationEligibility({
        data: { teamName: form.teamName, email: form.email, tournamentSlug: tournament.slug },
      });
      if (!eligibility.ok) {
        toast.error(eligibility.message);
        if (eligibility.reason === "email_already_registered") {
          setTimeout(() => navigate({ to: "/login" }), 2000);
        }
        return;
      }

      let proofUrl: string | null = null;
      if (form.paymentMethod === "upi_qr") {
        proofUrl = await uploadProofIfNeeded();
        if (!proofUrl) return;
      }

      const res = await createManualRegistration({
        data: {
          tournamentSlug: tournament.slug,
          paymentMethod: form.paymentMethod,
          paymentProofUrl: proofUrl,
          upiTransactionRef: form.upiTransactionRef || null,
          registration: {
            teamName: form.teamName,
            captainName: form.captainName,
            captainEmail: form.email,
            captainPhone: form.captainPhone,
            password: form.password || crypto.randomUUID(),
            player2Name: form.player2Name || null,
            player2Phone: form.player2Phone || null,
            player3Name: form.player3Name || null,
            player3Phone: form.player3Phone || null,
            player4Name: form.player4Name || null,
            player4Phone: form.player4Phone || null,
            player5Name: form.player5Name || null,
            player5Phone: form.player5Phone || null,
          },
        },
      });

      setSubmitted({ registrationId: res.registrationId, method: form.paymentMethod });
      if (form.paymentMethod === "cash") {
        toast.success("Registered! Pay cash at the venue before the deadline.");
      } else {
        toast.success("Submitted! Your payment is pending admin verification.");
      }
      // Don't auto-redirect — let the user read the success screen and choose Dashboard / Login.
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  if (tLoading) {
    return (
      <div className="container mx-auto px-4 py-32 text-center">
        <Loader2 className="w-8 h-8 mx-auto animate-spin text-neon" />
      </div>
    );
  }

  if (!tournament) {
    if (pickerList.length === 0) {
      return (
        <div className="container mx-auto px-4 py-32 text-center max-w-md">
          <Trophy className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
          <h1 className="font-display text-2xl mb-2">No Tournament Available</h1>
          <p className="text-sm text-muted-foreground mb-6">There are no tournaments currently accepting registrations.</p>
          <Link to="/tournaments" className="inline-flex items-center gap-2 px-5 py-3 rounded-md border border-border hover:border-neon text-xs uppercase tracking-wider font-bold">
            Browse Tournaments
          </Link>
        </div>
      );
    }
    return (
      <div className="container mx-auto px-4 sm:px-6 py-14 sm:py-20">
        <SectionHeader
          eyebrow="Step 1 of 2"
          title="Select A Tournament"
          description="Choose the tournament you want to register for. You'll fill in your team details next."
        />
        <div className="max-w-3xl mx-auto grid sm:grid-cols-2 gap-5">
          {pickerList.map((p) => (
            <Link
              key={p.id}
              to="/register"
              search={{ t: p.slug }}
              className="group rounded-2xl border border-border bg-card/60 backdrop-blur p-5 hover:border-neon hover:-translate-y-1 transition-all shadow-glow flex flex-col"
            >
              {p.banner_url && (
                <div className="aspect-video rounded-lg overflow-hidden mb-4 bg-background/40">
                  <img src={p.banner_url} alt={p.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                </div>
              )}
              <h3 className="font-display text-lg text-neon mb-1 group-hover:underline">{p.name}</h3>
              {p.subtitle && <p className="text-xs text-muted-foreground line-clamp-2 mb-3">{p.subtitle}</p>}
              <div className="space-y-1.5 text-xs text-muted-foreground mt-auto">
                <div className="flex items-center gap-1.5">
                  <Calendar size={12} className="text-neon" />
                  {p.qualification_date
                    ? formatDateDMY(p.qualification_date)
                    : "Dates TBA"}
                </div>
                <div className="flex items-center gap-1.5">
                  <Users size={12} className="text-neon" />
                  {p.tournament_type === "solo" ? "Solo entry" : `Team of ${p.team_size}`} · ₹{p.registration_fee.toLocaleString("en-IN")}
                </div>
              </div>
              <div className="mt-4 inline-flex items-center gap-1.5 text-xs text-neon font-bold uppercase tracking-wider">
                Register for this →
              </div>
            </Link>
          ))}
        </div>
      </div>
    );
  }

  if (submitted) {
    return (
      <div className="container mx-auto px-4 sm:px-6 py-20 sm:py-28 max-w-xl">
        <div className="rounded-3xl border border-neon/40 bg-card/70 backdrop-blur p-8 sm:p-10 shadow-glow text-center">
          <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-br from-neon to-primary flex items-center justify-center shadow-neon">
            <CheckCircle2 size={40} className="text-neon-foreground" />
          </div>
          <h1 className="font-display text-3xl sm:text-4xl text-gradient-neon mb-3">
            {submitted.method === "cash" ? "Registration Submitted!" : "Payment Submitted!"}
          </h1>
          <p className="text-muted-foreground mb-5">
            <span className="text-neon font-bold">{form.teamName}</span> has been registered for {tournament.name}.
          </p>

          <div className="my-5 inline-block rounded-xl border border-neon/30 bg-background/40 px-5 py-3">
            <div className="text-[10px] uppercase tracking-widest text-muted-foreground mb-1">Registration ID</div>
            <div className="font-mono text-sm text-neon break-all">{submitted.registrationId}</div>
          </div>

          {/* What's next */}
          <div className="text-left rounded-xl border border-border bg-background/40 p-5 mb-6 space-y-3">
            <div className="text-xs font-bold uppercase tracking-widest text-neon mb-1">What happens next</div>
            <div className="flex gap-3 text-sm">
              <div className="w-7 h-7 shrink-0 rounded-full bg-neon/10 border border-neon/40 flex items-center justify-center text-neon font-bold text-xs">1</div>
              <div>
                <div className="font-bold text-foreground">Check your email</div>
                <div className="text-xs text-muted-foreground">
                  A confirmation has been sent to <span className="text-neon">{form.email}</span>. Check inbox / spam.
                </div>
              </div>
            </div>
            <div className="flex gap-3 text-sm">
              <div className="w-7 h-7 shrink-0 rounded-full bg-neon/10 border border-neon/40 flex items-center justify-center text-neon font-bold text-xs">2</div>
              <div>
                <div className="font-bold text-foreground">
                  {submitted.method === "cash" ? "Pay cash at the venue" : "Wait for payment verification"}
                </div>
                <div className="text-xs text-muted-foreground">
                  {submitted.method === "cash" ? (
                    <>
                      Pay <span className="text-foreground font-bold">₹{fee.toLocaleString("en-IN")}</span>
                      {tournament.cash_payment_deadline && (
                        <> before <span className="text-amber-400 font-bold">{formatDateDMY(tournament.cash_payment_deadline)}</span></>
                      )}. Status stays <span className="text-amber-400 font-bold">PENDING</span> until collected.
                    </>
                  ) : (
                    <>Organizers verify your screenshot within 24 hours. You'll get an email once it's confirmed.</>
                  )}
                </div>
              </div>
            </div>
            <div className="flex gap-3 text-sm">
              <div className="w-7 h-7 shrink-0 rounded-full bg-neon/10 border border-neon/40 flex items-center justify-center text-neon font-bold text-xs">3</div>
              <div>
                <div className="font-bold text-foreground">Track from your dashboard</div>
                <div className="text-xs text-muted-foreground">
                  {user
                    ? <>Your dashboard shows live status, schedule, announcements & winner updates.</>
                    : <>Login with <span className="text-neon">{form.email}</span> to view live status, schedule & updates.</>}
                </div>
              </div>
            </div>
          </div>

          <div className="flex gap-3 justify-center flex-wrap">
            <button onClick={() => navigate({ to: user ? "/dashboard" : "/login" })} className="px-6 py-3 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground font-bold text-sm uppercase tracking-wider shadow-neon">
              {user ? "Go to Dashboard" : "Login to Dashboard"}
            </button>
            <button onClick={() => navigate({ to: "/" })} className="px-6 py-3 rounded-md border border-border hover:border-neon text-sm uppercase tracking-wider">
              Back to Home
            </button>
          </div>
        </div>
      </div>
    );
  }

  const inputCls = "w-full px-4 py-3 rounded-md bg-input/60 border border-border focus:border-neon focus:outline-none focus:ring-2 focus:ring-neon/30 transition-all text-sm";
  const labelCls = "block text-xs font-bold uppercase tracking-widest text-muted-foreground mb-2";

  // Players to render: captain is always shown. Then up to teamSize-1 additional player slots (or none for solo).
  const additionalPlayers: Array<{
    label: string;
    nameKey: "player2Name" | "player3Name" | "player4Name" | "player5Name";
    phoneKey: "player2Phone" | "player3Phone" | "player4Phone" | "player5Phone";
  }> = [];
  const allSlots = [
    { label: "Player 2", nameKey: "player2Name" as const, phoneKey: "player2Phone" as const },
    { label: "Player 3", nameKey: "player3Name" as const, phoneKey: "player3Phone" as const },
    { label: "Player 4", nameKey: "player4Name" as const, phoneKey: "player4Phone" as const },
    { label: "Player 5", nameKey: "player5Name" as const, phoneKey: "player5Phone" as const },
  ];
  if (!isSolo) {
    for (let i = 0; i < Math.min(teamSize - 1, 4); i++) additionalPlayers.push(allSlots[i]);
  }

  return (
    <div className="container mx-auto px-4 sm:px-6 py-14 sm:py-20">
      <SectionHeader
        eyebrow="Registration"
        title={isSolo ? "Solo Entry" : "Join The Lineup"}
        description={`Register${isSolo ? "" : ` your ${teamSize}-player team`} for ${tournament.name}. Pay via UPI or cash to confirm.`}
      />

      <div className="max-w-2xl mx-auto mb-6 rounded-xl border border-neon/30 bg-gradient-to-br from-card to-primary/10 p-5 shadow-glow">
        <div className="flex items-start gap-3">
          <Trophy className="text-neon shrink-0 mt-0.5" size={20} />
          <div className="flex-1">
            <div className="text-[10px] uppercase tracking-widest text-muted-foreground mb-1">Registering for</div>
            <div className="font-display text-xl text-neon">{tournament.name}</div>
            {tournament.qualification_date && (
              <div className="text-xs text-muted-foreground mt-1">
                Qualification {formatDateDMY(tournament.qualification_date)}
                {tournament.finals_date && ` · Finals ${formatDateDMY(tournament.finals_date)}`}
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="max-w-2xl mx-auto mb-6 grid sm:grid-cols-2 gap-3">
        <div className="rounded-xl border border-neon/30 bg-card/60 p-4 flex items-start gap-3 shadow-glow">
          <Users className="text-neon shrink-0 mt-0.5" size={18} />
          <div className="text-sm">
            <div className="font-bold">{isSolo ? "Solo Tournament" : `${teamSize}-Player Teams`}</div>
            <div className="text-muted-foreground text-xs">{isSolo ? "Compete individually." : "All players must be available for tournament dates."}</div>
          </div>
        </div>
        <div className="rounded-xl border border-neon/30 bg-card/60 p-4 flex items-start gap-3 shadow-glow">
          <Calendar className="text-neon shrink-0 mt-0.5" size={18} />
          <div className="text-sm">
            <div className="font-bold">{regOpen ? "Registration Open" : regClosedReason || "Registration Closed"}</div>
            <div className="text-muted-foreground text-xs">
              {regWindowState === "not_yet_open" && tournament.registration_open_date
                ? `Opens ${formatDateDMY(tournament.registration_open_date)}`
                : tournament.qualification_date
                ? `Starts ${formatDateDMY(tournament.qualification_date)}`
                : "Dates TBA"}
            </div>
          </div>
        </div>
      </div>

      <form onSubmit={onSubmit} className="max-w-2xl mx-auto rounded-2xl border border-border bg-card/60 backdrop-blur p-6 sm:p-10 shadow-glow space-y-6">
        <div>
          <h3 className="font-display text-lg text-neon mb-4">{isSolo ? "Entry Details" : "Team Details"}</h3>
          <div>
            <label className={labelCls}>{isSolo ? "Entry Name *" : "Team Name *"}</label>
            <input className={inputCls} value={form.teamName} onChange={update("teamName")} placeholder={isSolo ? "Your display name" : "The Pin Crushers"} />
            {errors.teamName && <ErrorMsg msg={errors.teamName} />}
          </div>
        </div>

        <div className="border-t border-border pt-6">
          <h3 className="font-display text-lg text-neon mb-4">{isSolo ? "Player Details" : "Team Captain (Player 1)"}</h3>
          <div className="space-y-5">
            <div>
              <label className={labelCls}>Full Name *</label>
              <input className={inputCls} value={form.captainName} onChange={update("captainName")} placeholder="John Doe" />
              {errors.captainName && <ErrorMsg msg={errors.captainName} />}
            </div>
            <div className="grid sm:grid-cols-2 gap-5">
              <div>
                <label className={labelCls}>Email *</label>
                <input
                  type="email"
                  className={inputCls + (user ? " opacity-70 cursor-not-allowed" : "")}
                  value={form.email}
                  onChange={update("email")}
                  placeholder="captain@email.com"
                  disabled={!!user}
                />
                {errors.email && <ErrorMsg msg={errors.email} />}
              </div>
              <div>
                <label className={labelCls}>Phone *</label>
                <input type="tel" className={inputCls} value={form.captainPhone} onChange={update("captainPhone")} placeholder="+91 98765 43210" />
                {errors.captainPhone && <ErrorMsg msg={errors.captainPhone} />}
              </div>
            </div>
            {!user ? (
              <div>
                <label className={labelCls}>Account Password *</label>
                <input type="password" className={inputCls} value={form.password} onChange={update("password")} placeholder="Min 6 characters" />
                {errors.password && <ErrorMsg msg={errors.password} />}
                <p className="text-xs text-muted-foreground mt-2">Login with this email + password to access your dashboard.</p>
              </div>
            ) : (
              <div className="rounded-md border border-neon/30 bg-neon/5 p-3 text-xs text-muted-foreground">
                Registering as <span className="text-neon font-bold">{user.email}</span>. This entry will appear on your dashboard.
              </div>
            )}
          </div>
        </div>

        {additionalPlayers.map((p) => (
          <div key={p.nameKey} className="border-t border-border pt-6">
            <h3 className="font-display text-lg text-neon mb-4">{p.label}</h3>
            <div className="grid sm:grid-cols-2 gap-5">
              <div>
                <label className={labelCls}>Full Name *</label>
                <input className={inputCls} value={form[p.nameKey]} onChange={update(p.nameKey)} placeholder={`${p.label} name`} />
                {errors[p.nameKey] && <ErrorMsg msg={errors[p.nameKey]} />}
              </div>
              <div>
                <label className={labelCls}>Phone</label>
                <input type="tel" className={inputCls} value={form[p.phoneKey]} onChange={update(p.phoneKey)} placeholder="+91 ..." />
              </div>
            </div>
          </div>
        ))}

        {/* PAYMENT */}
        <div className="border-t border-border pt-6">
          <h3 className="font-display text-lg text-neon mb-4">Payment</h3>

          <div className="rounded-xl border border-neon/40 bg-gradient-to-br from-card/80 to-card/40 p-5 shadow-glow mb-4">
            <div className="flex items-center justify-between gap-4">
              <div className="text-sm text-muted-foreground">Entry Fee</div>
              <div className="text-right">
                <div className="font-display text-3xl text-gradient-neon">₹{fee.toLocaleString("en-IN")}</div>
                <div className="text-[10px] uppercase tracking-widest text-muted-foreground">{isSolo ? "per entry" : `per team of ${teamSize}`}</div>
              </div>
            </div>
          </div>

          {enabledMethods.length === 0 ? (
            <div className="rounded-md border border-destructive/40 bg-destructive/10 p-4 text-sm text-destructive">
              No payment methods configured for this tournament. Please contact organizers.
            </div>
          ) : (
            <>
              <label className={labelCls}>Choose Payment Method</label>
              <div className="grid sm:grid-cols-2 gap-3 mb-5">
                {enabledMethods.includes("upi_qr") && (
                  <button
                    type="button"
                    onClick={() => setForm((f) => ({ ...f, paymentMethod: "upi_qr" }))}
                    className={`text-left rounded-xl border p-4 transition-all ${form.paymentMethod === "upi_qr" ? "border-neon bg-neon/10 shadow-glow" : "border-border bg-card/40 hover:border-neon/40"}`}
                  >
                    <div className="flex items-center gap-2 mb-1 text-neon">
                      <Smartphone size={18} /> <span className="font-display">UPI / QR Code</span>
                    </div>
                    <div className="text-xs text-muted-foreground">Scan, pay, then upload screenshot. Verified within 24h.</div>
                  </button>
                )}
                {enabledMethods.includes("cash") && (
                  <button
                    type="button"
                    onClick={() => setForm((f) => ({ ...f, paymentMethod: "cash" }))}
                    className={`text-left rounded-xl border p-4 transition-all ${form.paymentMethod === "cash" ? "border-neon bg-neon/10 shadow-glow" : "border-border bg-card/40 hover:border-neon/40"}`}
                  >
                    <div className="flex items-center gap-2 mb-1 text-neon">
                      <Banknote size={18} /> <span className="font-display">Cash at Venue</span>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      Pay in person.
                      {tournament.cash_payment_deadline && (
                        <> Deadline: <span className="text-amber-400">{formatDateDMY(tournament.cash_payment_deadline)}</span></>
                      )}
                    </div>
                  </button>
                )}
              </div>

              {/* UPI/QR detail panel */}
              {form.paymentMethod === "upi_qr" && (
                <div className="rounded-xl border border-border bg-card/40 p-5 space-y-4">
                  <div className="grid sm:grid-cols-[auto,1fr] gap-5 items-start">
                    <div className="w-44 aspect-square rounded-lg border border-border bg-background/60 overflow-hidden flex items-center justify-center mx-auto sm:mx-0">
                      {tournament.upi_qr_url ? (
                        <img src={tournament.upi_qr_url} alt="UPI QR Code" className="w-full h-full object-contain p-2" />
                      ) : (
                        <div className="text-center text-xs text-muted-foreground p-3">
                          <ImageIcon className="w-8 h-8 mx-auto mb-1 opacity-50" />
                          QR not configured
                        </div>
                      )}
                    </div>
                    <div className="text-sm space-y-2">
                      <div>
                        <div className="text-[10px] uppercase tracking-widest text-muted-foreground">Pay this amount</div>
                        <div className="font-display text-2xl text-neon">₹{fee.toLocaleString("en-IN")}</div>
                      </div>
                      {tournament.upi_id && (
                        <div>
                          <div className="text-[10px] uppercase tracking-widest text-muted-foreground">UPI ID</div>
                          <div className="font-mono text-sm">{tournament.upi_id}</div>
                        </div>
                      )}
                      {tournament.payment_instructions && (
                        <p className="text-xs text-muted-foreground whitespace-pre-line">{tournament.payment_instructions}</p>
                      )}
                    </div>
                  </div>

                  <div>
                    <label className={labelCls}>Payment Screenshot *</label>
                    {proofPreview ? (
                      <div className="relative w-48 rounded-lg border border-neon/40 overflow-hidden">
                        <img src={proofPreview} alt="Payment proof" className="w-full h-auto" />
                        <button
                          type="button"
                          onClick={() => { setProofFile(null); setProofPreview(null); }}
                          className="absolute top-1 right-1 bg-background/80 rounded-full p-1 text-destructive"
                          title="Remove"
                        >
                          <X size={14} />
                        </button>
                      </div>
                    ) : (
                      <label className="inline-flex items-center gap-2 cursor-pointer rounded-md border border-dashed border-border hover:border-neon px-4 py-3 text-xs uppercase tracking-wider font-bold">
                        <Upload size={14} /> Choose Screenshot
                        <input type="file" accept="image/*" onChange={onProofChange} className="hidden" />
                      </label>
                    )}
                    <p className="text-[11px] text-muted-foreground mt-2">PNG / JPG up to 5 MB. Show the success screen with amount and timestamp.</p>
                  </div>

                  <div>
                    <label className={labelCls}>UPI Transaction / UTR Reference (optional)</label>
                    <input className={inputCls} value={form.upiTransactionRef} onChange={update("upiTransactionRef")} placeholder="12-digit UTR or txn ID" />
                  </div>
                </div>
              )}

              {/* CASH detail panel */}
              {form.paymentMethod === "cash" && (
                <div className="rounded-xl border border-amber-400/40 bg-amber-400/5 p-5 text-sm space-y-2">
                  <div className="flex items-center gap-2 text-amber-400 font-bold">
                    <Banknote size={16} /> Cash Payment Selected
                  </div>
                  <p className="text-muted-foreground text-xs">
                    Your registration will be marked <span className="text-amber-400 font-bold">PENDING</span> until cash is collected by an organizer.
                  </p>
                  {tournament.cash_payment_deadline && (
                    <p className="text-muted-foreground text-xs">
                      Pay before: <span className="text-amber-400 font-bold">{formatDateDMY(tournament.cash_payment_deadline)}</span> or your slot may be released.
                    </p>
                  )}
                  {tournament.payment_instructions && (
                    <p className="text-muted-foreground text-xs whitespace-pre-line">{tournament.payment_instructions}</p>
                  )}
                </div>
              )}
            </>
          )}
        </div>

        <button
          type="submit"
          disabled={loading || uploadingProof || !regOpen || enabledMethods.length === 0}
          className="w-full py-4 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground font-bold uppercase tracking-wider shadow-neon hover:scale-[1.02] transition-transform disabled:opacity-50 disabled:cursor-not-allowed inline-flex items-center justify-center gap-2"
        >
          {loading || uploadingProof ? <Loader2 size={16} className="animate-spin" /> : <Lock size={16} />}
          {loading
            ? "Submitting…"
            : uploadingProof
            ? "Uploading screenshot…"
            : !regOpen
            ? regClosedReason || "Registration Closed"
            : form.paymentMethod === "cash"
            ? `Reserve Slot · Pay ₹${fee.toLocaleString("en-IN")} Cash`
            : `Submit Payment · ₹${fee.toLocaleString("en-IN")}`}
        </button>

        <p className="text-center text-xs text-muted-foreground">
          Already registered? <Link to="/login" className="text-neon hover:underline">Log in</Link>
        </p>
      </form>
    </div>
  );
}

function ErrorMsg({ msg }: { msg: string }) {
  return (
    <div className="flex items-center gap-1.5 mt-2 text-xs text-destructive">
      <AlertCircle size={12} /> {msg}
    </div>
  );
}
