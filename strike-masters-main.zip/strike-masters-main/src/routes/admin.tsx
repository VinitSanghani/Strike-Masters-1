import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Loader2, Search, Download, Users, CheckCircle2, Clock, XCircle, Trash2, Edit3, Save, X, Plus, Pin, Settings, Megaphone, ShieldAlert, Award, Image as ImageIcon, Trophy, FileText, LayoutDashboard, Wallet, Layers, Crown, Handshake } from "lucide-react";
import { SectionHeader } from "@/components/SectionHeader";
import { useAuth } from "@/hooks/use-auth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { SponsorsTab } from "@/components/admin/SponsorsTab";
import { TournamentsTab } from "@/components/admin/TournamentsTab";
import { TournamentContentTab } from "@/components/admin/TournamentContentTab";
import { AdminOverviewTab } from "@/components/admin/AdminOverviewTab";
import { PaymentVerificationTab } from "@/components/admin/PaymentVerificationTab";
import { RoundsScoringTab } from "@/components/admin/RoundsScoringTab";
import { WinnersTab } from "@/components/admin/WinnersTab";
import { GalleryTab } from "@/components/admin/GalleryTab";
import { AboutContentTab } from "@/components/admin/AboutContentTab";
import { ContactContentTab } from "@/components/admin/ContactContentTab";
import { LegalPagesTab } from "@/components/admin/LegalPagesTab";
import { SponsorsPageTab } from "@/components/admin/SponsorsPageTab";
import { SiteSettingsTab } from "@/components/admin/SiteSettingsTab";
import { TournamentSponsorsTab } from "@/components/admin/TournamentSponsorsTab";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Admin — Strike Masters Tournament 2026" },
      { name: "description", content: "Strike Masters tournament admin panel." },
    ],
  }),
  component: AdminPage,
});

interface Registration {
  id: string;
  user_id: string;
  team_name: string;
  captain_name: string;
  captain_email: string;
  captain_phone: string;
  player2_name: string;
  player2_phone: string | null;
  player3_name: string;
  player3_phone: string | null;
  substitute_name: string | null;
  substitute_phone: string | null;
  skill_level: string;
  payment_transaction_id: string | null;
  payment_verified: boolean;
  razorpay_order_id: string | null;
  razorpay_payment_id: string | null;
  amount_paid: number | null;
  status: "pending" | "approved" | "rejected";
  qualification_status: string | null;
  admin_notes: string | null;
  created_at: string;
}

interface Settings {
  id: number;
  prize_pool: string;
  registration_open: boolean;
  registration_deadline: string | null;
  tournament_start_date: string | null;
  tournament_end_date: string | null;
  finalist_team_count: number;
  registration_fee: number;
  notes: string | null;
}

interface Announcement {
  id: string;
  title: string;
  body: string;
  pinned: boolean;
  created_at: string;
}

type Tab = "overview" | "tournaments" | "content" | "registrations" | "payments" | "rounds" | "winners" | "announcements" | "sponsors" | "tournament_sponsors" | "sponsors_page" | "gallery" | "about" | "contact" | "legal" | "footer" | "settings";

function AdminPage() {
  const { user, isAdmin, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [tab, setTab] = useState<Tab>("overview");
  const [loading, setLoading] = useState(true);
  const [registrations, setRegistrations] = useState<Registration[]>([]);
  const [settings, setSettings] = useState<Settings | null>(null);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<"all" | "pending" | "approved" | "rejected">("all");
  const [paymentFilter, setPaymentFilter] = useState<"all" | "paid" | "unpaid">("all");

  useEffect(() => {
    if (!authLoading && (!user || !isAdmin)) {
      navigate({ to: "/login" });
    }
  }, [user, isAdmin, authLoading, navigate]);

  const refresh = async () => {
    const [regs, s, anns] = await Promise.all([
      supabase.from("registrations").select("*").order("created_at", { ascending: false }),
      supabase.from("tournament_settings").select("*").eq("id", 1).maybeSingle(),
      supabase.from("announcements").select("*").order("pinned", { ascending: false }).order("created_at", { ascending: false }),
    ]);
    setRegistrations((regs.data ?? []) as Registration[]);
    setSettings(s.data as Settings | null);
    setAnnouncements((anns.data ?? []) as Announcement[]);
    setLoading(false);
  };

  useEffect(() => {
    if (user && isAdmin) refresh();
  }, [user, isAdmin]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return registrations.filter((r) => {
      if (statusFilter !== "all" && r.status !== statusFilter) return false;
      if (paymentFilter === "paid" && !r.payment_verified) return false;
      if (paymentFilter === "unpaid" && r.payment_verified) return false;
      if (!q) return true;
      return [r.team_name, r.captain_name, r.captain_email, r.captain_phone, r.player2_name, r.player3_name, r.razorpay_payment_id, r.razorpay_order_id]
        .some((v) => v?.toLowerCase().includes(q));
    });
  }, [registrations, search, statusFilter, paymentFilter]);

  // Detect possible duplicate registrations across teams (email / phone / team name)
  const duplicateMap = useMemo(() => {
    const counts = { email: new Map<string, number>(), phone: new Map<string, number>(), team: new Map<string, number>() };
    for (const r of registrations) {
      const e = r.captain_email?.toLowerCase().trim();
      const p = r.captain_phone?.replace(/\D/g, "");
      const t = r.team_name?.toLowerCase().trim();
      if (e) counts.email.set(e, (counts.email.get(e) ?? 0) + 1);
      if (p) counts.phone.set(p, (counts.phone.get(p) ?? 0) + 1);
      if (t) counts.team.set(t, (counts.team.get(t) ?? 0) + 1);
    }
    const map = new Map<string, string[]>();
    for (const r of registrations) {
      const reasons: string[] = [];
      const e = r.captain_email?.toLowerCase().trim();
      const p = r.captain_phone?.replace(/\D/g, "");
      const t = r.team_name?.toLowerCase().trim();
      if (e && (counts.email.get(e) ?? 0) > 1) reasons.push("email");
      if (p && (counts.phone.get(p) ?? 0) > 1) reasons.push("phone");
      if (t && (counts.team.get(t) ?? 0) > 1) reasons.push("team");
      if (reasons.length) map.set(r.id, reasons);
    }
    return map;
  }, [registrations]);

  const counts = useMemo(() => ({
    total: registrations.length,
    pending: registrations.filter((r) => r.status === "pending").length,
    approved: registrations.filter((r) => r.status === "approved").length,
    rejected: registrations.filter((r) => r.status === "rejected").length,
    paid: registrations.filter((r) => r.payment_verified).length,
  }), [registrations]);

  if (authLoading || loading) {
    return (
      <div className="container mx-auto px-4 py-32 text-center">
        <Loader2 className="w-8 h-8 mx-auto animate-spin text-neon" />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="container mx-auto px-4 py-32 text-center max-w-md">
        <ShieldAlert className="w-12 h-12 mx-auto text-destructive mb-3" />
        <h1 className="font-display text-2xl mb-2">Access Denied</h1>
        <p className="text-sm text-muted-foreground">This area is restricted to tournament organizers.</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 sm:px-6 py-14 sm:py-20">
      <SectionHeader
        eyebrow="Admin Control"
        title="Tournament Dashboard"
        description="Manage registrations, payments, announcements, and tournament settings."
      />

      {/* Stat overview */}
      <div className="max-w-6xl mx-auto grid grid-cols-2 sm:grid-cols-5 gap-3 mb-6">
        <StatTile icon={<Users size={14} />} label="Teams" value={counts.total} />
        <StatTile icon={<Clock size={14} />} label="Pending" value={counts.pending} accent="amber" />
        <StatTile icon={<CheckCircle2 size={14} />} label="Approved" value={counts.approved} accent="success" />
        <StatTile icon={<XCircle size={14} />} label="Rejected" value={counts.rejected} accent="destructive" />
        <StatTile icon={<CheckCircle2 size={14} />} label="Paid" value={counts.paid} accent="neon" />
      </div>

      {/* Tabs */}
      <div className="max-w-6xl mx-auto mb-6 flex gap-1 border-b border-border overflow-x-auto">
        {([
          ["overview", "Overview", LayoutDashboard],
          ["tournaments", "Tournaments", Trophy],
          ["content", "Content", FileText],
          ["registrations", "Registrations", Users],
          ["payments", "Payments", Wallet],
          ["rounds", "Rounds & Scores", Layers],
          ["winners", "Winners", Crown],
          ["announcements", "Announcements", Megaphone],
          ["sponsors", "Sponsors", ImageIcon],
          ["tournament_sponsors", "Tournament Sponsors", Handshake],
          ["sponsors_page", "Sponsors Page", FileText],
          ["gallery", "Gallery", ImageIcon],
          ["about", "About Page", FileText],
          ["contact", "Contact Page", FileText],
          ["legal", "Rules & Refund", FileText],
          ["footer", "Footer", FileText],
          ["settings", "Settings", Settings],
        ] as const).map(([k, l, Icon]) => (
          <button
            key={k}
            onClick={() => setTab(k)}
            className={`px-4 py-3 text-xs uppercase tracking-widest font-bold border-b-2 transition-colors flex items-center gap-2 whitespace-nowrap ${
              tab === k ? "border-neon text-neon" : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            <Icon size={14} /> {l}
          </button>
        ))}
      </div>

      <div className="max-w-6xl mx-auto">
        {tab === "overview" && (
          <AdminOverviewTab onJump={(t) => setTab(t)} />
        )}
        {tab === "tournaments" && <TournamentsTab />}
        {tab === "content" && <TournamentContentTab />}
        {tab === "registrations" && (
          <RegistrationsTab
            data={filtered}
            duplicateMap={duplicateMap}
            search={search}
            setSearch={setSearch}
            statusFilter={statusFilter}
            setStatusFilter={setStatusFilter}
            paymentFilter={paymentFilter}
            setPaymentFilter={setPaymentFilter}
            onRefresh={refresh}
          />
        )}
        {tab === "payments" && <PaymentVerificationTab />}
        {tab === "rounds" && <RoundsScoringTab />}
        {tab === "winners" && <WinnersTab />}
        {tab === "announcements" && (
          <AnnouncementsTab data={announcements} onRefresh={refresh} userId={user!.id} />
        )}
        {tab === "sponsors" && <SponsorsTab />}
        {tab === "tournament_sponsors" && <TournamentSponsorsTab />}
        {tab === "sponsors_page" && <SponsorsPageTab />}
        {tab === "gallery" && <GalleryTab />}
        {tab === "about" && <AboutContentTab />}
        {tab === "contact" && <ContactContentTab />}
        {tab === "legal" && <LegalPagesTab />}
        {tab === "footer" && <SiteSettingsTab />}
        {tab === "settings" && settings && <SettingsTab data={settings} onRefresh={refresh} />}
      </div>
    </div>
  );
}

function StatTile({ icon, label, value, accent }: { icon: React.ReactNode; label: string; value: number; accent?: string }) {
  const cls =
    accent === "amber" ? "text-amber-400" :
    accent === "success" ? "text-success" :
    accent === "destructive" ? "text-destructive" : "text-neon";
  return (
    <div className="rounded-xl border border-border bg-card/60 p-4 shadow-glow">
      <div className={`flex items-center gap-1.5 ${cls} text-[10px] uppercase tracking-widest mb-1`}>
        {icon} {label}
      </div>
      <div className="font-display text-2xl">{value}</div>
    </div>
  );
}

function RegistrationsTab({
  data, duplicateMap, search, setSearch, statusFilter, setStatusFilter, paymentFilter, setPaymentFilter, onRefresh,
}: {
  data: Registration[];
  duplicateMap: Map<string, string[]>;
  search: string;
  setSearch: (v: string) => void;
  statusFilter: "all" | "pending" | "approved" | "rejected";
  setStatusFilter: (v: "all" | "pending" | "approved" | "rejected") => void;
  paymentFilter: "all" | "paid" | "unpaid";
  setPaymentFilter: (v: "all" | "paid" | "unpaid") => void;
  onRefresh: () => Promise<void>;
}) {
  const [editing, setEditing] = useState<Registration | null>(null);

  const exportCsv = () => {
    const headers = ["Team", "Captain", "Email", "Phone", "Player 2", "Player 3", "Substitute", "Skill", "Razorpay Order ID", "Razorpay Payment ID", "Amount Paid (INR)", "Payment Verified", "Status", "Submitted"];
    const rows = data.map((r) => [
      r.team_name, r.captain_name, r.captain_email, r.captain_phone, r.player2_name, r.player3_name,
      r.substitute_name ?? "", r.skill_level,
      r.razorpay_order_id ?? "", r.razorpay_payment_id ?? r.payment_transaction_id ?? "",
      r.amount_paid != null ? (r.amount_paid / 100).toFixed(2) : "",
      r.payment_verified ? "Yes" : "No", r.status, new Date(r.created_at).toLocaleString(),
    ]);
    const csv = [headers, ...rows].map((row) => row.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `strike-masters-registrations-${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const setStatus = async (id: string, status: "pending" | "approved" | "rejected") => {
    const { error } = await supabase.from("registrations").update({ status }).eq("id", id);
    if (error) return toast.error(error.message);
    toast.success(`Marked as ${status}`);
    await onRefresh();
  };

  const togglePaid = async (r: Registration) => {
    const { error } = await supabase.from("registrations").update({ payment_verified: !r.payment_verified }).eq("id", r.id);
    if (error) return toast.error(error.message);
    toast.success(`Payment ${!r.payment_verified ? "verified" : "marked unverified"}`);
    await onRefresh();
  };

  const remove = async (id: string) => {
    if (!confirm("Delete this registration permanently?")) return;
    const { error } = await supabase.from("registrations").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Registration deleted");
    await onRefresh();
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search team, captain, email, phone…"
            className="w-full pl-10 pr-4 py-2.5 rounded-md bg-input/60 border border-border focus:border-neon focus:outline-none text-sm"
          />
        </div>
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value as "all" | "pending" | "approved" | "rejected")}
          className="px-4 py-2.5 rounded-md bg-input/60 border border-border focus:border-neon focus:outline-none text-sm"
        >
          <option value="all">All statuses</option>
          <option value="pending">Pending</option>
          <option value="approved">Approved</option>
          <option value="rejected">Rejected</option>
        </select>
        <select
          value={paymentFilter}
          onChange={(e) => setPaymentFilter(e.target.value as "all" | "paid" | "unpaid")}
          className="px-4 py-2.5 rounded-md bg-input/60 border border-border focus:border-neon focus:outline-none text-sm"
        >
          <option value="all">All payments</option>
          <option value="paid">Paid only</option>
          <option value="unpaid">Unpaid only</option>
        </select>
        <button
          onClick={exportCsv}
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-md border border-border hover:border-neon text-xs uppercase tracking-wider font-bold"
        >
          <Download size={14} /> Export CSV
        </button>
      </div>

      <div className="rounded-2xl border border-border bg-card/40 backdrop-blur shadow-glow overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-card/80">
              <tr className="text-left text-[10px] uppercase tracking-widest text-muted-foreground">
                <th className="px-4 py-3">Team</th>
                <th className="px-4 py-3">Captain</th>
                <th className="px-4 py-3">Contact</th>
                <th className="px-4 py-3">Players</th>
                <th className="px-4 py-3">Payment</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {data.length === 0 && (
                <tr><td colSpan={7} className="px-4 py-12 text-center text-sm text-muted-foreground">No registrations match your filters.</td></tr>
              )}
              {data.map((r) => {
                const dups = duplicateMap.get(r.id);
                return (
                <tr key={r.id} className="hover:bg-accent/40 transition-colors">
                  <td className="px-4 py-3">
                    <div className="font-display flex items-center gap-2">
                      {r.team_name}
                      {dups && (
                        <span title={`Possible duplicate: ${dups.join(", ")}`} className="text-[9px] uppercase tracking-widest font-bold text-amber-400 border border-amber-400/40 rounded px-1.5 py-0.5">
                          Dup: {dups.join("/")}
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-muted-foreground capitalize">{r.skill_level}</div>
                  </td>
                  <td className="px-4 py-3">{r.captain_name}</td>
                  <td className="px-4 py-3 text-xs">
                    <div>{r.captain_email}</div>
                    <div className="text-muted-foreground">{r.captain_phone}</div>
                  </td>
                  <td className="px-4 py-3 text-xs">
                    <div>{r.player2_name}</div>
                    <div>{r.player3_name}</div>
                    {r.substitute_name && <div className="text-muted-foreground">Sub: {r.substitute_name}</div>}
                  </td>
                  <td className="px-4 py-3 text-xs">
                    {r.amount_paid != null && (
                      <div className="font-display text-sm text-neon">₹{(r.amount_paid / 100).toLocaleString("en-IN")}</div>
                    )}
                    {r.razorpay_payment_id ? (
                      <div className="font-mono text-[10px] text-muted-foreground break-all" title="Razorpay Payment ID">{r.razorpay_payment_id}</div>
                    ) : r.payment_transaction_id ? (
                      <div className="font-mono text-[10px] text-muted-foreground break-all">{r.payment_transaction_id}</div>
                    ) : (
                      <div className="text-muted-foreground">—</div>
                    )}
                    {r.razorpay_order_id && (
                      <div className="font-mono text-[10px] text-muted-foreground/70 break-all" title="Razorpay Order ID">{r.razorpay_order_id}</div>
                    )}
                    <button
                      onClick={() => togglePaid(r)}
                      className={`mt-1 inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] uppercase tracking-wider font-bold border ${
                        r.payment_verified ? "border-success/40 text-success" : "border-amber-400/40 text-amber-400"
                      }`}
                    >
                      {r.payment_verified ? "✓ Verified" : "Unverified"}
                    </button>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`inline-flex items-center gap-1 px-2 py-1 rounded text-[10px] uppercase tracking-wider font-bold border ${
                      r.status === "approved" ? "border-success/40 text-success" :
                      r.status === "rejected" ? "border-destructive/40 text-destructive" :
                      "border-amber-400/40 text-amber-400"
                    }`}>
                      {r.status === "approved" && <CheckCircle2 size={10} />}
                      {r.status === "rejected" && <XCircle size={10} />}
                      {r.status === "pending" && <Clock size={10} />}
                      {r.status}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex flex-wrap items-center gap-1">
                      {r.status !== "approved" && (
                        <button onClick={() => setStatus(r.id, "approved")} className="p-1.5 rounded text-success hover:bg-success/10" title="Approve">
                          <CheckCircle2 size={14} />
                        </button>
                      )}
                      {r.status !== "rejected" && (
                        <button onClick={() => setStatus(r.id, "rejected")} className="p-1.5 rounded text-destructive hover:bg-destructive/10" title="Reject">
                          <XCircle size={14} />
                        </button>
                      )}
                      <button onClick={() => setEditing(r)} className="p-1.5 rounded text-neon hover:bg-neon/10" title="Edit">
                        <Edit3 size={14} />
                      </button>
                      <button onClick={() => remove(r.id)} className="p-1.5 rounded text-destructive hover:bg-destructive/10" title="Delete">
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {editing && (
        <EditRegistrationModal
          reg={editing}
          onClose={() => setEditing(null)}
          onSaved={async () => { setEditing(null); await onRefresh(); }}
        />
      )}
    </div>
  );
}

function EditRegistrationModal({ reg, onClose, onSaved }: { reg: Registration; onClose: () => void; onSaved: () => Promise<void> }) {
  const [form, setForm] = useState(reg);
  const [saving, setSaving] = useState(false);

  const save = async () => {
    setSaving(true);
    const { error } = await supabase.from("registrations").update({
      team_name: form.team_name,
      captain_name: form.captain_name,
      captain_email: form.captain_email,
      captain_phone: form.captain_phone,
      player2_name: form.player2_name,
      player3_name: form.player3_name,
      substitute_name: form.substitute_name,
      payment_transaction_id: form.payment_transaction_id,
      qualification_status: form.qualification_status || null,
      admin_notes: form.admin_notes,
    }).eq("id", reg.id);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Registration updated");
    await onSaved();
  };

  const f = (k: keyof Registration, label: string, type = "text") => (
    <div>
      <label className="block text-[10px] uppercase tracking-widest text-muted-foreground mb-1">{label}</label>
      <input
        type={type}
        value={(form[k] ?? "") as string}
        onChange={(e) => setForm({ ...form, [k]: e.target.value })}
        className="w-full px-3 py-2 rounded-md bg-input/60 border border-border text-sm focus:border-neon focus:outline-none"
      />
    </div>
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur" onClick={onClose}>
      <div className="w-full max-w-2xl rounded-2xl border border-border bg-card p-6 shadow-glow max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display text-xl text-neon">Edit Registration</h3>
          <button onClick={onClose} className="p-2 hover:bg-accent rounded"><X size={16} /></button>
        </div>
        <div className="grid sm:grid-cols-2 gap-3">
          {f("team_name", "Team Name")}
          {f("captain_name", "Captain")}
          {f("captain_email", "Email", "email")}
          {f("captain_phone", "Phone")}
          {f("player2_name", "Player 2")}
          {f("player3_name", "Player 3")}
          {f("substitute_name", "Substitute")}
          {f("payment_transaction_id", "Payment Ref")}
        </div>
        <div className="mt-3">
          <label className="block text-[10px] uppercase tracking-widest text-muted-foreground mb-1 inline-flex items-center gap-1.5">
            <Award size={11} className="text-gold" /> Qualification / Tournament Status (shown on team dashboard)
          </label>
          <input
            value={form.qualification_status ?? ""}
            onChange={(e) => setForm({ ...form, qualification_status: e.target.value })}
            placeholder="e.g. Qualified for Finals · Group A"
            className="w-full px-3 py-2 rounded-md bg-input/60 border border-border text-sm focus:border-neon focus:outline-none"
          />
        </div>
        <div className="mt-3">
          <label className="block text-[10px] uppercase tracking-widest text-muted-foreground mb-1">Note to Team (visible in their dashboard)</label>
          <textarea
            value={form.admin_notes ?? ""}
            onChange={(e) => setForm({ ...form, admin_notes: e.target.value })}
            rows={3}
            className="w-full px-3 py-2 rounded-md bg-input/60 border border-border text-sm focus:border-neon focus:outline-none"
          />
        </div>
        <div className="mt-5 flex justify-end gap-2">
          <button onClick={onClose} className="px-4 py-2 rounded-md border border-border text-xs uppercase tracking-wider font-bold">Cancel</button>
          <button onClick={save} disabled={saving} className="inline-flex items-center gap-2 px-4 py-2 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground text-xs uppercase tracking-wider font-bold disabled:opacity-50">
            {saving && <Loader2 size={14} className="animate-spin" />}
            <Save size={14} /> Save
          </button>
        </div>
      </div>
    </div>
  );
}

function AnnouncementsTab({ data, onRefresh, userId }: { data: Announcement[]; onRefresh: () => Promise<void>; userId: string }) {
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [pinned, setPinned] = useState(false);
  const [saving, setSaving] = useState(false);

  const create = async () => {
    if (!title.trim() || !body.trim()) return toast.error("Title and body required");
    setSaving(true);
    const { error } = await supabase.from("announcements").insert({ title: title.trim(), body: body.trim(), pinned, created_by: userId });
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Announcement posted");
    setTitle(""); setBody(""); setPinned(false);
    await onRefresh();
  };

  const togglePin = async (a: Announcement) => {
    const { error } = await supabase.from("announcements").update({ pinned: !a.pinned }).eq("id", a.id);
    if (error) return toast.error(error.message);
    await onRefresh();
  };

  const remove = async (id: string) => {
    if (!confirm("Delete this announcement?")) return;
    const { error } = await supabase.from("announcements").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Deleted");
    await onRefresh();
  };

  return (
    <div className="grid lg:grid-cols-2 gap-6">
      <div className="rounded-2xl border border-border bg-card/60 p-6 shadow-glow space-y-4">
        <h3 className="font-display text-lg text-neon flex items-center gap-2"><Plus size={16} /> New Announcement</h3>
        <div>
          <label className="block text-[10px] uppercase tracking-widest text-muted-foreground mb-1">Title</label>
          <input value={title} onChange={(e) => setTitle(e.target.value)} className="w-full px-3 py-2 rounded-md bg-input/60 border border-border text-sm focus:border-neon focus:outline-none" />
        </div>
        <div>
          <label className="block text-[10px] uppercase tracking-widest text-muted-foreground mb-1">Body</label>
          <textarea value={body} onChange={(e) => setBody(e.target.value)} rows={5} className="w-full px-3 py-2 rounded-md bg-input/60 border border-border text-sm focus:border-neon focus:outline-none" />
        </div>
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={pinned} onChange={(e) => setPinned(e.target.checked)} /> Pin to top
        </label>
        <button onClick={create} disabled={saving} className="w-full inline-flex items-center justify-center gap-2 py-3 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground text-xs uppercase tracking-wider font-bold disabled:opacity-50">
          {saving && <Loader2 size={14} className="animate-spin" />} Post Announcement
        </button>
      </div>

      <div className="rounded-2xl border border-border bg-card/60 p-6 shadow-glow">
        <h3 className="font-display text-lg text-neon mb-3">Existing</h3>
        {data.length === 0 ? (
          <p className="text-sm text-muted-foreground">None yet.</p>
        ) : (
          <ul className="divide-y divide-border max-h-[500px] overflow-y-auto">
            {data.map((a) => (
              <li key={a.id} className="py-3 first:pt-0 last:pb-0 flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    {a.pinned && <Pin size={10} className="text-neon" />}
                    <h4 className="font-display text-sm">{a.title}</h4>
                  </div>
                  <p className="text-xs text-muted-foreground line-clamp-2">{a.body}</p>
                </div>
                <div className="flex gap-1">
                  <button onClick={() => togglePin(a)} className="p-1.5 rounded text-neon hover:bg-neon/10" title={a.pinned ? "Unpin" : "Pin"}>
                    <Pin size={14} />
                  </button>
                  <button onClick={() => remove(a.id)} className="p-1.5 rounded text-destructive hover:bg-destructive/10" title="Delete">
                    <Trash2 size={14} />
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

function SettingsTab({ data, onRefresh }: { data: Settings; onRefresh: () => Promise<void> }) {
  const [form, setForm] = useState(data);
  const [saving, setSaving] = useState(false);

  const save = async () => {
    setSaving(true);
    const { error } = await supabase.from("tournament_settings").update({
      prize_pool: form.prize_pool,
      registration_open: form.registration_open,
      registration_deadline: form.registration_deadline,
      tournament_start_date: form.tournament_start_date,
      tournament_end_date: form.tournament_end_date,
      finalist_team_count: form.finalist_team_count,
      registration_fee: form.registration_fee,
      notes: form.notes,
    }).eq("id", 1);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Settings saved");
    await onRefresh();
  };

  const inputCls = "w-full px-3 py-2 rounded-md bg-input/60 border border-border text-sm focus:border-neon focus:outline-none";
  const labelCls = "block text-[10px] uppercase tracking-widest text-muted-foreground mb-1";

  return (
    <div className="rounded-2xl border border-border bg-card/60 p-6 sm:p-8 shadow-glow space-y-5 max-w-3xl">
      <div>
        <label className={labelCls}>Prize Pool Display Text</label>
        <input className={inputCls} value={form.prize_pool} onChange={(e) => setForm({ ...form, prize_pool: e.target.value })} />
      </div>
      <label className="flex items-center gap-3 cursor-pointer">
        <input
          type="checkbox"
          checked={form.registration_open}
          onChange={(e) => setForm({ ...form, registration_open: e.target.checked })}
          className="w-4 h-4"
        />
        <span className="text-sm font-bold">Registration is currently open</span>
      </label>
      <div className="grid sm:grid-cols-3 gap-4">
        <div>
          <label className={labelCls}>Registration Deadline</label>
          <input type="date" className={inputCls} value={form.registration_deadline ?? ""} onChange={(e) => setForm({ ...form, registration_deadline: e.target.value || null })} />
        </div>
        <div>
          <label className={labelCls}>Tournament Start</label>
          <input type="date" className={inputCls} value={form.tournament_start_date ?? ""} onChange={(e) => setForm({ ...form, tournament_start_date: e.target.value || null })} />
        </div>
        <div>
          <label className={labelCls}>Tournament End</label>
          <input type="date" className={inputCls} value={form.tournament_end_date ?? ""} onChange={(e) => setForm({ ...form, tournament_end_date: e.target.value || null })} />
        </div>
      </div>
      <div className="grid sm:grid-cols-2 gap-4">
        <div>
          <label className={labelCls}>Number of Finalist Teams</label>
          <input type="number" min={2} max={32} className={inputCls} value={form.finalist_team_count} onChange={(e) => setForm({ ...form, finalist_team_count: parseInt(e.target.value) || 5 })} />
        </div>
        <div>
          <label className={labelCls}>Team Registration Fee (₹ INR)</label>
          <input type="number" min={0} max={100000} className={inputCls} value={form.registration_fee} onChange={(e) => setForm({ ...form, registration_fee: parseInt(e.target.value) || 0 })} />
        </div>
      </div>
      <div>
        <label className={labelCls}>Internal Notes</label>
        <textarea rows={3} className={inputCls} value={form.notes ?? ""} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
      </div>
      <button onClick={save} disabled={saving} className="inline-flex items-center gap-2 px-6 py-3 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground text-xs uppercase tracking-wider font-bold shadow-neon disabled:opacity-50">
        {saving && <Loader2 size={14} className="animate-spin" />}
        <Save size={14} /> Save Tournament Settings
      </button>
    </div>
  );
}
