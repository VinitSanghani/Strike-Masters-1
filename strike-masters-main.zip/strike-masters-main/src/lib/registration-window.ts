// Shared logic for determining whether a tournament's registration window is open.
// Honors admin-configured registration_open_date / registration_close_date so a
// tournament with a future open date is NOT yet accepting users, and a passed
// close date stops accepting new registrations.

export interface RegistrationWindowInput {
  registration_open: boolean;
  status: string;
  registration_open_date?: string | null;
  registration_close_date?: string | null;
}

function parseDate(value: string | null | undefined): Date | null {
  if (!value) return null;
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? null : d;
}

export type RegistrationWindowState =
  | "open"
  | "not_yet_open"
  | "closed"
  | "ended";

export function getRegistrationWindowState(
  t: RegistrationWindowInput,
  now: Date = new Date(),
): RegistrationWindowState {
  if (t.status === "completed" || t.status === "archived") return "ended";
  if (!t.registration_open) return "closed";

  const openAt = parseDate(t.registration_open_date);
  if (openAt && now < openAt) return "not_yet_open";

  const closeAt = parseDate(t.registration_close_date);
  if (closeAt) {
    // Treat date-only values as end-of-day in local time so the close date
    // itself remains an open day.
    const isDateOnly = /^\d{4}-\d{2}-\d{2}$/.test(t.registration_close_date ?? "");
    const effectiveClose = isDateOnly
      ? new Date(closeAt.getFullYear(), closeAt.getMonth(), closeAt.getDate(), 23, 59, 59, 999)
      : closeAt;
    if (now > effectiveClose) return "closed";
  }

  return "open";
}

export function isRegistrationWindowOpen(
  t: RegistrationWindowInput,
  now: Date = new Date(),
): boolean {
  return getRegistrationWindowState(t, now) === "open";
}

export function registrationWindowMessage(state: RegistrationWindowState): string {
  switch (state) {
    case "not_yet_open":
      return "Registration Opens Soon";
    case "closed":
      return "Registration Closed";
    case "ended":
      return "Tournament Completed";
    case "open":
    default:
      return "";
  }
}
