import { useEffect, useMemo, useState } from "react";
import {
  Loader2, Plus, Trash2, Edit3, Save, X, Image as ImageIcon, Copy, Star,
  Archive, Calendar, MapPin, Users, IndianRupee, Trophy, Eye, EyeOff,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { formatDateDMY, formatDateTimeDMY } from "@/lib/format-date";

export interface Tournament {
  id: string;
  slug: string;
  name: string;
  subtitle: string | null;
  description: string | null;
  rules: string | null;
  banner_url: string | null;
  venue: string | null;
  qualification_date: string | null;
  finals_date: string | null;
  registration_open_date: string | null;
  registration_close_date: string | null;
  registration_deadline: string | null;
  registration_open: boolean;
  payment_required: boolean;
  registration_fee: number;
  early_bird_fee: number | null;
  early_bird_until: string | null;
  prize_pool: string;
  prize_pool_amount: number | null;
  max_teams: number | null;
  team_size: number;
  finalist_count: number;
  lane_batch_size: number | null;
  qualification_format: string | null;
  status: "draft" | "upcoming" | "active" | "completed" | "archived";
  featured: boolean;
  notes: string | null;
  tournament_type: "solo" | "team";
  payment_methods: string[];
  upi_qr_url: string | null;
  upi_id: string | null;
  payment_instructions: string | null;
  cash_payment_deadline: string | null;
  auto_confirm_online: boolean;
  number_of_winners: number;
  created_at: string;
  updated_at: string;
}

const STATUS_OPTIONS: Tournament["status"][] = ["draft", "upcoming", "active", "completed", "archived"];

function slugify(s: string) {
  return s.toLowerCase().trim()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .slice(0, 80);
}

function statusColor(s: Tournament["status"]) {
  switch (s) {
    case "active": return "text-success border-success/40 bg-success/10";
    case "upcoming": return "text-neon border-neon/40 bg-neon/10";
    case "completed": return "text-muted-foreground border-border bg-card/40";
    case "archived": return "text-muted-foreground/60 border-border bg-card/20";
    default: return "text-amber-400 border-amber-400/40 bg-amber-400/10";
  }
}

export function TournamentsTab() {
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [registrationCounts, setRegistrationCounts] = useState<Record<string, number>>({});
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<Tournament | null>(null);
  const [creating, setCreating] = useState(false);
  const [statusFilter, setStatusFilter] = useState<"all" | Tournament["status"]>("all");

  const refresh = async () => {
    const [tRes, rRes] = await Promise.all([
      supabase.from("tournaments").select("*").order("created_at", { ascending: false }),
      supabase.from("registrations").select("tournament_id, payment_verified"),
    ]);
    if (tRes.error) toast.error(tRes.error.message);
    setTournaments((tRes.data ?? []) as Tournament[]);
    const counts: Record<string, number> = {};
    for (const r of (rRes.data ?? []) as { tournament_id: string | null; payment_verified: boolean }[]) {
      if (r.tournament_id && r.payment_verified) {
        counts[r.tournament_id] = (counts[r.tournament_id] ?? 0) + 1;
      }
    }
    setRegistrationCounts(counts);
    setLoading(false);
  };

  useEffect(() => { refresh(); }, []);

  const filtered = useMemo(() => {
    if (statusFilter === "all") return tournaments;
    return tournaments.filter((t) => t.status === statusFilter);
  }, [tournaments, statusFilter]);

  const setFeatured = async (t: Tournament) => {
    if (t.featured) {
      const { error } = await supabase.from("tournaments").update({ featured: false }).eq("id", t.id);
      if (error) return toast.error(error.message);
    } else {
      // Unfeature any other first
      await supabase.from("tournaments").update({ featured: false }).eq("featured", true);
      const { error } = await supabase.from("tournaments").update({ featured: true }).eq("id", t.id);
      if (error) return toast.error(error.message);
    }
    toast.success(t.featured ? "Removed from homepage" : "Set as featured tournament");
    await refresh();
  };

  const duplicate = async (t: Tournament) => {
    const newName = `${t.name} (Copy)`;
    const baseSlug = slugify(newName);
    const slug = `${baseSlug}-${Date.now().toString(36).slice(-4)}`;
    const { id, created_at, updated_at, featured, ...rest } = t;
    void id; void created_at; void updated_at; void featured;
    const { error } = await supabase.from("tournaments").insert({
      ...rest,
      name: newName,
      slug,
      status: "draft",
      featured: false,
    });
    if (error) return toast.error(error.message);
    toast.success("Tournament duplicated as draft");
    await refresh();
  };

  const archive = async (t: Tournament) => {
    const { error } = await supabase.from("tournaments").update({ status: "archived", featured: false }).eq("id", t.id);
    if (error) return toast.error(error.message);
    toast.success("Archived");
    await refresh();
  };

  const remove = async (t: Tournament) => {
    if (!confirm(`Permanently delete "${t.name}"? This will remove all linked content.`)) return;
    const { error } = await supabase.from("tournaments").delete().eq("id", t.id);
    if (error) return toast.error(error.message);
    toast.success("Tournament deleted");
    await refresh();
  };

  if (loading) {
    return <div className="text-center py-12"><Loader2 className="w-6 h-6 mx-auto animate-spin text-neon" /></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h3 className="font-display text-xl text-neon">Tournaments</h3>
          <p className="text-xs text-muted-foreground mt-1">Create, edit, duplicate, and archive tournaments. The featured one appears on the homepage.</p>
        </div>
        <div className="flex gap-2">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as "all" | Tournament["status"])}
            className="px-3 py-2 rounded-md bg-input/60 border border-border text-xs uppercase tracking-wider"
          >
            <option value="all">All Statuses</option>
            {STATUS_OPTIONS.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
          <button
            onClick={() => setCreating(true)}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground text-xs uppercase tracking-wider font-bold shadow-neon"
          >
            <Plus size={14} /> Create Tournament
          </button>
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border bg-card/40 p-10 text-center">
          <Trophy className="w-10 h-10 mx-auto text-muted-foreground mb-2" />
          <p className="text-sm text-muted-foreground">No tournaments yet. Click "Create Tournament" to launch your first one.</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((t) => (
            <div key={t.id} className={`rounded-xl border bg-card/60 shadow-glow overflow-hidden ${t.featured ? "border-neon" : "border-border"}`}>
              <div className="aspect-[16/9] bg-background/60 relative overflow-hidden">
                {t.banner_url ? (
                  <img src={t.banner_url} alt={t.name} className="w-full h-full object-cover" loading="lazy" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center"><ImageIcon className="w-10 h-10 text-muted-foreground" /></div>
                )}
                <div className="absolute top-2 left-2 flex gap-1.5">
                  <span className={`text-[9px] uppercase tracking-widest font-bold border rounded px-2 py-0.5 ${statusColor(t.status)}`}>
                    {t.status}
                  </span>
                  {t.featured && (
                    <span className="text-[9px] uppercase tracking-widest font-bold border rounded px-2 py-0.5 text-neon border-neon/40 bg-background/80 inline-flex items-center gap-1">
                      <Star size={10} /> Featured
                    </span>
                  )}
                </div>
              </div>
              <div className="p-4">
                <h4 className="font-display text-base mb-0.5 truncate">{t.name}</h4>
                {t.subtitle && <p className="text-xs text-muted-foreground line-clamp-1 mb-2">{t.subtitle}</p>}
                <div className="space-y-1 text-[11px] text-muted-foreground mb-3">
                  {t.qualification_date && (
                    <div className="flex items-center gap-1.5"><Calendar size={11} className="text-neon" /> Qualification: {formatDateDMY(t.qualification_date)}</div>
                  )}
                  {t.finals_date && (
                    <div className="flex items-center gap-1.5"><Trophy size={11} className="text-neon" /> Finals: {formatDateDMY(t.finals_date)}</div>
                  )}
                  {t.venue && <div className="flex items-center gap-1.5 truncate"><MapPin size={11} className="text-neon" /> {t.venue}</div>}
                  <div className="flex items-center gap-3">
                    <span className="inline-flex items-center gap-1"><IndianRupee size={11} className="text-neon" /> {t.registration_fee.toLocaleString("en-IN")}</span>
                    <span className="inline-flex items-center gap-1"><Users size={11} className="text-neon" /> {registrationCounts[t.id] ?? 0}{t.max_teams ? `/${t.max_teams}` : ""}</span>
                  </div>
                </div>
                <div className="flex items-center justify-between gap-1 pt-3 border-t border-border">
                  <button onClick={() => setFeatured(t)} className={`p-1.5 rounded hover:bg-neon/10 ${t.featured ? "text-neon" : "text-muted-foreground"}`} title={t.featured ? "Remove from homepage" : "Feature on homepage"}>
                    <Star size={14} fill={t.featured ? "currentColor" : "none"} />
                  </button>
                  <div className="flex gap-1">
                    <button onClick={() => duplicate(t)} className="p-1.5 rounded text-muted-foreground hover:text-neon hover:bg-neon/10" title="Duplicate"><Copy size={14} /></button>
                    <button onClick={() => archive(t)} disabled={t.status === "archived"} className="p-1.5 rounded text-muted-foreground hover:text-amber-400 hover:bg-amber-400/10 disabled:opacity-30" title="Archive"><Archive size={14} /></button>
                    <button onClick={() => setEditing(t)} className="p-1.5 rounded text-neon hover:bg-neon/10" title="Edit"><Edit3 size={14} /></button>
                    <button onClick={() => remove(t)} className="p-1.5 rounded text-destructive hover:bg-destructive/10" title="Delete"><Trash2 size={14} /></button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {(creating || editing) && (
        <TournamentModal
          tournament={editing}
          onClose={() => { setCreating(false); setEditing(null); }}
          onSaved={async () => { setCreating(false); setEditing(null); await refresh(); }}
        />
      )}
    </div>
  );
}

const padDatePart = (n: number) => String(n).padStart(2, "0");

function fromDateInput(s: string): string | null {
  if (!s) return null;
  const normalized = s.trim();
  const native = normalized.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})$/);
  const dmy = normalized.match(/^(\d{1,2})[/-](\d{1,2})[/-](\d{2,4})(?:[ T](\d{1,2}):(\d{2}))?$/);
  let d: Date | null = null;
  if (native) {
    d = new Date(Number(native[1]), Number(native[2]) - 1, Number(native[3]), Number(native[4]), Number(native[5]));
  } else if (dmy) {
    const year = Number(dmy[3].length === 2 ? `20${dmy[3]}` : dmy[3]);
    d = new Date(year, Number(dmy[2]) - 1, Number(dmy[1]), Number(dmy[4] ?? 0), Number(dmy[5] ?? 0));
  } else {
    const dateOnly = normalized.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (dateOnly) {
      d = new Date(Number(dateOnly[1]), Number(dateOnly[2]) - 1, Number(dateOnly[3]), 0, 0);
    }
  }
  if (!d || isNaN(d.getTime())) return null;
  return d.toISOString();
}

function toDateOnlyInput(d: string | null): string {
  if (!d) return "";
  const date = new Date(d);
  if (isNaN(date.getTime())) return "";
  return `${date.getFullYear()}-${padDatePart(date.getMonth() + 1)}-${padDatePart(date.getDate())}`;
}

function fromDateOnlyInput(s: string): string | null {
  if (!s) return null;
  const normalized = s.trim();
  const native = normalized.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  const dmy = normalized.match(/^(\d{1,2})[/-](\d{1,2})[/-](\d{2,4})$/);
  if (native) return `${native[1]}-${native[2]}-${native[3]}`;
  if (dmy) {
    const year = dmy[3].length === 2 ? `20${dmy[3]}` : dmy[3];
    return `${year}-${padDatePart(Number(dmy[2]))}-${padDatePart(Number(dmy[1]))}`;
  }
  return null;
}

function TournamentModal({
  tournament,
  onClose,
  onSaved,
}: {
  tournament: Tournament | null;
  onClose: () => void;
  onSaved: () => Promise<void>;
}) {
  const [form, setForm] = useState<{
    name: string;
    slug: string;
    subtitle: string;
    description: string;
    rules: string;
    venue: string;
    qualification_date: string;
    finals_date: string;
    registration_open_date: string;
    registration_close_date: string;
    registration_deadline: string;
    registration_open: boolean;
    payment_required: boolean;
    registration_fee: number;
    early_bird_fee: number | null;
    early_bird_until: string;
    prize_pool: string;
    prize_pool_amount: number | null;
    max_teams: number | null;
    team_size: number;
    finalist_count: number;
    lane_batch_size: number | null;
    qualification_format: string;
    status: Tournament["status"];
    featured: boolean;
    notes: string;
    tournament_type: "solo" | "team";
    payment_methods: string[];
    upi_id: string;
    payment_instructions: string;
    cash_payment_deadline: string;
    auto_confirm_online: boolean;
    number_of_winners: number;
  }>({
    name: tournament?.name ?? "",
    slug: tournament?.slug ?? "",
    subtitle: tournament?.subtitle ?? "",
    description: tournament?.description ?? "",
    rules: tournament?.rules ?? "",
    venue: tournament?.venue ?? "",
    qualification_date: toDateOnlyInput(tournament?.qualification_date ?? null),
    finals_date: toDateOnlyInput(tournament?.finals_date ?? null),
    registration_open_date: toDateOnlyInput(tournament?.registration_open_date ?? null),
    registration_close_date: toDateOnlyInput(tournament?.registration_close_date ?? null),
    registration_deadline: toDateOnlyInput(tournament?.registration_deadline ?? null),
    registration_open: tournament?.registration_open ?? true,
    payment_required: tournament?.payment_required ?? true,
    registration_fee: tournament?.registration_fee ?? 3000,
    early_bird_fee: tournament?.early_bird_fee ?? null,
    early_bird_until: toDateOnlyInput(tournament?.early_bird_until ?? null),
    prize_pool: tournament?.prize_pool ?? "Prize Pool Scales With Registrations",
    prize_pool_amount: tournament?.prize_pool_amount ?? null,
    max_teams: tournament?.max_teams ?? null,
    team_size: tournament?.team_size ?? 3,
    finalist_count: tournament?.finalist_count ?? 5,
    lane_batch_size: tournament?.lane_batch_size ?? 4,
    qualification_format: tournament?.qualification_format ?? "",
    status: tournament?.status ?? "draft",
    featured: tournament?.featured ?? false,
    notes: tournament?.notes ?? "",
    tournament_type: tournament?.tournament_type ?? "team",
    payment_methods: (tournament?.payment_methods ?? ["upi_qr", "cash"]).filter((m) => m !== "online"),
    upi_id: tournament?.upi_id ?? "",
    payment_instructions: tournament?.payment_instructions ?? "",
    cash_payment_deadline: toDateOnlyInput(tournament?.cash_payment_deadline ?? null),
    auto_confirm_online: tournament?.auto_confirm_online ?? true,
    number_of_winners: tournament?.number_of_winners ?? 3,
  });
  const [bannerUrl, setBannerUrl] = useState<string | null>(tournament?.banner_url ?? null);
  const [qrUrl, setQrUrl] = useState<string | null>(tournament?.upi_qr_url ?? null);
  const [uploading, setUploading] = useState(false);
  const [uploadingQr, setUploadingQr] = useState(false);
  const [saving, setSaving] = useState(false);
  const [slugTouched, setSlugTouched] = useState(!!tournament);

  const onBannerChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5_000_000) {
      toast.error("Banner must be smaller than 5 MB");
      return;
    }
    setUploading(true);
    const ext = file.name.split(".").pop()?.toLowerCase() || "jpg";
    const path = `${crypto.randomUUID()}.${ext}`;
    const { error: upErr } = await supabase.storage.from("tournament-banners").upload(path, file, {
      cacheControl: "3600",
      upsert: false,
      contentType: file.type,
    });
    setUploading(false);
    if (upErr) {
      toast.error(upErr.message);
      return;
    }
    const { data } = supabase.storage.from("tournament-banners").getPublicUrl(path);
    setBannerUrl(data.publicUrl);
    toast.success("Banner uploaded");
  };

  const onQrChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 3_000_000) { toast.error("QR image must be under 3 MB"); return; }
    setUploadingQr(true);
    const ext = file.name.split(".").pop()?.toLowerCase() || "png";
    const path = `qr-${crypto.randomUUID()}.${ext}`;
    const { error: upErr } = await supabase.storage.from("tournament-banners").upload(path, file, {
      cacheControl: "3600", upsert: false, contentType: file.type,
    });
    setUploadingQr(false);
    if (upErr) { toast.error(upErr.message); return; }
    const { data } = supabase.storage.from("tournament-banners").getPublicUrl(path);
    setQrUrl(data.publicUrl);
    toast.success("QR code uploaded");
  };

  const save = async () => {
    if (!form.name.trim()) {
      toast.error("Tournament name is required");
      return;
    }
    const slug = (form.slug.trim() || slugify(form.name)).slice(0, 80);
    if (!slug) {
      toast.error("Slug could not be generated. Please enter one.");
      return;
    }

    setSaving(true);
    const payload = {
      name: form.name.trim(),
      slug,
      subtitle: form.subtitle.trim() || null,
      description: form.description.trim() || null,
      rules: form.rules.trim() || null,
      venue: form.venue.trim() || null,
      banner_url: bannerUrl,
      qualification_date: fromDateInput(form.qualification_date),
      finals_date: fromDateInput(form.finals_date),
      registration_open_date: fromDateInput(form.registration_open_date),
      registration_close_date: fromDateInput(form.registration_close_date),
      registration_deadline: fromDateOnlyInput(form.registration_deadline),
      registration_open: form.registration_open,
      payment_required: form.payment_required,
      registration_fee: Number(form.registration_fee) || 0,
      early_bird_fee: form.early_bird_fee ? Number(form.early_bird_fee) : null,
      early_bird_until: fromDateOnlyInput(form.early_bird_until),
      prize_pool: form.prize_pool.trim() || "Prize Pool Scales With Registrations",
      prize_pool_amount: form.prize_pool_amount ? Number(form.prize_pool_amount) : null,
      max_teams: form.max_teams ? Number(form.max_teams) : null,
      team_size: Number(form.team_size) || 3,
      finalist_count: Number(form.finalist_count) || 5,
      lane_batch_size: form.lane_batch_size ? Number(form.lane_batch_size) : null,
      qualification_format: form.qualification_format.trim() || null,
      status: form.status,
      notes: form.notes.trim() || null,
      tournament_type: form.tournament_type,
      payment_methods: form.payment_methods.length ? form.payment_methods : ["upi_qr", "cash"],
      upi_qr_url: qrUrl,
      upi_id: form.upi_id.trim() || null,
      payment_instructions: form.payment_instructions.trim() || null,
      cash_payment_deadline: fromDateOnlyInput(form.cash_payment_deadline),
      auto_confirm_online: form.auto_confirm_online,
      number_of_winners: Number(form.number_of_winners) || 1,
    };

    let error: { message: string } | null = null;
    if (tournament) {
      const res = await supabase.from("tournaments").update(payload).eq("id", tournament.id);
      error = res.error;
    } else {
      const res = await supabase.from("tournaments").insert(payload);
      error = res.error;
    }

    // Handle featured toggle separately to avoid unique-index violation
    if (!error && form.featured) {
      if (!tournament || !tournament.featured) {
        await supabase.from("tournaments").update({ featured: false }).eq("featured", true);
      }
      if (tournament) {
        await supabase.from("tournaments").update({ featured: true }).eq("id", tournament.id);
      } else {
        await supabase.from("tournaments").update({ featured: true }).eq("slug", slug);
      }
    } else if (!error && tournament && tournament.featured && !form.featured) {
      await supabase.from("tournaments").update({ featured: false }).eq("id", tournament.id);
    }

    setSaving(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(tournament ? "Tournament updated" : "Tournament created");
    await onSaved();
  };

  const inputCls = "w-full px-3 py-2 rounded-md bg-input/60 border border-border text-sm focus:border-neon focus:outline-none";
  const labelCls = "block text-[10px] uppercase tracking-widest text-muted-foreground mb-1";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur" onClick={onClose}>
      <div className="w-full max-w-3xl rounded-2xl border border-border bg-card p-6 shadow-glow max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4 sticky top-0 bg-card pb-2 border-b border-border z-10">
          <h3 className="font-display text-xl text-neon">{tournament ? "Edit Tournament" : "Create Tournament"}</h3>
          <button onClick={onClose} className="p-2 hover:bg-accent rounded"><X size={16} /></button>
        </div>

        {/* Banner */}
        <div className="mb-4">
          <label className={labelCls}>Tournament Banner</label>
          <div className="flex items-start gap-4">
            <div className="w-48 aspect-video rounded-md border border-border bg-background/60 flex items-center justify-center overflow-hidden shrink-0">
              {bannerUrl ? (
                <img src={bannerUrl} alt="Banner preview" className="w-full h-full object-cover" />
              ) : (
                <ImageIcon className="w-8 h-8 text-muted-foreground" />
              )}
            </div>
            <div className="flex-1">
              <input
                type="file"
                accept="image/png,image/jpeg,image/webp"
                onChange={onBannerChange}
                disabled={uploading}
                className="block w-full text-xs file:mr-3 file:py-2 file:px-4 file:rounded-md file:border-0 file:bg-neon file:text-neon-foreground file:font-bold file:text-xs file:uppercase file:tracking-wider file:cursor-pointer"
              />
              <p className="text-[11px] text-muted-foreground mt-2">JPG, PNG, or WEBP. Max 5 MB. 16:9 ratio recommended.</p>
              {uploading && <p className="text-xs text-neon mt-1 inline-flex items-center gap-1"><Loader2 size={12} className="animate-spin" /> Uploading…</p>}
              {bannerUrl && (
                <button onClick={() => setBannerUrl(null)} className="text-[11px] text-destructive mt-1 underline">Remove banner</button>
              )}
            </div>
          </div>
        </div>

        {/* Core */}
        <div className="grid sm:grid-cols-2 gap-3">
          <div className="sm:col-span-2">
            <label className={labelCls}>Tournament Name *</label>
            <input
              className={inputCls}
              value={form.name}
              onChange={(e) => {
                const name = e.target.value;
                setForm({ ...form, name, slug: slugTouched ? form.slug : slugify(name) });
              }}
              placeholder="Strike Masters 2026"
            />
          </div>
          <div>
            <label className={labelCls}>URL Slug *</label>
            <input
              className={inputCls}
              value={form.slug}
              onChange={(e) => { setSlugTouched(true); setForm({ ...form, slug: slugify(e.target.value) }); }}
              placeholder="strike-masters-2026"
            />
            <p className="text-[10px] text-muted-foreground mt-1">URL: /tournaments/{form.slug || "your-slug"}</p>
          </div>
          <div>
            <label className={labelCls}>Status</label>
            <select className={inputCls} value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as Tournament["status"] })}>
              {STATUS_OPTIONS.map((s) => <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>)}
            </select>
          </div>
          <div className="sm:col-span-2">
            <label className={labelCls}>Subtitle / Tagline</label>
            <input className={inputCls} value={form.subtitle} onChange={(e) => setForm({ ...form, subtitle: e.target.value })} placeholder="Premier Bowling Championship" />
          </div>
          <div className="sm:col-span-2">
            <label className={labelCls}>Description</label>
            <textarea rows={3} className={inputCls} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          </div>
          <div className="sm:col-span-2">
            <label className={labelCls}>Rules / Format</label>
            <textarea rows={4} className={inputCls} value={form.rules} onChange={(e) => setForm({ ...form, rules: e.target.value })} placeholder="Tournament rules, format, and policies..." />
          </div>
        </div>

        {/* Schedule */}
        <h4 className="font-display text-sm text-neon mt-6 mb-2 uppercase tracking-widest">Schedule & Venue</h4>
        <div className="grid sm:grid-cols-2 gap-3">
          <div>
            <label className={labelCls}>Qualification Date</label>
            <input type="date" className={inputCls} value={form.qualification_date} onChange={(e) => setForm({ ...form, qualification_date: e.target.value })} />
          </div>
          <div>
            <label className={labelCls}>Finals Date</label>
            <input type="date" className={inputCls} value={form.finals_date} onChange={(e) => setForm({ ...form, finals_date: e.target.value })} />
          </div>
          <div className="sm:col-span-2">
            <label className={labelCls}>Venue / Location</label>
            <input className={inputCls} value={form.venue} onChange={(e) => setForm({ ...form, venue: e.target.value })} placeholder="LaneX Bowling Alley, AR Mall, Surat" />
          </div>
        </div>

        {/* Registration */}
        <h4 className="font-display text-sm text-neon mt-6 mb-2 uppercase tracking-widest">Registration</h4>
        <div className="grid sm:grid-cols-2 gap-3">
          <div>
            <label className={labelCls}>Registration Opens</label>
            <input type="date" className={inputCls} value={form.registration_open_date} onChange={(e) => setForm({ ...form, registration_open_date: e.target.value })} />
          </div>
          <div>
            <label className={labelCls}>Registration Closes</label>
            <input type="date" className={inputCls} value={form.registration_close_date} onChange={(e) => setForm({ ...form, registration_close_date: e.target.value })} />
          </div>
          <div>
            <label className={labelCls}>Registration Deadline (display)</label>
            <input type="date" className={inputCls} value={form.registration_deadline} onChange={(e) => setForm({ ...form, registration_deadline: e.target.value })} />
          </div>
          <div>
            <label className={labelCls}>Max Teams (slot limit)</label>
            <input type="number" min="0" className={inputCls} value={form.max_teams ?? ""} onChange={(e) => setForm({ ...form, max_teams: e.target.value ? Number(e.target.value) : null })} placeholder="Unlimited" />
          </div>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={form.registration_open} onChange={(e) => setForm({ ...form, registration_open: e.target.checked })} />
            Registration Open
          </label>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={form.payment_required} onChange={(e) => setForm({ ...form, payment_required: e.target.checked })} />
            Payment Required
          </label>
        </div>

        {/* Pricing */}
        <h4 className="font-display text-sm text-neon mt-6 mb-2 uppercase tracking-widest">Pricing & Prizes</h4>
        <div className="grid sm:grid-cols-2 gap-3">
          <div>
            <label className={labelCls}>Entry Fee (₹) *</label>
            <input type="number" min="0" className={inputCls} value={form.registration_fee} onChange={(e) => setForm({ ...form, registration_fee: Number(e.target.value) })} />
          </div>
          <div>
            <label className={labelCls}>Early Bird Fee (₹) (optional)</label>
            <input type="number" min="0" className={inputCls} value={form.early_bird_fee ?? ""} onChange={(e) => setForm({ ...form, early_bird_fee: e.target.value ? Number(e.target.value) : null })} />
          </div>
          <div>
            <label className={labelCls}>Early Bird Until</label>
            <input type="date" className={inputCls} value={form.early_bird_until} onChange={(e) => setForm({ ...form, early_bird_until: e.target.value })} />
          </div>
          <div>
            <label className={labelCls}>Prize Pool Amount (₹)</label>
            <input type="number" min="0" className={inputCls} value={form.prize_pool_amount ?? ""} onChange={(e) => setForm({ ...form, prize_pool_amount: e.target.value ? Number(e.target.value) : null })} />
          </div>
          <div className="sm:col-span-2">
            <label className={labelCls}>Prize Pool Description</label>
            <input className={inputCls} value={form.prize_pool} onChange={(e) => setForm({ ...form, prize_pool: e.target.value })} placeholder="Prize Pool Scales With Registrations" />
          </div>
        </div>

        {/* Payment Methods */}
        <h4 className="font-display text-sm text-neon mt-6 mb-2 uppercase tracking-widest">Payment Methods</h4>
        <p className="text-[11px] text-muted-foreground mb-3">Choose which payment methods are available for this tournament. Players will pick at registration.</p>
        <div className="grid sm:grid-cols-2 gap-2 mb-3">
          {(["upi_qr", "cash"] as const).map((m) => (
            <label key={m} className="flex items-center gap-2 text-sm rounded-md border border-border bg-input/40 px-3 py-2 cursor-pointer hover:border-neon/40 transition-colors">
              <input
                type="checkbox"
                checked={form.payment_methods.includes(m)}
                onChange={(e) => {
                  const next = e.target.checked
                    ? [...form.payment_methods.filter((x) => x !== m), m]
                    : form.payment_methods.filter((x) => x !== m);
                  setForm({ ...form, payment_methods: next });
                }}
              />
              {m === "cash" ? "💵 Cash (pay at venue / before deadline)" : "📱 UPI / QR (upload screenshot)"}
            </label>
          ))}
        </div>
        <div className="grid sm:grid-cols-2 gap-3">
          <div>
            <label className={labelCls}>UPI ID (display)</label>
            <input className={inputCls} value={form.upi_id} onChange={(e) => setForm({ ...form, upi_id: e.target.value })} placeholder="yourname@upi" />
          </div>
          <div>
            <label className={labelCls}>Cash Payment Deadline</label>
            <input type="date" className={inputCls} value={form.cash_payment_deadline} onChange={(e) => setForm({ ...form, cash_payment_deadline: e.target.value })} />
          </div>
          <div className="sm:col-span-2">
            <label className={labelCls}>UPI / QR Code Image</label>
            <div className="flex items-start gap-3">
              <div className="w-32 h-32 rounded-md border border-border bg-background/60 flex items-center justify-center overflow-hidden shrink-0">
                {qrUrl ? <img src={qrUrl} alt="QR" className="w-full h-full object-contain" /> : <ImageIcon className="w-6 h-6 text-muted-foreground" />}
              </div>
              <div className="flex-1">
                <input type="file" accept="image/png,image/jpeg,image/webp" onChange={onQrChange} disabled={uploadingQr}
                  className="block w-full text-xs file:mr-3 file:py-2 file:px-4 file:rounded-md file:border-0 file:bg-neon file:text-neon-foreground file:font-bold file:text-xs file:uppercase file:tracking-wider file:cursor-pointer" />
                <p className="text-[11px] text-muted-foreground mt-2">PNG/JPG. Max 3 MB. Used when UPI/QR payment is enabled.</p>
                {uploadingQr && <p className="text-xs text-neon mt-1 inline-flex items-center gap-1"><Loader2 size={12} className="animate-spin" /> Uploading…</p>}
                {qrUrl && <button onClick={() => setQrUrl(null)} className="text-[11px] text-destructive mt-1 underline">Remove QR</button>}
              </div>
            </div>
          </div>
          <div className="sm:col-span-2">
            <label className={labelCls}>Payment Instructions / Notes</label>
            <textarea rows={2} className={inputCls} value={form.payment_instructions} onChange={(e) => setForm({ ...form, payment_instructions: e.target.value })} placeholder="Pay via UPI to ID above, then upload screenshot…" />
          </div>
        </div>

        {/* Tournament Type & Winners */}
        <h4 className="font-display text-sm text-neon mt-6 mb-2 uppercase tracking-widest">Tournament Type & Winners</h4>
        <div className="grid sm:grid-cols-3 gap-3">
          <div>
            <label className={labelCls}>Tournament Type</label>
            <select className={inputCls} value={form.tournament_type} onChange={(e) => setForm({ ...form, tournament_type: e.target.value as "solo" | "team" })}>
              <option value="team">Team Tournament</option>
              <option value="solo">Solo Tournament</option>
            </select>
          </div>
          <div>
            <label className={labelCls}>Number of Winners</label>
            <input type="number" min="1" max="20" className={inputCls} value={form.number_of_winners} onChange={(e) => setForm({ ...form, number_of_winners: Number(e.target.value) || 1 })} />
            <p className="text-[10px] text-muted-foreground mt-1">1 = Champion only · 2 = 1st/2nd · 3 = 1st/2nd/3rd …</p>
          </div>
        </div>

        {/* Format settings */}
        <h4 className="font-display text-sm text-neon mt-6 mb-2 uppercase tracking-widest">Format Settings</h4>
        <div className="grid sm:grid-cols-3 gap-3">
          <div>
            <label className={labelCls}>Team Size</label>
            <input type="number" min="1" className={inputCls} value={form.team_size} onChange={(e) => setForm({ ...form, team_size: Number(e.target.value) })} />
          </div>
          <div>
            <label className={labelCls}>Finalist Teams</label>
            <input type="number" min="1" className={inputCls} value={form.finalist_count} onChange={(e) => setForm({ ...form, finalist_count: Number(e.target.value) })} />
          </div>
          <div>
            <label className={labelCls}>Lane Batch Size</label>
            <input type="number" min="1" className={inputCls} value={form.lane_batch_size ?? ""} onChange={(e) => setForm({ ...form, lane_batch_size: e.target.value ? Number(e.target.value) : null })} />
          </div>
          <div className="sm:col-span-3">
            <label className={labelCls}>Qualification Format</label>
            <input className={inputCls} value={form.qualification_format} onChange={(e) => setForm({ ...form, qualification_format: e.target.value })} placeholder="3 games per team, top 5 advance" />
          </div>
        </div>

        {/* Visibility */}
        <h4 className="font-display text-sm text-neon mt-6 mb-2 uppercase tracking-widest">Visibility</h4>
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={form.featured} onChange={(e) => setForm({ ...form, featured: e.target.checked })} />
          <Star size={14} className="text-neon" /> Feature on homepage (only one tournament can be featured)
        </label>

        <div className="mt-2">
          <label className={labelCls}>Internal Notes (admin only)</label>
          <textarea rows={2} className={inputCls} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
        </div>

        <div className="mt-6 flex justify-end gap-2 sticky bottom-0 bg-card pt-4 border-t border-border">
          <button onClick={onClose} className="px-4 py-2 rounded-md border border-border text-xs uppercase tracking-wider font-bold">Cancel</button>
          <button onClick={save} disabled={saving || uploading} className="inline-flex items-center gap-2 px-4 py-2 rounded-md bg-gradient-to-r from-neon to-primary text-neon-foreground text-xs uppercase tracking-wider font-bold disabled:opacity-50">
            {saving && <Loader2 size={14} className="animate-spin" />}
            <Save size={14} /> {tournament ? "Save Changes" : "Create Tournament"}
          </button>
        </div>
      </div>
    </div>
  );
}
