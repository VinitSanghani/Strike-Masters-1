import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Loader2 } from "lucide-react";
import { SectionHeader } from "@/components/SectionHeader";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/refund")({
  head: () => ({
    meta: [
      { title: "Refund Policy — Strike Masters Bowling Tournament 2026" },
      { name: "description", content: "Strike Masters refund and cancellation policy for tournament registrations." },
      { property: "og:title", content: "Refund Policy — Strike Masters 2026" },
      { property: "og:description", content: "Refund and cancellation terms for tournament entries." },
    ],
  }),
  component: RefundPage,
});

interface Section { heading: string; body: string }
interface LegalPage {
  eyebrow: string;
  title: string;
  description: string;
  sections: Section[];
}

function RefundPage() {
  const [c, setC] = useState<LegalPage | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const { data } = await (supabase as any)
        .from("legal_pages")
        .select("eyebrow,title,description,sections")
        .eq("page_key", "refund")
        .maybeSingle();
      if (cancelled) return;
      if (data) {
        setC({ ...data, sections: Array.isArray(data.sections) ? data.sections : [] } as LegalPage);
      }
      setLoading(false);
    })();
    return () => { cancelled = true; };
  }, []);

  if (loading) {
    return <div className="container mx-auto px-4 py-32 text-center"><Loader2 className="w-8 h-8 mx-auto animate-spin text-neon" /></div>;
  }
  if (!c) {
    return <div className="container mx-auto px-4 py-32 text-center text-sm text-muted-foreground">Refund content not available.</div>;
  }

  return (
    <div className="container mx-auto px-4 sm:px-6 py-14 sm:py-20">
      <SectionHeader eyebrow={c.eyebrow} title={c.title} description={c.description} />

      <div className="max-w-3xl mx-auto rounded-2xl border border-border bg-card/50 p-6 sm:p-10 space-y-8">
        {c.sections.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center">No policy sections yet.</p>
        ) : (
          c.sections.map((s, i) => (
            <div key={i}>
              <h3 className="font-display text-xl text-neon mb-2">{s.heading}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed whitespace-pre-line">{s.body}</p>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
